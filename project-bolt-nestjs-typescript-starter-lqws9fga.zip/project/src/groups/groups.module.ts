import { Module } from '@nestjs/common';
import { GroupsController } from './groups.controller';
import { GroupsService } from './groups.service';
import { CompetitionsController } from './competitions.controller';
import { CompetitionsService } from './competitions.service';
import { GroupsGateway } from './groups.gateway';

@Module({
  controllers: [GroupsController, CompetitionsController],
  providers: [GroupsService, CompetitionsService, GroupsGateway],
  exports: [GroupsService, CompetitionsService],
})
export class GroupsModule {}
