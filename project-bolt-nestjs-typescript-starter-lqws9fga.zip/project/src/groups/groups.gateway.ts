import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({ cors: true, namespace: '/groups' })
export class GroupsGateway {
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('joinGroupRoom')
  async handleJoinGroup(
    @MessageBody() data: { groupId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await client.join(`group-${data.groupId}`);
    return { success: true };
  }

  @SubscribeMessage('groupUpdate')
  handleGroupUpdate(@MessageBody() data: { groupId: string; update: any }) {
    this.server.to(`group-${data.groupId}`).emit('groupUpdated', data.update);
  }

  @SubscribeMessage('competitionUpdate')
  handleCompetitionUpdate(
    @MessageBody() data: { groupId: string; competitionId: string; update: any },
  ) {
    this.server
      .to(`group-${data.groupId}`)
      .emit('competitionUpdated', data.update);
  }

  @SubscribeMessage('voiceChannelUpdate')
  handleVoiceUpdate(
    @MessageBody() data: { groupId: string; channels: any[] },
  ) {
    this.server
      .to(`group-${data.groupId}`)
      .emit('voiceChannelsUpdated', data.channels);
  }

  @SubscribeMessage('musicUpdate')
  handleMusicUpdate(@MessageBody() data: { groupId: string; music: any }) {
    this.server.to(`group-${data.groupId}`).emit('musicUpdated', data.music);
  }

  @SubscribeMessage('newSupport')
  handleNewSupport(
    @MessageBody()
    data: {
      groupId: string;
      competitionId: string;
      support: any;
    },
  ) {
    this.server.to(`group-${data.groupId}`).emit('supportReceived', data.support);
  }
}
