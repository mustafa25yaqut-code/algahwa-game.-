import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface CreateCompetitionDto {
  groupId: string;
  competitionName: string;
  gameType: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
  entryFee: number;
  roundDuration?: number;
}

@Injectable()
export class CompetitionsService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async createCompetition(dto: CreateCompetitionDto) {
    const { data, error } = await this.supabase
      .from('group_competitions')
      .insert({
        group_id: dto.groupId,
        competition_name: dto.competitionName,
        game_type: dto.gameType,
        total_prize_pool: 0,
        round_duration: dto.roundDuration || 180,
        status: 'waiting',
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getCompetition(competitionId: string) {
    const { data, error } = await this.supabase
      .from('group_competitions')
      .select(
        `
        *,
        group:group_id(*),
        participants:competition_participants(
          *,
          profile:profile_id(id, username, avatar_url, level, player_id)
        ),
        supporters:competition_supporters(
          *,
          supporter:supporter_profile_id(id, username, avatar_url),
          participant:participant_profile_id(id, username, avatar_url)
        )
      `,
      )
      .eq('id', competitionId)
      .single();

    if (error) throw error;
    return data;
  }

  async listGroupCompetitions(groupId: string) {
    const { data, error } = await this.supabase
      .from('group_competitions')
      .select('*')
      .eq('group_id', groupId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  async joinCompetition(competitionId: string, profileId: string, entryFee: number) {
    const { data: participant, error: partError } = await this.supabase
      .from('competition_participants')
      .insert({
        competition_id: competitionId,
        profile_id: profileId,
        entry_fee: entryFee,
        current_score: 0,
      })
      .select()
      .single();

    if (partError) throw partError;

    const { data: competition } = await this.supabase
      .from('group_competitions')
      .select('total_prize_pool')
      .eq('id', competitionId)
      .single();

    const newPrizePool = (competition.total_prize_pool || 0) + entryFee;

    await this.supabase
      .from('group_competitions')
      .update({ total_prize_pool: newPrizePool })
      .eq('id', competitionId);

    return participant;
  }

  async startCompetition(competitionId: string) {
    const { data, error } = await this.supabase
      .from('group_competitions')
      .update({
        status: 'in_progress',
        started_at: new Date().toISOString(),
      })
      .eq('id', competitionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateParticipantScore(
    competitionId: string,
    profileId: string,
    score: number,
  ) {
    const { data, error } = await this.supabase
      .from('competition_participants')
      .update({ current_score: score })
      .eq('competition_id', competitionId)
      .eq('profile_id', profileId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async supportParticipant(
    competitionId: string,
    supporterProfileId: string,
    participantProfileId: string,
    amount: number,
    type: 'gift' | 'boost' | 'sponsor',
  ) {
    const { data, error } = await this.supabase
      .from('competition_supporters')
      .insert({
        competition_id: competitionId,
        supporter_profile_id: supporterProfileId,
        participant_profile_id: participantProfileId,
        support_amount: amount,
        support_type: type,
      })
      .select()
      .single();

    if (error) throw error;

    const { data: competition } = await this.supabase
      .from('group_competitions')
      .select('total_prize_pool')
      .eq('id', competitionId)
      .single();

    const newPrizePool = (competition.total_prize_pool || 0) + amount;

    await this.supabase
      .from('group_competitions')
      .update({ total_prize_pool: newPrizePool })
      .eq('id', competitionId);

    return data;
  }

  async completeCompetition(competitionId: string, winnerProfileId: string) {
    const { error } = await this.supabase.rpc('complete_competition', {
      p_competition_id: competitionId,
      p_winner_profile_id: winnerProfileId,
    });

    if (error) throw error;

    const competition = await this.getCompetition(competitionId);
    return competition;
  }

  async getParticipantSupport(competitionId: string, participantProfileId: string) {
    const { data, error } = await this.supabase
      .from('competition_supporters')
      .select(
        `
        *,
        supporter:supporter_profile_id(id, username, avatar_url)
      `,
      )
      .eq('competition_id', competitionId)
      .eq('participant_profile_id', participantProfileId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const totalSupport = data.reduce(
      (sum, support) => sum + parseFloat(support.support_amount),
      0,
    );

    return {
      supporters: data,
      totalSupport,
    };
  }

  async getLeaderboard(competitionId: string) {
    const { data, error } = await this.supabase
      .from('competition_participants')
      .select(
        `
        *,
        profile:profile_id(id, username, avatar_url, level, player_id)
      `,
      )
      .eq('competition_id', competitionId)
      .order('current_score', { ascending: false });

    if (error) throw error;

    return data.map((participant, index) => ({
      ...participant,
      rank: index + 1,
    }));
  }
}
