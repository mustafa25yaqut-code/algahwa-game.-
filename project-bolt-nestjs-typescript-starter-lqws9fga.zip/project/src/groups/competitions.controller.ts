import { Controller, Get, Post, Put, Body, Param } from '@nestjs/common';
import { CompetitionsService } from './competitions.service';

@Controller('competitions')
export class CompetitionsController {
  constructor(private competitionsService: CompetitionsService) {}

  @Post()
  async createCompetition(
    @Body()
    body: {
      groupId: string;
      competitionName: string;
      gameType: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
      entryFee: number;
      roundDuration?: number;
    },
  ) {
    const competition =
      await this.competitionsService.createCompetition(body);
    return { success: true, competition };
  }

  @Get(':id')
  async getCompetition(@Param('id') id: string) {
    const competition = await this.competitionsService.getCompetition(id);
    return { success: true, competition };
  }

  @Get('group/:groupId')
  async listGroupCompetitions(@Param('groupId') groupId: string) {
    const competitions =
      await this.competitionsService.listGroupCompetitions(groupId);
    return { success: true, competitions };
  }

  @Post(':id/join')
  async joinCompetition(
    @Param('id') id: string,
    @Body() body: { profileId: string; entryFee: number },
  ) {
    const participant = await this.competitionsService.joinCompetition(
      id,
      body.profileId,
      body.entryFee,
    );
    return { success: true, participant };
  }

  @Post(':id/start')
  async startCompetition(@Param('id') id: string) {
    const competition = await this.competitionsService.startCompetition(id);
    return { success: true, competition };
  }

  @Put(':id/score')
  async updateScore(
    @Param('id') id: string,
    @Body() body: { profileId: string; score: number },
  ) {
    const participant = await this.competitionsService.updateParticipantScore(
      id,
      body.profileId,
      body.score,
    );
    return { success: true, participant };
  }

  @Post(':id/support')
  async supportParticipant(
    @Param('id') id: string,
    @Body()
    body: {
      supporterProfileId: string;
      participantProfileId: string;
      amount: number;
      type: 'gift' | 'boost' | 'sponsor';
    },
  ) {
    const support = await this.competitionsService.supportParticipant(
      id,
      body.supporterProfileId,
      body.participantProfileId,
      body.amount,
      body.type,
    );
    return { success: true, support };
  }

  @Post(':id/complete')
  async completeCompetition(
    @Param('id') id: string,
    @Body() body: { winnerProfileId: string },
  ) {
    const competition = await this.competitionsService.completeCompetition(
      id,
      body.winnerProfileId,
    );
    return { success: true, competition };
  }

  @Get(':id/leaderboard')
  async getLeaderboard(@Param('id') id: string) {
    const leaderboard = await this.competitionsService.getLeaderboard(id);
    return { success: true, leaderboard };
  }

  @Get(':id/participant/:profileId/support')
  async getParticipantSupport(
    @Param('id') id: string,
    @Param('profileId') profileId: string,
  ) {
    const support = await this.competitionsService.getParticipantSupport(
      id,
      profileId,
    );
    return { success: true, ...support };
  }
}
