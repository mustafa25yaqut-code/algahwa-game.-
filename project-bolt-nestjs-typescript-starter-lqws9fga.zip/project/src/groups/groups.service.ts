import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface CreateGroupDto {
  groupName: string;
  ownerProfileId: string;
  groupAvatar?: string;
}

@Injectable()
export class GroupsService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async createGroup(dto: CreateGroupDto) {
    const { data: group, error: groupError } = await this.supabase
      .from('groups')
      .insert({
        group_name: dto.groupName,
        owner_profile_id: dto.ownerProfileId,
        group_avatar: dto.groupAvatar,
        creation_fee: 5.0,
        total_members: 1,
      })
      .select()
      .single();

    if (groupError) throw groupError;

    await this.supabase.from('group_members').insert({
      group_id: group.id,
      profile_id: dto.ownerProfileId,
      role: 'owner',
    });

    for (let i = 1; i <= 10; i++) {
      await this.supabase.from('group_voice_channels').insert({
        group_id: group.id,
        channel_number: i,
        is_active: false,
      });
    }

    return group;
  }

  async getGroup(groupId: string) {
    const { data, error } = await this.supabase
      .from('groups')
      .select(
        `
        *,
        owner:owner_profile_id(id, username, avatar_url, player_id),
        members:group_members(
          id,
          profile:profile_id(id, username, avatar_url, level, player_id),
          role,
          joined_at
        )
      `,
      )
      .eq('id', groupId)
      .single();

    if (error) throw error;
    return data;
  }

  async listGroups(limit: number = 20) {
    const { data, error } = await this.supabase
      .from('groups')
      .select(
        `
        *,
        owner:owner_profile_id(id, username, avatar_url)
      `,
      )
      .eq('status', 'active')
      .order('group_rank', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  }

  async updateGroup(groupId: string, updates: any) {
    const { data, error } = await this.supabase
      .from('groups')
      .update(updates)
      .eq('id', groupId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async sendJoinRequest(groupId: string, profileId: string) {
    const { data, error } = await this.supabase
      .from('group_join_requests')
      .insert({
        group_id: groupId,
        profile_id: profileId,
        status: 'pending',
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getPendingRequests(groupId: string) {
    const { data, error } = await this.supabase
      .from('group_join_requests')
      .select(
        `
        *,
        profile:profile_id(id, username, avatar_url, level, player_id)
      `,
      )
      .eq('group_id', groupId)
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  async acceptJoinRequest(requestId: string) {
    const { data: request, error: reqError } = await this.supabase
      .from('group_join_requests')
      .select('*')
      .eq('id', requestId)
      .single();

    if (reqError) throw reqError;

    await this.supabase
      .from('group_join_requests')
      .update({ status: 'accepted' })
      .eq('id', requestId);

    await this.supabase.from('group_members').insert({
      group_id: request.group_id,
      profile_id: request.profile_id,
      role: 'member',
    });

    await this.supabase.rpc('increment', {
      table_name: 'groups',
      row_id: request.group_id,
      column_name: 'total_members',
    });

    return { success: true };
  }

  async rejectJoinRequest(requestId: string) {
    const { error } = await this.supabase
      .from('group_join_requests')
      .update({ status: 'rejected' })
      .eq('id', requestId);

    if (error) throw error;
    return { success: true };
  }

  async kickMember(groupId: string, profileId: string) {
    const { error } = await this.supabase
      .from('group_members')
      .delete()
      .eq('group_id', groupId)
      .eq('profile_id', profileId);

    if (error) throw error;

    await this.supabase
      .from('groups')
      .update({ total_members: this.supabase.rpc('decrement') })
      .eq('id', groupId);

    return { success: true };
  }

  async getVoiceChannels(groupId: string) {
    const { data, error } = await this.supabase
      .from('group_voice_channels')
      .select(
        `
        *,
        profile:profile_id(id, username, avatar_url)
      `,
      )
      .eq('group_id', groupId)
      .order('channel_number', { ascending: true });

    if (error) throw error;
    return data;
  }

  async occupyVoiceChannel(
    groupId: string,
    channelNumber: number,
    profileId: string,
  ) {
    const { data, error } = await this.supabase
      .from('group_voice_channels')
      .update({
        profile_id: profileId,
        is_active: true,
        updated_at: new Date().toISOString(),
      })
      .eq('group_id', groupId)
      .eq('channel_number', channelNumber)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async leaveVoiceChannel(groupId: string, profileId: string) {
    const { error } = await this.supabase
      .from('group_voice_channels')
      .update({
        profile_id: null,
        is_active: false,
        updated_at: new Date().toISOString(),
      })
      .eq('group_id', groupId)
      .eq('profile_id', profileId);

    if (error) throw error;
    return { success: true };
  }

  async addMusicToQueue(
    groupId: string,
    musicUrl: string,
    musicTitle: string,
    profileId: string,
  ) {
    const { data, error } = await this.supabase
      .from('group_music_queue')
      .insert({
        group_id: groupId,
        music_url: musicUrl,
        music_title: musicTitle,
        requested_by_profile_id: profileId,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getMusicQueue(groupId: string) {
    const { data, error } = await this.supabase
      .from('group_music_queue')
      .select(
        `
        *,
        requested_by:requested_by_profile_id(id, username, avatar_url)
      `,
      )
      .eq('group_id', groupId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data;
  }
}
