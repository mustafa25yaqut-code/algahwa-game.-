import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
} from '@nestjs/common';
import { GroupsService } from './groups.service';

@Controller('groups')
export class GroupsController {
  constructor(private groupsService: GroupsService) {}

  @Post()
  async createGroup(
    @Body()
    body: {
      groupName: string;
      ownerProfileId: string;
      groupAvatar?: string;
    },
  ) {
    const group = await this.groupsService.createGroup(body);
    return { success: true, group };
  }

  @Get(':id')
  async getGroup(@Param('id') id: string) {
    const group = await this.groupsService.getGroup(id);
    return { success: true, group };
  }

  @Get()
  async listGroups(@Query('limit') limit?: number) {
    const groups = await this.groupsService.listGroups(limit);
    return { success: true, groups };
  }

  @Put(':id')
  async updateGroup(@Param('id') id: string, @Body() updates: any) {
    const group = await this.groupsService.updateGroup(id, updates);
    return { success: true, group };
  }

  @Post(':id/join-request')
  async sendJoinRequest(
    @Param('id') id: string,
    @Body() body: { profileId: string },
  ) {
    const request = await this.groupsService.sendJoinRequest(
      id,
      body.profileId,
    );
    return { success: true, request };
  }

  @Get(':id/requests')
  async getPendingRequests(@Param('id') id: string) {
    const requests = await this.groupsService.getPendingRequests(id);
    return { success: true, requests };
  }

  @Post('requests/:requestId/accept')
  async acceptRequest(@Param('requestId') requestId: string) {
    const result = await this.groupsService.acceptJoinRequest(requestId);
    return result;
  }

  @Post('requests/:requestId/reject')
  async rejectRequest(@Param('requestId') requestId: string) {
    const result = await this.groupsService.rejectJoinRequest(requestId);
    return result;
  }

  @Delete(':id/members/:profileId')
  async kickMember(
    @Param('id') id: string,
    @Param('profileId') profileId: string,
  ) {
    const result = await this.groupsService.kickMember(id, profileId);
    return result;
  }

  @Get(':id/voice-channels')
  async getVoiceChannels(@Param('id') id: string) {
    const channels = await this.groupsService.getVoiceChannels(id);
    return { success: true, channels };
  }

  @Post(':id/voice-channels/:channelNumber/occupy')
  async occupyChannel(
    @Param('id') id: string,
    @Param('channelNumber') channelNumber: number,
    @Body() body: { profileId: string },
  ) {
    const channel = await this.groupsService.occupyVoiceChannel(
      id,
      channelNumber,
      body.profileId,
    );
    return { success: true, channel };
  }

  @Post(':id/music')
  async addMusic(
    @Param('id') id: string,
    @Body()
    body: { musicUrl: string; musicTitle: string; profileId: string },
  ) {
    const music = await this.groupsService.addMusicToQueue(
      id,
      body.musicUrl,
      body.musicTitle,
      body.profileId,
    );
    return { success: true, music };
  }

  @Get(':id/music')
  async getMusicQueue(@Param('id') id: string) {
    const queue = await this.groupsService.getMusicQueue(id);
    return { success: true, queue };
  }
}
