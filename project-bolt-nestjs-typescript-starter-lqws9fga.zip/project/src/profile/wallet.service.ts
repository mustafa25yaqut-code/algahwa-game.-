import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class WalletService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async getWallet(userId: string) {
    const { data, error } = await this.supabase
      .from('user_wallets')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) throw new Error(error.message);

    if (!data) {
      const { data: newWallet } = await this.supabase
        .from('user_wallets')
        .insert({ user_id: userId, balance: 0 })
        .select()
        .single();
      return newWallet;
    }

    return data;
  }

  async createBet(
    gameId: string,
    gameType: string,
    betAmount: number,
    playerIds: string[],
  ) {
    if (betAmount === 0) {
      const { data } = await this.supabase
        .from('game_bets')
        .insert({
          game_id: gameId,
          game_type: gameType,
          bet_amount: 0,
          player1_id: playerIds[0],
          player2_id: playerIds[1] || null,
          player3_id: playerIds[2] || null,
          player4_id: playerIds[3] || null,
          status: 'active',
          total_pot: 0,
        })
        .select()
        .single();

      return data;
    }

    for (const playerId of playerIds) {
      const wallet = await this.getWallet(playerId);
      if (wallet.balance < betAmount) {
        throw new Error('Insufficient balance');
      }
    }

    for (const playerId of playerIds) {
      await this.supabase.rpc('deduct_coins', {
        p_user_id: playerId,
        p_amount: betAmount,
      });

      await this.supabase.from('transactions').insert({
        user_id: playerId,
        type: 'bet',
        amount: -betAmount,
        game_id: gameId,
        game_type: gameType,
        description: `رهان على لعبة ${gameType}`,
      });
    }

    const totalPot = betAmount * playerIds.length;

    const { data } = await this.supabase
      .from('game_bets')
      .insert({
        game_id: gameId,
        game_type: gameType,
        bet_amount: betAmount,
        player1_id: playerIds[0],
        player2_id: playerIds[1] || null,
        player3_id: playerIds[2] || null,
        player4_id: playerIds[3] || null,
        status: 'active',
        total_pot: totalPot,
      })
      .select()
      .single();

    return data;
  }

  async processPayout(gameId: string, winnerId: string) {
    const { data: bet } = await this.supabase
      .from('game_bets')
      .select('*')
      .eq('game_id', gameId)
      .single();

    if (!bet) throw new Error('Bet not found');
    if (bet.status === 'completed') throw new Error('Already paid out');

    if (bet.bet_amount === 0) {
      await this.supabase
        .from('game_bets')
        .update({ status: 'completed', winner_id: winnerId, completed_at: new Date().toISOString() })
        .eq('game_id', gameId);

      return { winner_payout: 0, commission: 0 };
    }

    const totalPot = bet.total_pot;
    const winnerPayout = Math.floor(totalPot * 0.75);
    const commission = totalPot - winnerPayout;

    await this.supabase.rpc('add_coins', {
      p_user_id: winnerId,
      p_amount: winnerPayout,
    });

    await this.supabase.from('transactions').insert({
      user_id: winnerId,
      type: 'win',
      amount: winnerPayout,
      game_id: gameId,
      game_type: bet.game_type,
      description: `فوز في لعبة ${bet.game_type}`,
    });

    await this.supabase
      .from('admin_wallet')
      .update({
        coins_revenue: this.supabase.rpc('increment_coins_revenue', { amount: commission }),
        updated_at: new Date().toISOString(),
      })
      .eq('id', (await this.supabase.from('admin_wallet').select('id').single()).data.id);

    await this.supabase
      .from('game_bets')
      .update({
        status: 'completed',
        winner_id: winnerId,
        winner_payout: winnerPayout,
        commission: commission,
        completed_at: new Date().toISOString(),
      })
      .eq('game_id', gameId);

    return { winner_payout: winnerPayout, commission };
  }

  async createPaymentOrder(userId: string, amountUsd: number) {
    const coinsAmount = Math.floor(amountUsd * 100);

    const { data } = await this.supabase
      .from('payment_orders')
      .insert({
        user_id: userId,
        amount_usd: amountUsd,
        coins_amount: coinsAmount,
        status: 'pending',
      })
      .select()
      .single();

    return data;
  }

  async completePayment(orderId: string, paymentId: string) {
    const { data: order } = await this.supabase
      .from('payment_orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (!order) throw new Error('Order not found');

    await this.supabase.rpc('add_coins', {
      p_user_id: order.user_id,
      p_amount: order.coins_amount,
    });

    await this.supabase.from('transactions').insert({
      user_id: order.user_id,
      type: 'purchase',
      amount: order.coins_amount,
      description: `شراء ${order.coins_amount} عملة مقابل $${order.amount_usd}`,
    });

    await this.supabase
      .from('payment_orders')
      .update({
        status: 'completed',
        payment_id: paymentId,
        completed_at: new Date().toISOString(),
      })
      .eq('id', orderId);

    const revenueAmount = order.amount_usd;
    await this.supabase
      .from('admin_wallet')
      .update({
        total_revenue: this.supabase.rpc('increment_revenue', { amount: revenueAmount }),
        updated_at: new Date().toISOString(),
      })
      .eq('id', (await this.supabase.from('admin_wallet').select('id').single()).data.id);

    return order;
  }

  async getTransactions(userId: string, limit = 50) {
    const { data, error } = await this.supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw new Error(error.message);
    return data || [];
  }

  async getAdminWallet() {
    const { data, error } = await this.supabase
      .from('admin_wallet')
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return data;
  }

  async getWithdrawalMethods(countryCode?: string) {
    let query = this.supabase
      .from('withdrawal_methods')
      .select('*')
      .eq('active', true);

    if (countryCode) {
      query = query.or(`country_code.eq.${countryCode},country_code.eq.GLOBAL`);
    }

    const { data, error } = await query.order('country_name');

    if (error) throw new Error(error.message);
    return data || [];
  }

  async createWithdrawalRequest(
    userId: string,
    amountCoins: number,
    methodId: string,
    accountDetails: any,
  ) {
    if (amountCoins < 1000) {
      throw new Error('الحد الأدنى للسحب هو 1000 عملة');
    }

    const wallet = await this.getWallet(userId);
    if (wallet.balance < amountCoins) {
      throw new Error('رصيدك غير كافٍ');
    }

    const amountUsd = amountCoins / 100;

    await this.supabase.rpc('deduct_coins', {
      p_user_id: userId,
      p_amount: amountCoins,
    });

    await this.supabase.from('transactions').insert({
      user_id: userId,
      type: 'commission',
      amount: -amountCoins,
      description: `طلب سحب ${amountCoins} عملة ($${amountUsd})`,
    });

    const { data } = await this.supabase
      .from('withdrawal_requests')
      .insert({
        user_id: userId,
        amount_coins: amountCoins,
        amount_usd: amountUsd,
        withdrawal_method_id: methodId,
        account_details: accountDetails,
        status: 'pending',
      })
      .select()
      .single();

    return data;
  }

  async getWithdrawalRequests(userId: string) {
    const { data, error } = await this.supabase
      .from('withdrawal_requests')
      .select('*, withdrawal_method:withdrawal_methods(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);
    return data || [];
  }

  async cancelWithdrawalRequest(userId: string, requestId: string) {
    const { data: request } = await this.supabase
      .from('withdrawal_requests')
      .select('*')
      .eq('id', requestId)
      .eq('user_id', userId)
      .single();

    if (!request) throw new Error('طلب السحب غير موجود');
    if (request.status !== 'pending') {
      throw new Error('لا يمكن إلغاء هذا الطلب');
    }

    await this.supabase.rpc('add_coins', {
      p_user_id: userId,
      p_amount: request.amount_coins,
    });

    await this.supabase.from('transactions').insert({
      user_id: userId,
      type: 'refund',
      amount: request.amount_coins,
      description: `إلغاء طلب سحب ${request.amount_coins} عملة`,
    });

    await this.supabase
      .from('withdrawal_requests')
      .update({ status: 'cancelled' })
      .eq('id', requestId);

    return { success: true };
  }
}
