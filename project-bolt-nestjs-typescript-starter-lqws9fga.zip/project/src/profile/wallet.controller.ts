import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { WalletService } from './wallet.service';

@Controller('wallet')
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Get(':userId')
  async getWallet(@Param('userId') userId: string) {
    return this.walletService.getWallet(userId);
  }

  @Post('bet')
  async createBet(
    @Body() body: { gameId: string; gameType: string; betAmount: number; playerIds: string[] },
  ) {
    return this.walletService.createBet(
      body.gameId,
      body.gameType,
      body.betAmount,
      body.playerIds,
    );
  }

  @Post('payout')
  async processPayout(@Body() body: { gameId: string; winnerId: string }) {
    return this.walletService.processPayout(body.gameId, body.winnerId);
  }

  @Post('payment/create')
  async createPayment(@Body() body: { userId: string; amountUsd: number }) {
    return this.walletService.createPaymentOrder(body.userId, body.amountUsd);
  }

  @Post('payment/complete')
  async completePayment(@Body() body: { orderId: string; paymentId: string }) {
    return this.walletService.completePayment(body.orderId, body.paymentId);
  }

  @Get(':userId/transactions')
  async getTransactions(@Param('userId') userId: string) {
    return this.walletService.getTransactions(userId);
  }

  @Get('admin/wallet')
  async getAdminWallet() {
    return this.walletService.getAdminWallet();
  }

  @Get('withdrawal-methods/:countryCode?')
  async getWithdrawalMethods(@Param('countryCode') countryCode?: string) {
    return this.walletService.getWithdrawalMethods(countryCode);
  }

  @Post('withdrawal/create')
  async createWithdrawal(
    @Body()
    body: {
      userId: string;
      amountCoins: number;
      methodId: string;
      accountDetails: any;
    },
  ) {
    return this.walletService.createWithdrawalRequest(
      body.userId,
      body.amountCoins,
      body.methodId,
      body.accountDetails,
    );
  }

  @Get(':userId/withdrawals')
  async getWithdrawals(@Param('userId') userId: string) {
    return this.walletService.getWithdrawalRequests(userId);
  }

  @Post('withdrawal/cancel')
  async cancelWithdrawal(@Body() body: { userId: string; requestId: string }) {
    return this.walletService.cancelWithdrawalRequest(body.userId, body.requestId);
  }
}
