export interface UserProfile {
  id: string;
  username: string;
  full_name: string;
  avatar_url?: string;
  birth_date?: string;
  country?: string;
  gender?: 'male' | 'female' | 'other';
  level: number;
  xp: number;
  bio?: string;
  created_at: Date;
  updated_at: Date;
}

export interface GameStatistics {
  id: string;
  user_id: string;
  game_type: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
  wins: number;
  losses: number;
  total_games: number;
  win_rate: number;
}

export interface Friendship {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: Date;
  updated_at: Date;
}

export interface Achievement {
  id: string;
  code: string;
  name: string;
  description: string;
  icon: string;
  xp_reward: number;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  unlocked_at: Date;
  achievement?: Achievement;
}

export interface UpdateProfileDto {
  full_name?: string;
  username?: string;
  avatar_url?: string;
  birth_date?: string;
  country?: string;
  gender?: 'male' | 'female' | 'other';
  bio?: string;
}

export interface SendFriendRequestDto {
  addressee_username: string;
}

export interface RespondFriendRequestDto {
  friendship_id: string;
  accept: boolean;
}

export interface UpdateGameStatsDto {
  user_id: string;
  game_type: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
  won: boolean;
}
