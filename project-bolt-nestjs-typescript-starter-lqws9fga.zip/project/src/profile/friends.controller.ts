import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
} from '@nestjs/common';
import { FriendsService } from './friends.service';

@Controller('friends')
export class FriendsController {
  constructor(private friendsService: FriendsService) {}

  @Get('search')
  async searchPlayer(@Query('playerId') playerId: string) {
    const player = await this.friendsService.searchPlayerById(playerId);
    return { success: true, player };
  }

  @Post('request')
  async sendFriendRequest(
    @Body() body: { senderProfileId: string; receiverProfileId: string },
  ) {
    const request = await this.friendsService.sendFriendRequest(
      body.senderProfileId,
      body.receiverProfileId,
    );
    return { success: true, request };
  }

  @Post('accept/:requestId')
  async acceptFriendRequest(@Param('requestId') requestId: string) {
    const result = await this.friendsService.acceptFriendRequest(requestId);
    return result;
  }

  @Post('reject/:requestId')
  async rejectFriendRequest(@Param('requestId') requestId: string) {
    const result = await this.friendsService.rejectFriendRequest(requestId);
    return result;
  }

  @Get('requests/:profileId')
  async getPendingRequests(@Param('profileId') profileId: string) {
    const requests = await this.friendsService.getPendingRequests(profileId);
    return { success: true, requests };
  }

  @Get('list/:profileId')
  async getFriendsList(@Param('profileId') profileId: string) {
    const friends = await this.friendsService.getFriendsList(profileId);
    return { success: true, friends };
  }

  @Delete(':friendshipId')
  async removeFriend(@Param('friendshipId') friendshipId: string) {
    const result = await this.friendsService.removeFriend(friendshipId);
    return result;
  }

  @Get('profile/:profileId')
  async getPlayerProfile(@Param('profileId') profileId: string) {
    const profile = await this.friendsService.getPlayerProfile(profileId);
    return { success: true, profile };
  }
}
