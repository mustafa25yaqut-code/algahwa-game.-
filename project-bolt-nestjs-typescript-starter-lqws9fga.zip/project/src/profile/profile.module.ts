import { Module } from '@nestjs/common';
import { ProfileController } from './profile.controller';
import { ProfileService } from './profile.service';
import { WalletController } from './wallet.controller';
import { WalletService } from './wallet.service';
import { FriendsController } from './friends.controller';
import { FriendsService } from './friends.service';

@Module({
  controllers: [ProfileController, WalletController, FriendsController],
  providers: [ProfileService, WalletService, FriendsService],
  exports: [ProfileService, WalletService, FriendsService],
})
export class ProfileModule {}
