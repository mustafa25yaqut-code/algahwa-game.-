import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  UserProfile,
  GameStatistics,
  Friendship,
  UserAchievement,
  UpdateProfileDto,
  SendFriendRequestDto,
  RespondFriendRequestDto,
  UpdateGameStatsDto,
} from './profile.types';

@Injectable()
export class ProfileService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async getProfile(userId: string): Promise<UserProfile> {
    const { data, error } = await this.supabase
      .from('user_profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) throw new Error('Profile not found');

    return data;
  }

  async getProfileByUsername(username: string): Promise<UserProfile> {
    const { data, error } = await this.supabase
      .from('user_profiles')
      .select('*')
      .eq('username', username)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) throw new Error('Profile not found');

    return data;
  }

  async updateProfile(userId: string, dto: UpdateProfileDto): Promise<UserProfile> {
    const { data, error } = await this.supabase
      .from('user_profiles')
      .update({ ...dto, updated_at: new Date().toISOString() })
      .eq('id', userId)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return data;
  }

  async getStatistics(userId: string): Promise<GameStatistics[]> {
    const { data, error } = await this.supabase
      .from('game_statistics')
      .select('*')
      .eq('user_id', userId);

    if (error) throw new Error(error.message);
    return data || [];
  }

  async updateGameStats(dto: UpdateGameStatsDto): Promise<void> {
    const { data: existing } = await this.supabase
      .from('game_statistics')
      .select('*')
      .eq('user_id', dto.user_id)
      .eq('game_type', dto.game_type)
      .maybeSingle();

    if (existing) {
      const wins = existing.wins + (dto.won ? 1 : 0);
      const losses = existing.losses + (dto.won ? 0 : 1);
      const total_games = existing.total_games + 1;
      const win_rate = (wins / total_games) * 100;

      await this.supabase
        .from('game_statistics')
        .update({
          wins,
          losses,
          total_games,
          win_rate,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existing.id);
    } else {
      await this.supabase.from('game_statistics').insert({
        user_id: dto.user_id,
        game_type: dto.game_type,
        wins: dto.won ? 1 : 0,
        losses: dto.won ? 0 : 1,
        total_games: 1,
        win_rate: dto.won ? 100 : 0,
      });
    }

    await this.addXP(dto.user_id, dto.won ? 20 : 5);
    await this.checkAchievements(dto.user_id);
  }

  async sendFriendRequest(userId: string, dto: SendFriendRequestDto): Promise<Friendship> {
    const { data: addressee } = await this.supabase
      .from('user_profiles')
      .select('id')
      .eq('username', dto.addressee_username)
      .maybeSingle();

    if (!addressee) throw new Error('User not found');

    const { data, error } = await this.supabase
      .from('friendships')
      .insert({
        requester_id: userId,
        addressee_id: addressee.id,
        status: 'pending',
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return data;
  }

  async respondFriendRequest(userId: string, dto: RespondFriendRequestDto): Promise<Friendship> {
    const { data, error } = await this.supabase
      .from('friendships')
      .update({
        status: dto.accept ? 'accepted' : 'rejected',
        updated_at: new Date().toISOString(),
      })
      .eq('id', dto.friendship_id)
      .eq('addressee_id', userId)
      .select()
      .single();

    if (error) throw new Error(error.message);

    if (dto.accept) {
      await this.checkAchievements(userId);
    }

    return data;
  }

  async getFriends(userId: string): Promise<UserProfile[]> {
    const { data: friendships, error } = await this.supabase
      .from('friendships')
      .select('requester_id, addressee_id')
      .or(`requester_id.eq.${userId},addressee_id.eq.${userId}`)
      .eq('status', 'accepted');

    if (error) throw new Error(error.message);

    const friendIds = friendships.map((f) =>
      f.requester_id === userId ? f.addressee_id : f.requester_id,
    );

    if (friendIds.length === 0) return [];

    const { data: friends } = await this.supabase
      .from('user_profiles')
      .select('*')
      .in('id', friendIds);

    return friends || [];
  }

  async getPendingRequests(userId: string): Promise<Friendship[]> {
    const { data, error } = await this.supabase
      .from('friendships')
      .select('*')
      .eq('addressee_id', userId)
      .eq('status', 'pending');

    if (error) throw new Error(error.message);
    return data || [];
  }

  async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    const { data, error } = await this.supabase
      .from('user_achievements')
      .select('*, achievement:achievements(*)')
      .eq('user_id', userId);

    if (error) throw new Error(error.message);
    return data || [];
  }

  async getSettings(userId: string): Promise<any> {
    const { data, error } = await this.supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) {
      const { data: newSettings } = await this.supabase
        .from('user_settings')
        .insert({ user_id: userId })
        .select()
        .single();
      return newSettings;
    }

    return data;
  }

  async updateSettings(userId: string, settings: any): Promise<any> {
    const { data, error } = await this.supabase
      .from('user_settings')
      .update({ ...settings, updated_at: new Date().toISOString() })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return data;
  }

  private async addXP(userId: string, xp: number): Promise<void> {
    const profile = await this.getProfile(userId);
    const newXP = profile.xp + xp;
    const newLevel = this.calculateLevel(newXP);

    await this.supabase
      .from('user_profiles')
      .update({
        xp: newXP,
        level: newLevel,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId);

    if (newLevel >= 10) await this.unlockAchievement(userId, 'level_10');
    if (newLevel >= 25) await this.unlockAchievement(userId, 'level_25');
    if (newLevel >= 50) await this.unlockAchievement(userId, 'level_50');
  }

  private calculateLevel(xp: number): number {
    return Math.floor(xp / 100) + 1;
  }

  private async checkAchievements(userId: string): Promise<void> {
    const stats = await this.getStatistics(userId);
    const friends = await this.getFriends(userId);

    const totalGames = stats.reduce((sum, s) => sum + s.total_games, 0);
    const totalWins = stats.reduce((sum, s) => sum + s.wins, 0);

    if (totalWins >= 1) await this.unlockAchievement(userId, 'first_win');
    if (totalGames >= 10) await this.unlockAchievement(userId, 'games_10');
    if (totalGames >= 50) await this.unlockAchievement(userId, 'games_50');
    if (totalGames >= 100) await this.unlockAchievement(userId, 'games_100');
    if (friends.length >= 5) await this.unlockAchievement(userId, 'friend_5');
    if (stats.length === 4) await this.unlockAchievement(userId, 'all_games');
  }

  private async unlockAchievement(userId: string, code: string): Promise<void> {
    const { data: achievement } = await this.supabase
      .from('achievements')
      .select('*')
      .eq('code', code)
      .maybeSingle();

    if (!achievement) return;

    const { data: existing } = await this.supabase
      .from('user_achievements')
      .select('*')
      .eq('user_id', userId)
      .eq('achievement_id', achievement.id)
      .maybeSingle();

    if (existing) return;

    await this.supabase.from('user_achievements').insert({
      user_id: userId,
      achievement_id: achievement.id,
    });

    await this.addXP(userId, achievement.xp_reward);
  }
}
