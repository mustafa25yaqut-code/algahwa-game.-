import { Controller, Get, Post, Put, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ProfileService } from './profile.service';
import type {
  UpdateProfileDto,
  SendFriendRequestDto,
  RespondFriendRequestDto,
} from './profile.types';

@Controller('profile')
export class ProfileController {
  constructor(private readonly profileService: ProfileService) {}

  @Get(':userId')
  async getProfile(@Param('userId') userId: string) {
    return this.profileService.getProfile(userId);
  }

  @Get('username/:username')
  async getProfileByUsername(@Param('username') username: string) {
    return this.profileService.getProfileByUsername(username);
  }

  @Put(':userId')
  async updateProfile(
    @Param('userId') userId: string,
    @Body() dto: UpdateProfileDto,
  ) {
    return this.profileService.updateProfile(userId, dto);
  }

  @Get(':userId/statistics')
  async getStatistics(@Param('userId') userId: string) {
    return this.profileService.getStatistics(userId);
  }

  @Get(':userId/friends')
  async getFriends(@Param('userId') userId: string) {
    return this.profileService.getFriends(userId);
  }

  @Get(':userId/friend-requests')
  async getPendingRequests(@Param('userId') userId: string) {
    return this.profileService.getPendingRequests(userId);
  }

  @Post(':userId/friend-request')
  async sendFriendRequest(
    @Param('userId') userId: string,
    @Body() dto: SendFriendRequestDto,
  ) {
    return this.profileService.sendFriendRequest(userId, dto);
  }

  @Put(':userId/friend-request')
  async respondFriendRequest(
    @Param('userId') userId: string,
    @Body() dto: RespondFriendRequestDto,
  ) {
    return this.profileService.respondFriendRequest(userId, dto);
  }

  @Get(':userId/achievements')
  async getUserAchievements(@Param('userId') userId: string) {
    return this.profileService.getUserAchievements(userId);
  }

  @Get(':userId/settings')
  async getSettings(@Param('userId') userId: string) {
    return this.profileService.getSettings(userId);
  }

  @Put(':userId/settings')
  async updateSettings(@Param('userId') userId: string, @Body() settings: any) {
    return this.profileService.updateSettings(userId, settings);
  }
}
