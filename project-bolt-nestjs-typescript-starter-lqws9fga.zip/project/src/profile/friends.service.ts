import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class FriendsService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async searchPlayerById(playerId: string) {
    const { data, error } = await this.supabase.rpc('search_player_by_id', {
      search_player_id: playerId,
    });

    if (error) throw error;
    return data && data.length > 0 ? data[0] : null;
  }

  async sendFriendRequest(senderProfileId: string, receiverProfileId: string) {
    const { data: existing } = await this.supabase
      .from('friend_requests')
      .select('*')
      .eq('sender_profile_id', senderProfileId)
      .eq('receiver_profile_id', receiverProfileId)
      .maybeSingle();

    if (existing) {
      throw new Error('Friend request already sent');
    }

    const { data: friendship } = await this.supabase
      .from('friendships')
      .select('*')
      .eq('requester_id', senderProfileId)
      .eq('addressee_id', receiverProfileId)
      .maybeSingle();

    if (friendship) {
      throw new Error('Already friends');
    }

    const { data, error } = await this.supabase
      .from('friend_requests')
      .insert({
        sender_profile_id: senderProfileId,
        receiver_profile_id: receiverProfileId,
        status: 'pending',
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async acceptFriendRequest(requestId: string) {
    const { error } = await this.supabase.rpc('accept_friend_request', {
      request_id: requestId,
    });

    if (error) throw error;
    return { success: true };
  }

  async rejectFriendRequest(requestId: string) {
    const { error } = await this.supabase
      .from('friend_requests')
      .update({ status: 'rejected' })
      .eq('id', requestId);

    if (error) throw error;
    return { success: true };
  }

  async getPendingRequests(profileId: string) {
    const { data, error } = await this.supabase
      .from('friend_requests')
      .select(
        `
        *,
        sender:sender_profile_id(id, username, avatar_url, level, player_id),
        receiver:receiver_profile_id(id, username, avatar_url, level, player_id)
      `,
      )
      .eq('receiver_profile_id', profileId)
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  async getFriendsList(profileId: string) {
    const { data, error } = await this.supabase
      .from('friendships')
      .select(
        `
        *,
        requester:requester_id(id, username, avatar_url, level, player_id),
        addressee:addressee_id(id, username, avatar_url, level, player_id)
      `,
      )
      .or(`requester_id.eq.${profileId},addressee_id.eq.${profileId}`)
      .eq('status', 'accepted')
      .order('created_at', { ascending: false });

    if (error) throw error;

    return data.map((friendship) => {
      const friend =
        friendship.requester.id === profileId
          ? friendship.addressee
          : friendship.requester;
      return {
        friendshipId: friendship.id,
        friend,
      };
    });
  }

  async removeFriend(friendshipId: string) {
    const { error } = await this.supabase
      .from('friendships')
      .delete()
      .eq('id', friendshipId);

    if (error) throw error;
    return { success: true };
  }

  async getPlayerProfile(profileId: string) {
    const { data, error } = await this.supabase
      .from('user_profiles')
      .select('id, username, avatar_url, level, player_id')
      .eq('id', profileId)
      .single();

    if (error) throw error;
    return data;
  }
}
