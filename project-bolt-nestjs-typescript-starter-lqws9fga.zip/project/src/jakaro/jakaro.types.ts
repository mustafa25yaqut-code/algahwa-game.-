export type CardSuit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type CardRank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  suit: CardSuit;
  rank: CardRank;
  id: string;
}

export interface JakaroPlayer {
  id: string;
  name: string;
  hand: Card[];
  collectedCards: Card[];
  score: number;
  isConnected: boolean;
  teamId?: string;
  socketId?: string;
}

export interface JakaroMove {
  playerId: string;
  card: Card;
  capturedCards?: Card[];
}

export interface JakaroGame {
  id: string;
  players: JakaroPlayer[];
  tableCards: Card[];
  deck: Card[];
  currentTurnIndex: number;
  round: number;
  status: 'waiting' | 'active' | 'finished';
  gameMode: 'single' | 'doubles';
  lastCapture?: string;
  winner?: string;
  createdAt: Date;
}

export interface CreateJakaroGameDto {
  playerName: string;
  gameMode?: 'single' | 'doubles';
}

export interface JoinJakaroGameDto {
  gameId: string;
  playerName: string;
}

export interface PlayJakaroCardDto {
  gameId: string;
  playerId: string;
  card: Card;
  capturedCards?: Card[];
}
