import { Module } from '@nestjs/common';
import { JakaroGateway } from './jakaro.gateway';
import { JakaroService } from './jakaro.service';

@Module({
  providers: [JakaroGateway, JakaroService],
})
export class JakaroModule {}
