import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JakaroService } from './jakaro.service';
import type {
  CreateJakaroGameDto,
  JoinJakaroGameDto,
  PlayJakaroCardDto,
} from './jakaro.types';

@WebSocketGateway({ cors: true })
export class JakaroGateway {
  @WebSocketServer()
  server: Server;

  constructor(private readonly jakaroService: JakaroService) {}

  @SubscribeMessage('jakaro:createGame')
  handleCreateGame(
    @MessageBody() dto: CreateJakaroGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.jakaroService.createGame(dto);
      client.join(game.id);
      client.emit('jakaro:gameCreated', { game, playerId: game.players[0].id });
      return { success: true, game };
    } catch (error) {
      client.emit('jakaro:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('jakaro:joinGame')
  handleJoinGame(
    @MessageBody() dto: JoinJakaroGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const { game, player } = this.jakaroService.joinGame(dto);
      client.join(game.id);

      this.server.to(game.id).emit('jakaro:playerJoined', { game, newPlayer: player });
      client.emit('jakaro:gameJoined', { game, playerId: player.id });

      if (game.status === 'active') {
        this.server.to(game.id).emit('jakaro:gameStarted', { game });
      }

      return { success: true, game, playerId: player.id };
    } catch (error) {
      client.emit('jakaro:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('jakaro:playCard')
  handlePlayCard(
    @MessageBody() dto: PlayJakaroCardDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.jakaroService.playCard(dto);
      this.server.to(game.id).emit('jakaro:cardPlayed', { game, move: dto });

      if (game.status === 'finished') {
        this.server.to(game.id).emit('jakaro:gameFinished', { game });
      }

      return { success: true, game };
    } catch (error) {
      client.emit('jakaro:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('jakaro:getGame')
  handleGetGame(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.jakaroService.getGame(data.gameId);
      return { success: true, game };
    } catch (error) {
      client.emit('jakaro:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }
}
