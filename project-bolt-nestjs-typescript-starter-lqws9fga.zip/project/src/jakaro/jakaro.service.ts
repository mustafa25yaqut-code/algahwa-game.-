import { Injectable } from '@nestjs/common';
import {
  JakaroGame,
  Card,
  JakaroPlayer,
  CreateJakaroGameDto,
  JoinJakaroGameDto,
  PlayJakaroCardDto,
  CardSuit,
  CardRank,
} from './jakaro.types';

@Injectable()
export class JakaroService {
  private games: Map<string, JakaroGame> = new Map();

  createGame(dto: CreateJakaroGameDto): JakaroGame {
    const gameId = this.generateGameId();
    const player: JakaroPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      hand: [],
      collectedCards: [],
      score: 0,
      isConnected: true,
    };

    const game: JakaroGame = {
      id: gameId,
      players: [player],
      tableCards: [],
      deck: [],
      currentTurnIndex: 0,
      round: 1,
      status: 'waiting',
      gameMode: dto.gameMode || 'single',
      createdAt: new Date(),
    };

    this.games.set(gameId, game);
    return game;
  }

  joinGame(dto: JoinJakaroGameDto): { game: JakaroGame; player: JakaroPlayer } {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    if (game.status !== 'waiting') {
      throw new Error('Game already started');
    }

    if (game.players.length >= 4) {
      throw new Error('Game is full');
    }

    const player: JakaroPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      hand: [],
      collectedCards: [],
      score: 0,
      isConnected: true,
    };

    game.players.push(player);

    if (game.players.length === 2) {
      this.startGame(game);
    }

    return { game, player };
  }

  private startGame(game: JakaroGame): void {
    game.deck = this.createDeck();
    this.shuffleDeck(game.deck);
    this.dealCards(game);
    game.status = 'active';
  }

  private createDeck(): Card[] {
    const suits: CardSuit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
    const ranks: CardRank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck: Card[] = [];

    for (const suit of suits) {
      for (const rank of ranks) {
        deck.push({
          suit,
          rank,
          id: `${suit}-${rank}`,
        });
      }
    }

    return deck;
  }

  private shuffleDeck(deck: Card[]): void {
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
  }

  private dealCards(game: JakaroGame): void {
    game.tableCards = game.deck.splice(0, 4);

    game.players.forEach((player) => {
      player.hand = game.deck.splice(0, 3);
    });
  }

  playCard(dto: PlayJakaroCardDto): JakaroGame {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    const player = game.players.find((p) => p.id === dto.playerId);
    if (!player) {
      throw new Error('Player not found');
    }

    if (game.players[game.currentTurnIndex].id !== dto.playerId) {
      throw new Error('Not your turn');
    }

    const cardIndex = player.hand.findIndex((c) => c.id === dto.card.id);
    if (cardIndex === -1) {
      throw new Error('Card not in hand');
    }

    player.hand.splice(cardIndex, 1);

    if (dto.capturedCards && dto.capturedCards.length > 0) {
      dto.capturedCards.forEach((capturedCard) => {
        const tableIndex = game.tableCards.findIndex((c) => c.id === capturedCard.id);
        if (tableIndex !== -1) {
          game.tableCards.splice(tableIndex, 1);
        }
      });

      player.collectedCards.push(dto.card, ...dto.capturedCards);
      game.lastCapture = player.id;

      this.calculateScore(player);
    } else {
      game.tableCards.push(dto.card);
    }

    const allHandsEmpty = game.players.every((p) => p.hand.length === 0);

    if (allHandsEmpty) {
      if (game.deck.length > 0) {
        game.players.forEach((p) => {
          p.hand = game.deck.splice(0, 3);
        });
        game.round++;
      } else {
        if (game.lastCapture) {
          const lastPlayer = game.players.find((p) => p.id === game.lastCapture);
          if (lastPlayer) {
            lastPlayer.collectedCards.push(...game.tableCards);
            game.tableCards = [];
            this.calculateScore(lastPlayer);
          }
        }

        game.status = 'finished';
        const winner = game.players.reduce((prev, current) =>
          prev.score > current.score ? prev : current,
        );
        game.winner = winner.id;
      }
    } else {
      game.currentTurnIndex = (game.currentTurnIndex + 1) % game.players.length;
    }

    return game;
  }

  private calculateScore(player: JakaroPlayer): void {
    let score = 0;

    const diamondsCount = player.collectedCards.filter((c) => c.suit === 'diamonds').length;
    if (diamondsCount >= 7) {
      score += 1;
    }

    const cardCount = player.collectedCards.length;
    if (cardCount >= 27) {
      score += 1;
    }

    const hasDiamond10 = player.collectedCards.some(
      (c) => c.suit === 'diamonds' && c.rank === '10',
    );
    if (hasDiamond10) {
      score += 2;
    }

    const hasClub2 = player.collectedCards.some((c) => c.suit === 'clubs' && c.rank === '2');
    if (hasClub2) {
      score += 1;
    }

    const aces = player.collectedCards.filter((c) => c.rank === 'A');
    score += aces.length;

    player.score = score;
  }

  getGame(gameId: string): JakaroGame {
    const game = this.games.get(gameId);
    if (!game) {
      throw new Error('Game not found');
    }
    return game;
  }

  private generateGameId(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  private generatePlayerId(): string {
    return Math.random().toString(36).substring(2, 15);
  }
}
