import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LudoModule } from './ludo/ludo.module';
import { DominoModule } from './domino/domino.module';
import { JakaroModule } from './jakaro/jakaro.module';
import { BackgammonModule } from './backgammon/backgammon.module';
import { ProfileModule } from './profile/profile.module';
import { VoiceModule } from './voice/voice.module';
import { ChatModule } from './chat/chat.module';
import { MusicModule } from './music/music.module';
import { GroupsModule } from './groups/groups.module';
import { MatchmakingModule } from './matchmaking/matchmaking.module';

@Module({
  imports: [
    LudoModule,
    DominoModule,
    JakaroModule,
    BackgammonModule,
    ProfileModule,
    VoiceModule,
    ChatModule,
    MusicModule,
    GroupsModule,
    MatchmakingModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
