import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface JoinQueueDto {
  profileId: string;
  gameType: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
  betAmount: number;
}

@Injectable()
export class MatchmakingService {
  private supabase: SupabaseClient;
  private matchmakingIntervals: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async joinQueue(dto: JoinQueueDto) {
    const { data: existingQueue } = await this.supabase
      .from('matchmaking_queue')
      .select('*')
      .eq('profile_id', dto.profileId)
      .eq('status', 'waiting')
      .maybeSingle();

    if (existingQueue) {
      throw new Error('Already in queue');
    }

    const { data: queueEntry, error } = await this.supabase
      .from('matchmaking_queue')
      .insert({
        profile_id: dto.profileId,
        game_type: dto.gameType,
        bet_amount: dto.betAmount,
        status: 'waiting',
      })
      .select()
      .single();

    if (error) throw error;

    this.startMatchmaking(queueEntry.id, dto.profileId, dto.gameType, dto.betAmount);

    return queueEntry;
  }

  private async startMatchmaking(
    queueId: string,
    profileId: string,
    gameType: string,
    betAmount: number,
  ) {
    const intervalId = setInterval(async () => {
      try {
        const { data: matchedQueueId } = await this.supabase.rpc('find_match', {
          p_profile_id: profileId,
          p_game_type: gameType,
          p_bet_amount: betAmount,
        });

        if (matchedQueueId) {
          const { data: sessionId } = await this.supabase.rpc(
            'create_game_session',
            {
              p_queue1_id: queueId,
              p_queue2_id: matchedQueueId,
            },
          );

          if (sessionId) {
            this.stopMatchmaking(queueId);
          }
        }
      } catch (error) {
        console.error('Matchmaking error:', error);
      }
    }, 2000);

    this.matchmakingIntervals.set(queueId, intervalId);

    setTimeout(() => {
      this.stopMatchmaking(queueId);
      this.cancelQueue(queueId);
    }, 300000);
  }

  private stopMatchmaking(queueId: string) {
    const intervalId = this.matchmakingIntervals.get(queueId);
    if (intervalId) {
      clearInterval(intervalId);
      this.matchmakingIntervals.delete(queueId);
    }
  }

  async cancelQueue(queueId: string) {
    const { error } = await this.supabase
      .from('matchmaking_queue')
      .update({ status: 'cancelled' })
      .eq('id', queueId)
      .eq('status', 'waiting');

    if (error) throw error;

    this.stopMatchmaking(queueId);

    return { success: true };
  }

  async getQueueStatus(profileId: string) {
    const { data, error } = await this.supabase
      .from('matchmaking_queue')
      .select('*')
      .eq('profile_id', profileId)
      .eq('status', 'waiting')
      .maybeSingle();

    if (error) throw error;

    if (!data) {
      return { inQueue: false };
    }

    const waitTime = Date.now() - new Date(data.created_at).getTime();

    return {
      inQueue: true,
      queueId: data.id,
      gameType: data.game_type,
      betAmount: data.bet_amount,
      waitTime: Math.floor(waitTime / 1000),
    };
  }

  async getMatchedSession(profileId: string) {
    const { data, error } = await this.supabase
      .from('matchmaking_queue')
      .select('game_session_id, matched_with_profile_id')
      .eq('profile_id', profileId)
      .eq('status', 'matched')
      .order('matched_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (!data || !data.game_session_id) {
      return null;
    }

    const { data: session, error: sessionError } = await this.supabase
      .from('game_sessions')
      .select(
        `
        *,
        player1:player1_profile_id(id, username, avatar_url, level, player_id),
        player2:player2_profile_id(id, username, avatar_url, level, player_id)
      `,
      )
      .eq('id', data.game_session_id)
      .single();

    if (sessionError) throw sessionError;

    return session;
  }

  async getGameSession(sessionId: string) {
    const { data, error } = await this.supabase
      .from('game_sessions')
      .select(
        `
        *,
        player1:player1_profile_id(id, username, avatar_url, level, player_id),
        player2:player2_profile_id(id, username, avatar_url, level, player_id)
      `,
      )
      .eq('id', sessionId)
      .single();

    if (error) throw error;
    return data;
  }

  async startGameSession(sessionId: string) {
    const { data, error } = await this.supabase
      .from('game_sessions')
      .update({
        status: 'in_progress',
        started_at: new Date().toISOString(),
      })
      .eq('id', sessionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async completeGameSession(sessionId: string, winnerProfileId: string) {
    const { data, error } = await this.supabase
      .from('game_sessions')
      .update({
        status: 'completed',
        winner_profile_id: winnerProfileId,
        completed_at: new Date().toISOString(),
      })
      .eq('id', sessionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateGameData(sessionId: string, gameData: any) {
    const { data, error } = await this.supabase
      .from('game_sessions')
      .update({ game_data: gameData })
      .eq('id', sessionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getQueueStats(gameType: string) {
    const { data, error } = await this.supabase.rpc('get_queue_stats', {
      p_game_type: gameType,
    });

    if (error) throw error;
    return data;
  }

  async cleanupOldQueues() {
    const { error } = await this.supabase.rpc('cleanup_old_queues');
    if (error) throw error;
    return { success: true };
  }

  async getAvailableBetAmounts(gameType: string) {
    const { data, error } = await this.supabase
      .from('matchmaking_queue')
      .select('bet_amount')
      .eq('game_type', gameType)
      .eq('status', 'waiting');

    if (error) throw error;

    const amounts = data.map((item) => item.bet_amount);
    const uniqueAmounts = [...new Set(amounts)];

    return uniqueAmounts.sort((a, b) => a - b);
  }
}
