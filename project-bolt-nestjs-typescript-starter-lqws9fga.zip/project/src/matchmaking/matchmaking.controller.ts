import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  Delete,
} from '@nestjs/common';
import { MatchmakingService } from './matchmaking.service';

@Controller('matchmaking')
export class MatchmakingController {
  constructor(private matchmakingService: MatchmakingService) {}

  @Post('join')
  async joinQueue(
    @Body()
    body: {
      profileId: string;
      gameType: 'ludo' | 'domino' | 'jakaro' | 'backgammon';
      betAmount: number;
    },
  ) {
    const queueEntry = await this.matchmakingService.joinQueue(body);
    return { success: true, queueEntry };
  }

  @Delete('cancel/:queueId')
  async cancelQueue(@Param('queueId') queueId: string) {
    const result = await this.matchmakingService.cancelQueue(queueId);
    return result;
  }

  @Get('status/:profileId')
  async getQueueStatus(@Param('profileId') profileId: string) {
    const status = await this.matchmakingService.getQueueStatus(profileId);
    return { success: true, ...status };
  }

  @Get('session/:profileId')
  async getMatchedSession(@Param('profileId') profileId: string) {
    const session = await this.matchmakingService.getMatchedSession(profileId);
    return { success: true, session };
  }

  @Get('game-session/:sessionId')
  async getGameSession(@Param('sessionId') sessionId: string) {
    const session = await this.matchmakingService.getGameSession(sessionId);
    return { success: true, session };
  }

  @Post('game-session/:sessionId/start')
  async startGameSession(@Param('sessionId') sessionId: string) {
    const session = await this.matchmakingService.startGameSession(sessionId);
    return { success: true, session };
  }

  @Post('game-session/:sessionId/complete')
  async completeGameSession(
    @Param('sessionId') sessionId: string,
    @Body() body: { winnerProfileId: string },
  ) {
    const session = await this.matchmakingService.completeGameSession(
      sessionId,
      body.winnerProfileId,
    );
    return { success: true, session };
  }

  @Post('game-session/:sessionId/update')
  async updateGameData(
    @Param('sessionId') sessionId: string,
    @Body() body: { gameData: any },
  ) {
    const session = await this.matchmakingService.updateGameData(
      sessionId,
      body.gameData,
    );
    return { success: true, session };
  }

  @Get('stats/:gameType')
  async getQueueStats(@Param('gameType') gameType: string) {
    const stats = await this.matchmakingService.getQueueStats(gameType);
    return { success: true, stats };
  }

  @Get('bet-amounts/:gameType')
  async getAvailableBetAmounts(@Param('gameType') gameType: string) {
    const amounts =
      await this.matchmakingService.getAvailableBetAmounts(gameType);
    return { success: true, amounts };
  }

  @Post('cleanup')
  async cleanupOldQueues() {
    const result = await this.matchmakingService.cleanupOldQueues();
    return result;
  }
}
