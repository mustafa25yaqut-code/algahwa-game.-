import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway({ cors: true, namespace: '/matchmaking' })
export class MatchmakingGateway {
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('joinMatchmaking')
  async handleJoinMatchmaking(
    @MessageBody()
    data: {
      profileId: string;
      gameType: string;
      betAmount: number;
    },
    @ConnectedSocket() client: Socket,
  ) {
    await client.join(`matchmaking-${data.gameType}-${data.betAmount}`);
    return { success: true };
  }

  @SubscribeMessage('leaveMatchmaking')
  async handleLeaveMatchmaking(
    @MessageBody() data: { gameType: string; betAmount: number },
    @ConnectedSocket() client: Socket,
  ) {
    await client.leave(`matchmaking-${data.gameType}-${data.betAmount}`);
    return { success: true };
  }

  notifyMatchFound(
    gameType: string,
    betAmount: number,
    sessionId: string,
    player1Id: string,
    player2Id: string,
  ) {
    this.server
      .to(`matchmaking-${gameType}-${betAmount}`)
      .emit('matchFound', {
        sessionId,
        player1Id,
        player2Id,
      });
  }

  notifyQueueUpdate(gameType: string, betAmount: number, waitingCount: number) {
    this.server
      .to(`matchmaking-${gameType}-${betAmount}`)
      .emit('queueUpdate', {
        waitingCount,
      });
  }
}
