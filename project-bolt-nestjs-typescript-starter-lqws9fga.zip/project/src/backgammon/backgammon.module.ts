import { Module } from '@nestjs/common';
import { BackgammonGateway } from './backgammon.gateway';
import { BackgammonService } from './backgammon.service';

@Module({
  providers: [BackgammonGateway, BackgammonService],
})
export class BackgammonModule {}
