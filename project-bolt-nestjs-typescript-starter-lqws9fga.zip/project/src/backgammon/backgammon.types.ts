export type PlayerColor = 'white' | 'black';

export interface Checker {
  color: PlayerColor;
  position: number;
}

export interface Point {
  position: number;
  checkers: PlayerColor[];
}

export interface Dice {
  die1: number;
  die2: number;
  used: boolean[];
}

export interface BackgammonPlayer {
  id: string;
  name: string;
  color: PlayerColor;
  checkers: number;
  bornOff: number;
  isConnected: boolean;
}

export interface Move {
  from: number;
  to: number;
  checker: PlayerColor;
}

export interface BackgammonGame {
  id: string;
  players: BackgammonPlayer[];
  board: Point[];
  dice: Dice | null;
  currentTurnColor: PlayerColor;
  bar: { white: number; black: number };
  status: 'waiting' | 'active' | 'finished';
  winner?: string;
  createdAt: Date;
}

export interface CreateBackgammonGameDto {
  playerName: string;
}

export interface JoinBackgammonGameDto {
  gameId: string;
  playerName: string;
}

export interface RollDiceDto {
  gameId: string;
  playerId: string;
}

export interface MovePieceDto {
  gameId: string;
  playerId: string;
  from: number;
  to: number;
}
