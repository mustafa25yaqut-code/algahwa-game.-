import { Injectable } from '@nestjs/common';
import {
  BackgammonGame,
  BackgammonPlayer,
  Point,
  PlayerColor,
  CreateBackgammonGameDto,
  JoinBackgammonGameDto,
  RollDiceDto,
  MovePieceDto,
} from './backgammon.types';

@Injectable()
export class BackgammonService {
  private games: Map<string, BackgammonGame> = new Map();

  createGame(dto: CreateBackgammonGameDto): BackgammonGame {
    const gameId = this.generateGameId();
    const player: BackgammonPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      color: 'white',
      checkers: 15,
      bornOff: 0,
      isConnected: true,
    };

    const game: BackgammonGame = {
      id: gameId,
      players: [player],
      board: this.initializeBoard(),
      dice: null,
      currentTurnColor: 'white',
      bar: { white: 0, black: 0 },
      status: 'waiting',
      createdAt: new Date(),
    };

    this.games.set(gameId, game);
    return game;
  }

  joinGame(dto: JoinBackgammonGameDto): { game: BackgammonGame; player: BackgammonPlayer } {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    if (game.status !== 'waiting') {
      throw new Error('Game already started');
    }

    if (game.players.length >= 2) {
      throw new Error('Game is full');
    }

    const player: BackgammonPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      color: 'black',
      checkers: 15,
      bornOff: 0,
      isConnected: true,
    };

    game.players.push(player);
    game.status = 'active';

    return { game, player };
  }

  private initializeBoard(): Point[] {
    const board: Point[] = [];

    for (let i = 0; i < 24; i++) {
      board.push({ position: i, checkers: [] });
    }

    board[0].checkers = Array(2).fill('white');
    board[5].checkers = Array(5).fill('black');
    board[7].checkers = Array(3).fill('black');
    board[11].checkers = Array(5).fill('white');
    board[12].checkers = Array(5).fill('black');
    board[16].checkers = Array(3).fill('white');
    board[18].checkers = Array(5).fill('white');
    board[23].checkers = Array(2).fill('black');

    return board;
  }

  rollDice(dto: RollDiceDto): BackgammonGame {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    const player = game.players.find((p) => p.id === dto.playerId);
    if (!player) {
      throw new Error('Player not found');
    }

    if (player.color !== game.currentTurnColor) {
      throw new Error('Not your turn');
    }

    if (game.dice && game.dice.used.some((u) => !u)) {
      throw new Error('Must use current dice before rolling again');
    }

    const die1 = Math.floor(Math.random() * 6) + 1;
    const die2 = Math.floor(Math.random() * 6) + 1;

    if (die1 === die2) {
      game.dice = {
        die1,
        die2,
        used: [false, false, false, false],
      };
    } else {
      game.dice = {
        die1,
        die2,
        used: [false, false],
      };
    }

    return game;
  }

  movePiece(dto: MovePieceDto): BackgammonGame {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    const player = game.players.find((p) => p.id === dto.playerId);
    if (!player) {
      throw new Error('Player not found');
    }

    if (player.color !== game.currentTurnColor) {
      throw new Error('Not your turn');
    }

    if (!game.dice) {
      throw new Error('Roll dice first');
    }

    if (!this.isValidMove(game, dto.from, dto.to, player.color)) {
      throw new Error('Invalid move');
    }

    this.executeMove(game, dto.from, dto.to, player.color);

    const diceValue = Math.abs(dto.to - dto.from);
    const diceIndex = game.dice.used.findIndex(
      (used, idx) =>
        !used &&
        (game.dice.die1 === diceValue || game.dice.die2 === diceValue ||
         (game.dice.die1 === game.dice.die2 && game.dice.die1 === diceValue)),
    );

    if (diceIndex !== -1) {
      game.dice.used[diceIndex] = true;
    }

    if (game.dice.used.every((u) => u)) {
      game.dice = null;
      game.currentTurnColor = game.currentTurnColor === 'white' ? 'black' : 'white';
    }

    if (player.bornOff === 15) {
      game.status = 'finished';
      game.winner = player.id;
    }

    return game;
  }

  private isValidMove(
    game: BackgammonGame,
    from: number,
    to: number,
    color: PlayerColor,
  ): boolean {
    if (from < -1 || from >= 24 || to < 0 || to > 24) {
      return false;
    }

    if (from === -1) {
      const barCount = game.bar[color];
      if (barCount === 0) {
        return false;
      }
    } else {
      const fromPoint = game.board[from];
      if (!fromPoint.checkers.length || fromPoint.checkers[fromPoint.checkers.length - 1] !== color) {
        return false;
      }
    }

    if (to === 24) {
      return this.canBearOff(game, color);
    }

    const toPoint = game.board[to];
    if (toPoint.checkers.length > 0 && toPoint.checkers[0] !== color) {
      if (toPoint.checkers.length > 1) {
        return false;
      }
    }

    const diceValue = Math.abs(to - from);
    if (!game.dice) return false;

    const hasMatchingDie = game.dice.used.some(
      (used, idx) =>
        !used &&
        (game.dice.die1 === diceValue || game.dice.die2 === diceValue ||
         (game.dice.die1 === game.dice.die2 && game.dice.die1 === diceValue)),
    );

    return hasMatchingDie;
  }

  private executeMove(
    game: BackgammonGame,
    from: number,
    to: number,
    color: PlayerColor,
  ): void {
    if (from === -1) {
      game.bar[color]--;
    } else {
      const fromPoint = game.board[from];
      fromPoint.checkers.pop();
    }

    if (to === 24) {
      const player = game.players.find((p) => p.color === color);
      if (player) {
        player.bornOff++;
        player.checkers--;
      }
    } else {
      const toPoint = game.board[to];

      if (toPoint.checkers.length === 1 && toPoint.checkers[0] !== color) {
        const hitColor = toPoint.checkers[0];
        toPoint.checkers = [];
        game.bar[hitColor]++;
      }

      toPoint.checkers.push(color);
    }
  }

  private canBearOff(game: BackgammonGame, color: PlayerColor): boolean {
    const homeStart = color === 'white' ? 18 : 0;
    const homeEnd = color === 'white' ? 24 : 6;

    if (game.bar[color] > 0) {
      return false;
    }

    for (let i = 0; i < 24; i++) {
      if (color === 'white' && i < homeStart) {
        if (game.board[i].checkers.some((c) => c === color)) {
          return false;
        }
      } else if (color === 'black' && i >= homeEnd) {
        if (game.board[i].checkers.some((c) => c === color)) {
          return false;
        }
      }
    }

    return true;
  }

  getGame(gameId: string): BackgammonGame {
    const game = this.games.get(gameId);
    if (!game) {
      throw new Error('Game not found');
    }
    return game;
  }

  private generateGameId(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  private generatePlayerId(): string {
    return Math.random().toString(36).substring(2, 15);
  }
}
