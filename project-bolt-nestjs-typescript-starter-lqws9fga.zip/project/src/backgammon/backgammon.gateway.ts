import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { BackgammonService } from './backgammon.service';
import type {
  CreateBackgammonGameDto,
  JoinBackgammonGameDto,
  RollDiceDto,
  MovePieceDto,
} from './backgammon.types';

@WebSocketGateway({ cors: true })
export class BackgammonGateway {
  @WebSocketServer()
  server: Server;

  constructor(private readonly backgammonService: BackgammonService) {}

  @SubscribeMessage('backgammon:createGame')
  handleCreateGame(
    @MessageBody() dto: CreateBackgammonGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.backgammonService.createGame(dto);
      client.join(game.id);
      client.emit('backgammon:gameCreated', { game, playerId: game.players[0].id });
      return { success: true, game };
    } catch (error) {
      client.emit('backgammon:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('backgammon:joinGame')
  handleJoinGame(
    @MessageBody() dto: JoinBackgammonGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const { game, player } = this.backgammonService.joinGame(dto);
      client.join(game.id);

      this.server.to(game.id).emit('backgammon:playerJoined', { game, newPlayer: player });
      client.emit('backgammon:gameJoined', { game, playerId: player.id });
      this.server.to(game.id).emit('backgammon:gameStarted', { game });

      return { success: true, game, playerId: player.id };
    } catch (error) {
      client.emit('backgammon:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('backgammon:rollDice')
  handleRollDice(
    @MessageBody() dto: RollDiceDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.backgammonService.rollDice(dto);
      this.server.to(game.id).emit('backgammon:diceRolled', { game });
      return { success: true, game };
    } catch (error) {
      client.emit('backgammon:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('backgammon:movePiece')
  handleMovePiece(
    @MessageBody() dto: MovePieceDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.backgammonService.movePiece(dto);
      this.server.to(game.id).emit('backgammon:pieceMoved', { game, move: dto });

      if (game.status === 'finished') {
        this.server.to(game.id).emit('backgammon:gameFinished', { game });
      }

      return { success: true, game };
    } catch (error) {
      client.emit('backgammon:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('backgammon:getGame')
  handleGetGame(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.backgammonService.getGame(data.gameId);
      return { success: true, game };
    } catch (error) {
      client.emit('backgammon:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }
}
