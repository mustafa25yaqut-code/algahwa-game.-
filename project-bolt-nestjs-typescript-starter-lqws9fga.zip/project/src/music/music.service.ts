import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface StartMusicDto {
  gameId: string;
  teamId?: string;
  musicUrl: string;
  musicTitle?: string;
  startedByPlayerId: string;
  startedByPlayerName: string;
}

@Injectable()
export class MusicService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async startMusic(dto: StartMusicDto) {
    await this.stopAllMusicInGame(dto.gameId, dto.teamId);

    const { data, error } = await this.supabase
      .from('game_music')
      .insert({
        game_id: dto.gameId,
        team_id: dto.teamId,
        music_url: dto.musicUrl,
        music_title: dto.musicTitle,
        is_playing: true,
        started_by_player_id: dto.startedByPlayerId,
        started_by_player_name: dto.startedByPlayerName,
        playback_time: 0,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getCurrentMusic(gameId: string, teamId?: string) {
    let query = this.supabase
      .from('game_music')
      .select('*')
      .eq('game_id', gameId)
      .eq('is_playing', true);

    if (teamId) {
      query = query.eq('team_id', teamId);
    }

    const { data, error } = await query.maybeSingle();

    if (error) throw error;
    return data;
  }

  async updateMusicStatus(musicId: string, isPlaying: boolean) {
    const { error } = await this.supabase
      .from('game_music')
      .update({ is_playing: isPlaying })
      .eq('id', musicId);

    if (error) throw error;
  }

  async updateMusicTime(musicId: string, time: number) {
    const { error } = await this.supabase
      .from('game_music')
      .update({ playback_time: time })
      .eq('id', musicId);

    if (error) throw error;
  }

  async stopMusic(musicId: string) {
    const { error } = await this.supabase
      .from('game_music')
      .delete()
      .eq('id', musicId);

    if (error) throw error;
  }

  async stopAllMusicInGame(gameId: string, teamId?: string) {
    let query = this.supabase
      .from('game_music')
      .delete()
      .eq('game_id', gameId);

    if (teamId) {
      query = query.eq('team_id', teamId);
    }

    const { error } = await query;

    if (error && error.code !== 'PGRST116') throw error;
  }
}
