import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { MusicService } from './music.service';

@WebSocketGateway({ cors: true, namespace: '/music' })
export class MusicGateway {
  @WebSocketServer()
  server: Server;

  constructor(private musicService: MusicService) {}

  @SubscribeMessage('joinMusicRoom')
  async handleJoinMusicRoom(
    @MessageBody() data: { gameId: string; teamId?: string },
    @ConnectedSocket() client: Socket,
  ) {
    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;
    await client.join(room);

    const currentMusic = await this.musicService.getCurrentMusic(
      data.gameId,
      data.teamId,
    );

    return { success: true, currentMusic };
  }

  @SubscribeMessage('playMusic')
  async handlePlayMusic(
    @MessageBody()
    data: {
      gameId: string;
      teamId?: string;
      musicUrl: string;
      musicTitle?: string;
      playerId: string;
      playerName: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const music = await this.musicService.startMusic({
      gameId: data.gameId,
      teamId: data.teamId,
      musicUrl: data.musicUrl,
      musicTitle: data.musicTitle,
      startedByPlayerId: data.playerId,
      startedByPlayerName: data.playerName,
    });

    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;

    this.server.to(room).emit('musicStarted', music);

    return { success: true, music };
  }

  @SubscribeMessage('pauseMusic')
  async handlePauseMusic(
    @MessageBody() data: { gameId: string; teamId?: string; musicId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await this.musicService.updateMusicStatus(data.musicId, false);

    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;

    this.server.to(room).emit('musicPaused', { musicId: data.musicId });

    return { success: true };
  }

  @SubscribeMessage('resumeMusic')
  async handleResumeMusic(
    @MessageBody() data: { gameId: string; teamId?: string; musicId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await this.musicService.updateMusicStatus(data.musicId, true);

    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;

    this.server.to(room).emit('musicResumed', { musicId: data.musicId });

    return { success: true };
  }

  @SubscribeMessage('stopMusic')
  async handleStopMusic(
    @MessageBody() data: { gameId: string; teamId?: string; musicId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await this.musicService.stopMusic(data.musicId);

    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;

    this.server.to(room).emit('musicStopped', { musicId: data.musicId });

    return { success: true };
  }

  @SubscribeMessage('updateMusicTime')
  async handleUpdateMusicTime(
    @MessageBody()
    data: { gameId: string; teamId?: string; musicId: string; time: number },
    @ConnectedSocket() client: Socket,
  ) {
    await this.musicService.updateMusicTime(data.musicId, data.time);

    const room = data.teamId
      ? `music-${data.gameId}-${data.teamId}`
      : `music-${data.gameId}`;

    this.server.to(room).emit('musicTimeUpdated', {
      musicId: data.musicId,
      time: data.time,
    });

    return { success: true };
  }
}
