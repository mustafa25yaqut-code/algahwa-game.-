import { Module } from '@nestjs/common';
import { MusicGateway } from './music.gateway';
import { MusicService } from './music.service';

@Module({
  providers: [MusicGateway, MusicService],
  exports: [MusicService],
})
export class MusicModule {}
