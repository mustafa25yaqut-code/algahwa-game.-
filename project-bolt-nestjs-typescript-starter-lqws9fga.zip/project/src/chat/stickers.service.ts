import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface SendStickerDto {
  gameId: string;
  senderId: string;
  senderName: string;
  stickerType: string;
  targetId?: string;
  targetName?: string;
}

interface SendGiftDto {
  gameId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  giftType: string;
}

@Injectable()
export class StickersService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async sendSticker(dto: SendStickerDto) {
    const { data, error } = await this.supabase
      .from('game_stickers')
      .insert({
        game_id: dto.gameId,
        sender_id: dto.senderId,
        sender_name: dto.senderName,
        sticker_type: dto.stickerType,
        target_id: dto.targetId,
        target_name: dto.targetName,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getGameStickers(gameId: string, limit: number = 50) {
    const { data, error } = await this.supabase
      .from('game_stickers')
      .select('*')
      .eq('game_id', gameId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data;
  }

  async sendGift(dto: SendGiftDto) {
    const { data, error } = await this.supabase
      .from('game_gifts')
      .insert({
        game_id: dto.gameId,
        sender_id: dto.senderId,
        sender_name: dto.senderName,
        receiver_id: dto.receiverId,
        receiver_name: dto.receiverName,
        gift_type: dto.giftType,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getPlayerGifts(playerId: string, gameId: string) {
    const { data, error } = await this.supabase
      .from('game_gifts')
      .select('*')
      .eq('game_id', gameId)
      .eq('receiver_id', playerId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }
}
