import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

interface SaveMessageDto {
  gameId: string;
  playerId: string;
  playerName: string;
  messageType: 'public' | 'team';
  messageContent: string;
  teamId?: string;
}

@Injectable()
export class ChatService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async saveMessage(dto: SaveMessageDto) {
    const { data, error } = await this.supabase
      .from('game_messages')
      .insert({
        game_id: dto.gameId,
        player_id: dto.playerId,
        player_name: dto.playerName,
        message_type: dto.messageType,
        message_content: dto.messageContent,
        team_id: dto.teamId,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getGameMessages(gameId: string, limit: number = 100) {
    const { data, error } = await this.supabase
      .from('game_messages')
      .select('*')
      .eq('game_id', gameId)
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data;
  }

  async getPublicMessages(gameId: string, limit: number = 100) {
    const { data, error } = await this.supabase
      .from('game_messages')
      .select('*')
      .eq('game_id', gameId)
      .eq('message_type', 'public')
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data;
  }

  async getTeamMessages(gameId: string, teamId: string, limit: number = 100) {
    const { data, error } = await this.supabase
      .from('game_messages')
      .select('*')
      .eq('game_id', gameId)
      .eq('team_id', teamId)
      .eq('message_type', 'team')
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data;
  }
}
