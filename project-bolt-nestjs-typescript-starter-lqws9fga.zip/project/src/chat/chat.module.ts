import { Module } from '@nestjs/common';
import { ChatGateway } from './chat.gateway';
import { ChatService } from './chat.service';
import { StickersGateway } from './stickers.gateway';
import { StickersService } from './stickers.service';

@Module({
  providers: [ChatGateway, ChatService, StickersGateway, StickersService],
  exports: [ChatService, StickersService],
})
export class ChatModule {}
