import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { ChatService } from './chat.service';

@WebSocketGateway({ cors: true, namespace: '/chat' })
export class ChatGateway {
  @WebSocketServer()
  server: Server;

  constructor(private chatService: ChatService) {}

  @SubscribeMessage('joinChatRoom')
  async handleJoinChatRoom(
    @MessageBody() data: { gameId: string; playerId: string; teamId?: string },
    @ConnectedSocket() client: Socket,
  ) {
    await client.join(`chat-${data.gameId}`);
    if (data.teamId) {
      await client.join(`team-${data.gameId}-${data.teamId}`);
    }

    const messages = await this.chatService.getGameMessages(data.gameId);

    return { success: true, messages };
  }

  @SubscribeMessage('sendPublicMessage')
  async handlePublicMessage(
    @MessageBody()
    data: {
      gameId: string;
      playerId: string;
      playerName: string;
      message: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const savedMessage = await this.chatService.saveMessage({
      gameId: data.gameId,
      playerId: data.playerId,
      playerName: data.playerName,
      messageType: 'public',
      messageContent: data.message,
    });

    this.server.to(`chat-${data.gameId}`).emit('newMessage', savedMessage);

    return { success: true, message: savedMessage };
  }

  @SubscribeMessage('sendTeamMessage')
  async handleTeamMessage(
    @MessageBody()
    data: {
      gameId: string;
      playerId: string;
      playerName: string;
      teamId: string;
      message: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const savedMessage = await this.chatService.saveMessage({
      gameId: data.gameId,
      playerId: data.playerId,
      playerName: data.playerName,
      messageType: 'team',
      messageContent: data.message,
      teamId: data.teamId,
    });

    this.server
      .to(`team-${data.gameId}-${data.teamId}`)
      .emit('newTeamMessage', savedMessage);

    return { success: true, message: savedMessage };
  }

  @SubscribeMessage('getMessages')
  async handleGetMessages(
    @MessageBody() data: { gameId: string; limit?: number },
    @ConnectedSocket() client: Socket,
  ) {
    const messages = await this.chatService.getGameMessages(
      data.gameId,
      data.limit,
    );

    return { success: true, messages };
  }
}
