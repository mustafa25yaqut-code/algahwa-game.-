import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { StickersService } from './stickers.service';

@WebSocketGateway({ cors: true, namespace: '/stickers' })
export class StickersGateway {
  @WebSocketServer()
  server: Server;

  constructor(private stickersService: StickersService) {}

  @SubscribeMessage('joinStickerRoom')
  async handleJoinStickerRoom(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await client.join(`stickers-${data.gameId}`);
    return { success: true };
  }

  @SubscribeMessage('sendSticker')
  async handleSendSticker(
    @MessageBody()
    data: {
      gameId: string;
      senderId: string;
      senderName: string;
      stickerType: string;
      targetId?: string;
      targetName?: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const sticker = await this.stickersService.sendSticker({
      gameId: data.gameId,
      senderId: data.senderId,
      senderName: data.senderName,
      stickerType: data.stickerType,
      targetId: data.targetId,
      targetName: data.targetName,
    });

    this.server.to(`stickers-${data.gameId}`).emit('newSticker', sticker);

    return { success: true, sticker };
  }

  @SubscribeMessage('sendQuickMessage')
  async handleSendQuickMessage(
    @MessageBody()
    data: {
      gameId: string;
      senderId: string;
      senderName: string;
      messageType: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const sticker = await this.stickersService.sendSticker({
      gameId: data.gameId,
      senderId: data.senderId,
      senderName: data.senderName,
      stickerType: data.messageType,
    });

    this.server.to(`stickers-${data.gameId}`).emit('newQuickMessage', sticker);

    return { success: true, sticker };
  }

  @SubscribeMessage('sendGift')
  async handleSendGift(
    @MessageBody()
    data: {
      gameId: string;
      senderId: string;
      senderName: string;
      receiverId: string;
      receiverName: string;
      giftType: string;
    },
    @ConnectedSocket() client: Socket,
  ) {
    const gift = await this.stickersService.sendGift({
      gameId: data.gameId,
      senderId: data.senderId,
      senderName: data.senderName,
      receiverId: data.receiverId,
      receiverName: data.receiverName,
      giftType: data.giftType,
    });

    this.server.to(`stickers-${data.gameId}`).emit('newGift', gift);

    return { success: true, gift };
  }
}
