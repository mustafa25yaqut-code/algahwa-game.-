import { Injectable } from '@nestjs/common';
import {
  DominoGame,
  DominoTile,
  DominoPlayer,
  CreateDominoGameDto,
  JoinDominoGameDto,
  PlayDominoTileDto,
  DrawDominoTileDto,
} from './domino.types';

@Injectable()
export class DominoService {
  private games: Map<string, DominoGame> = new Map();

  createGame(dto: CreateDominoGameDto): DominoGame {
    const gameId = this.generateGameId();
    const player: DominoPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      hand: [],
      isConnected: true,
    };

    const game: DominoGame = {
      id: gameId,
      players: [player],
      board: { tiles: [], leftEnd: -1, rightEnd: -1 },
      currentTurnIndex: 0,
      boneyard: [],
      status: 'waiting',
      createdAt: new Date(),
    };

    this.games.set(gameId, game);
    return game;
  }

  joinGame(dto: JoinDominoGameDto): { game: DominoGame; player: DominoPlayer } {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    if (game.status !== 'waiting') {
      throw new Error('Game already started');
    }

    if (game.players.length >= 4) {
      throw new Error('Game is full');
    }

    const player: DominoPlayer = {
      id: this.generatePlayerId(),
      name: dto.playerName,
      hand: [],
      isConnected: true,
    };

    game.players.push(player);

    if (game.players.length === 2) {
      this.startGame(game);
    }

    return { game, player };
  }

  private startGame(game: DominoGame): void {
    game.boneyard = this.createDominoSet();
    this.shuffleTiles(game.boneyard);

    const tilesPerPlayer = game.players.length === 2 ? 7 : 5;

    game.players.forEach((player) => {
      player.hand = game.boneyard.splice(0, tilesPerPlayer);
    });

    game.status = 'active';
  }

  private createDominoSet(): DominoTile[] {
    const tiles: DominoTile[] = [];
    for (let top = 0; top <= 6; top++) {
      for (let bottom = top; bottom <= 6; bottom++) {
        tiles.push({
          top,
          bottom,
          id: `${top}-${bottom}`,
        });
      }
    }
    return tiles;
  }

  private shuffleTiles(tiles: DominoTile[]): void {
    for (let i = tiles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
    }
  }

  playTile(dto: PlayDominoTileDto): DominoGame {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    const player = game.players.find((p) => p.id === dto.playerId);
    if (!player) {
      throw new Error('Player not found');
    }

    if (game.players[game.currentTurnIndex].id !== dto.playerId) {
      throw new Error('Not your turn');
    }

    const tileIndex = player.hand.findIndex((t) => t.id === dto.tile.id);
    if (tileIndex === -1) {
      throw new Error('Tile not in hand');
    }

    if (!this.canPlayTile(game, dto.tile, dto.position)) {
      throw new Error('Invalid move');
    }

    player.hand.splice(tileIndex, 1);

    if (game.board.tiles.length === 0) {
      game.board.tiles.push(dto.tile);
      game.board.leftEnd = dto.tile.top;
      game.board.rightEnd = dto.tile.bottom;
    } else {
      this.placeTileOnBoard(game, dto.tile, dto.position);
    }

    if (player.hand.length === 0) {
      game.status = 'finished';
      game.winner = player.id;
    } else {
      game.currentTurnIndex = (game.currentTurnIndex + 1) % game.players.length;
    }

    return game;
  }

  private canPlayTile(
    game: DominoGame,
    tile: DominoTile,
    position: 'left' | 'right',
  ): boolean {
    if (game.board.tiles.length === 0) {
      return true;
    }

    const targetEnd = position === 'left' ? game.board.leftEnd : game.board.rightEnd;
    return tile.top === targetEnd || tile.bottom === targetEnd;
  }

  private placeTileOnBoard(
    game: DominoGame,
    tile: DominoTile,
    position: 'left' | 'right',
  ): void {
    if (position === 'left') {
      if (tile.bottom === game.board.leftEnd) {
        game.board.tiles.unshift(tile);
        game.board.leftEnd = tile.top;
      } else {
        game.board.tiles.unshift({ ...tile, top: tile.bottom, bottom: tile.top });
        game.board.leftEnd = tile.bottom;
      }
    } else {
      if (tile.top === game.board.rightEnd) {
        game.board.tiles.push(tile);
        game.board.rightEnd = tile.bottom;
      } else {
        game.board.tiles.push({ ...tile, top: tile.bottom, bottom: tile.top });
        game.board.rightEnd = tile.top;
      }
    }
  }

  drawTile(dto: DrawDominoTileDto): { game: DominoGame; tile?: DominoTile } {
    const game = this.games.get(dto.gameId);
    if (!game) {
      throw new Error('Game not found');
    }

    const player = game.players.find((p) => p.id === dto.playerId);
    if (!player) {
      throw new Error('Player not found');
    }

    if (game.players[game.currentTurnIndex].id !== dto.playerId) {
      throw new Error('Not your turn');
    }

    if (game.boneyard.length === 0) {
      game.currentTurnIndex = (game.currentTurnIndex + 1) % game.players.length;
      return { game };
    }

    const drawnTile = game.boneyard.pop();
    player.hand.push(drawnTile);

    return { game, tile: drawnTile };
  }

  getGame(gameId: string): DominoGame {
    const game = this.games.get(gameId);
    if (!game) {
      throw new Error('Game not found');
    }
    return game;
  }

  private generateGameId(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  private generatePlayerId(): string {
    return Math.random().toString(36).substring(2, 15);
  }
}
