import { Module } from '@nestjs/common';
import { DominoGateway } from './domino.gateway';
import { DominoService } from './domino.service';

@Module({
  providers: [DominoGateway, DominoService],
})
export class DominoModule {}
