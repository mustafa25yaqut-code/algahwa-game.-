import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { DominoService } from './domino.service';
import type {
  CreateDominoGameDto,
  JoinDominoGameDto,
  PlayDominoTileDto,
  DrawDominoTileDto,
} from './domino.types';

@WebSocketGateway({ cors: true })
export class DominoGateway {
  @WebSocketServer()
  server: Server;

  constructor(private readonly dominoService: DominoService) {}

  @SubscribeMessage('domino:createGame')
  handleCreateGame(
    @MessageBody() dto: CreateDominoGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.dominoService.createGame(dto);
      client.join(game.id);
      client.emit('domino:gameCreated', { game, playerId: game.players[0].id });
      return { success: true, game };
    } catch (error) {
      client.emit('domino:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('domino:joinGame')
  handleJoinGame(
    @MessageBody() dto: JoinDominoGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const { game, player } = this.dominoService.joinGame(dto);
      client.join(game.id);

      this.server.to(game.id).emit('domino:playerJoined', { game, newPlayer: player });
      client.emit('domino:gameJoined', { game, playerId: player.id });

      if (game.status === 'active') {
        this.server.to(game.id).emit('domino:gameStarted', { game });
      }

      return { success: true, game, playerId: player.id };
    } catch (error) {
      client.emit('domino:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('domino:playTile')
  handlePlayTile(
    @MessageBody() dto: PlayDominoTileDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.dominoService.playTile(dto);
      this.server.to(game.id).emit('domino:tilePlayer', { game, move: dto });

      if (game.status === 'finished') {
        this.server.to(game.id).emit('domino:gameFinished', { game });
      }

      return { success: true, game };
    } catch (error) {
      client.emit('domino:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('domino:drawTile')
  handleDrawTile(
    @MessageBody() dto: DrawDominoTileDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const { game, tile } = this.dominoService.drawTile(dto);

      client.emit('domino:tileDrawn', { tile });
      this.server.to(game.id).emit('domino:gameUpdated', { game });

      return { success: true, game };
    } catch (error) {
      client.emit('domino:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }

  @SubscribeMessage('domino:getGame')
  handleGetGame(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = this.dominoService.getGame(data.gameId);
      return { success: true, game };
    } catch (error) {
      client.emit('domino:error', { message: error.message });
      return { success: false, error: error.message };
    }
  }
}
