export interface DominoTile {
  top: number;
  bottom: number;
  id: string;
}

export interface DominoPlayer {
  id: string;
  name: string;
  hand: DominoTile[];
  isConnected: boolean;
}

export interface DominoMove {
  playerId: string;
  tile: DominoTile;
  position: 'left' | 'right';
}

export interface DominoBoard {
  tiles: DominoTile[];
  leftEnd: number;
  rightEnd: number;
}

export interface DominoGame {
  id: string;
  players: DominoPlayer[];
  board: DominoBoard;
  currentTurnIndex: number;
  boneyard: DominoTile[];
  status: 'waiting' | 'active' | 'finished';
  winner?: string;
  createdAt: Date;
}

export interface CreateDominoGameDto {
  playerName: string;
}

export interface JoinDominoGameDto {
  gameId: string;
  playerName: string;
}

export interface PlayDominoTileDto {
  gameId: string;
  playerId: string;
  tile: DominoTile;
  position: 'left' | 'right';
}

export interface DrawDominoTileDto {
  gameId: string;
  playerId: string;
}
