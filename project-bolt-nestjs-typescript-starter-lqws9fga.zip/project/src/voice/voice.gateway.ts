import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { VoiceService } from './voice.service';

@WebSocketGateway({ cors: true, namespace: '/voice' })
export class VoiceGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  constructor(private voiceService: VoiceService) {}

  async handleConnection(client: Socket) {
    console.log(`Voice client connected: ${client.id}`);
  }

  async handleDisconnect(client: Socket) {
    console.log(`Voice client disconnected: ${client.id}`);
    await this.voiceService.handleDisconnect(client.id);
    this.server.emit('voiceSettingsUpdate');
  }

  @SubscribeMessage('joinVoiceRoom')
  async handleJoinVoiceRoom(
    @MessageBody() data: { gameId: string; playerId: string; playerName: string },
    @ConnectedSocket() client: Socket,
  ) {
    await client.join(`voice-${data.gameId}`);

    await this.voiceService.createVoiceSettings(
      data.playerId,
      data.gameId,
      client.id,
    );

    const settings = await this.voiceService.getGameVoiceSettings(data.gameId);
    this.server.to(`voice-${data.gameId}`).emit('voiceSettingsUpdate', settings);

    return { success: true };
  }

  @SubscribeMessage('toggleMic')
  async handleToggleMic(
    @MessageBody() data: { playerId: string; gameId: string; enabled: boolean },
    @ConnectedSocket() client: Socket,
  ) {
    await this.voiceService.updateMicStatus(
      data.playerId,
      data.gameId,
      data.enabled,
    );

    const settings = await this.voiceService.getGameVoiceSettings(data.gameId);
    this.server.to(`voice-${data.gameId}`).emit('voiceSettingsUpdate', settings);
    this.server.to(`voice-${data.gameId}`).emit('micToggled', {
      playerId: data.playerId,
      enabled: data.enabled,
    });

    return { success: true };
  }

  @SubscribeMessage('mutePlayer')
  async handleMutePlayer(
    @MessageBody()
    data: { playerId: string; gameId: string; targetPlayerId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await this.voiceService.mutePlayer(
      data.playerId,
      data.gameId,
      data.targetPlayerId,
    );

    const settings = await this.voiceService.getPlayerVoiceSettings(
      data.playerId,
      data.gameId,
    );

    client.emit('voiceSettingsUpdate', settings);

    return { success: true };
  }

  @SubscribeMessage('unmutePlayer')
  async handleUnmutePlayer(
    @MessageBody()
    data: { playerId: string; gameId: string; targetPlayerId: string },
    @ConnectedSocket() client: Socket,
  ) {
    await this.voiceService.unmutePlayer(
      data.playerId,
      data.gameId,
      data.targetPlayerId,
    );

    const settings = await this.voiceService.getPlayerVoiceSettings(
      data.playerId,
      data.gameId,
    );

    client.emit('voiceSettingsUpdate', settings);

    return { success: true };
  }

  @SubscribeMessage('updateVolume')
  async handleUpdateVolume(
    @MessageBody() data: { playerId: string; gameId: string; volume: number },
    @ConnectedSocket() client: Socket,
  ) {
    await this.voiceService.updateVolume(
      data.playerId,
      data.gameId,
      data.volume,
    );

    return { success: true };
  }

  @SubscribeMessage('voiceSignal')
  handleVoiceSignal(
    @MessageBody() data: { targetSocketId: string; signal: any; from: string },
    @ConnectedSocket() client: Socket,
  ) {
    this.server.to(data.targetSocketId).emit('voiceSignal', {
      signal: data.signal,
      from: data.from,
      socketId: client.id,
    });
  }

  @SubscribeMessage('voiceOffer')
  handleVoiceOffer(
    @MessageBody()
    data: { targetSocketId: string; offer: any; from: string },
    @ConnectedSocket() client: Socket,
  ) {
    this.server.to(data.targetSocketId).emit('voiceOffer', {
      offer: data.offer,
      from: data.from,
      socketId: client.id,
    });
  }

  @SubscribeMessage('voiceAnswer')
  handleVoiceAnswer(
    @MessageBody()
    data: { targetSocketId: string; answer: any; from: string },
    @ConnectedSocket() client: Socket,
  ) {
    this.server.to(data.targetSocketId).emit('voiceAnswer', {
      answer: data.answer,
      from: data.from,
      socketId: client.id,
    });
  }

  @SubscribeMessage('iceCandidate')
  handleIceCandidate(
    @MessageBody()
    data: { targetSocketId: string; candidate: any; from: string },
    @ConnectedSocket() client: Socket,
  ) {
    this.server.to(data.targetSocketId).emit('iceCandidate', {
      candidate: data.candidate,
      from: data.from,
      socketId: client.id,
    });
  }
}
