import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class VoiceService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY,
    );
  }

  async createVoiceSettings(
    playerId: string,
    gameId: string,
    socketId: string,
  ) {
    const { data, error } = await this.supabase
      .from('voice_settings')
      .upsert(
        {
          player_id: playerId,
          game_id: gameId,
          socket_id: socketId,
          mic_enabled: false,
          muted_players: [],
          volume_level: 50,
        },
        { onConflict: 'player_id,game_id' },
      )
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async getPlayerVoiceSettings(playerId: string, gameId: string) {
    const { data, error } = await this.supabase
      .from('voice_settings')
      .select('*')
      .eq('player_id', playerId)
      .eq('game_id', gameId)
      .maybeSingle();

    if (error) throw error;
    return data;
  }

  async getGameVoiceSettings(gameId: string) {
    const { data, error } = await this.supabase
      .from('voice_settings')
      .select('*')
      .eq('game_id', gameId);

    if (error) throw error;
    return data;
  }

  async updateMicStatus(playerId: string, gameId: string, enabled: boolean) {
    const { error } = await this.supabase
      .from('voice_settings')
      .update({ mic_enabled: enabled, updated_at: new Date().toISOString() })
      .eq('player_id', playerId)
      .eq('game_id', gameId);

    if (error) throw error;
  }

  async mutePlayer(
    playerId: string,
    gameId: string,
    targetPlayerId: string,
  ) {
    const settings = await this.getPlayerVoiceSettings(playerId, gameId);
    if (!settings) return;

    const mutedPlayers = settings.muted_players || [];
    if (!mutedPlayers.includes(targetPlayerId)) {
      mutedPlayers.push(targetPlayerId);
    }

    const { error } = await this.supabase
      .from('voice_settings')
      .update({
        muted_players: mutedPlayers,
        updated_at: new Date().toISOString(),
      })
      .eq('player_id', playerId)
      .eq('game_id', gameId);

    if (error) throw error;
  }

  async unmutePlayer(
    playerId: string,
    gameId: string,
    targetPlayerId: string,
  ) {
    const settings = await this.getPlayerVoiceSettings(playerId, gameId);
    if (!settings) return;

    const mutedPlayers = (settings.muted_players || []).filter(
      (id) => id !== targetPlayerId,
    );

    const { error } = await this.supabase
      .from('voice_settings')
      .update({
        muted_players: mutedPlayers,
        updated_at: new Date().toISOString(),
      })
      .eq('player_id', playerId)
      .eq('game_id', gameId);

    if (error) throw error;
  }

  async updateVolume(playerId: string, gameId: string, volume: number) {
    const { error } = await this.supabase
      .from('voice_settings')
      .update({ volume_level: volume, updated_at: new Date().toISOString() })
      .eq('player_id', playerId)
      .eq('game_id', gameId);

    if (error) throw error;
  }

  async handleDisconnect(socketId: string) {
    const { error } = await this.supabase
      .from('voice_settings')
      .delete()
      .eq('socket_id', socketId);

    if (error) console.error('Error cleaning up voice settings:', error);
  }
}
