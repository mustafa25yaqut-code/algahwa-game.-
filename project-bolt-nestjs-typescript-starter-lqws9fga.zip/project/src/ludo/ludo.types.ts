export interface Game {
  id: string;
  room_code: string;
  status: 'waiting' | 'in_progress' | 'completed';
  current_turn: number;
  winner_id?: string;
  game_mode: 'single' | 'doubles';
  created_at: string;
  updated_at: string;
}

export interface Player {
  id: string;
  game_id: string;
  player_index: number;
  player_name: string;
  is_ready: boolean;
  pieces_home: number;
  team_id?: string;
  socket_id?: string;
  created_at: string;
}

export interface GameState {
  id: string;
  game_id: string;
  player_index: number;
  piece_index: number;
  position: number;
  updated_at: string;
}

export interface CreateGameDto {
  playerName: string;
  gameMode?: 'single' | 'doubles';
}

export interface JoinGameDto {
  roomCode: string;
  playerName: string;
}

export interface MovePieceDto {
  gameId: string;
  playerIndex: number;
  pieceIndex: number;
  diceValue: number;
}

export interface RollDiceDto {
  gameId: string;
  playerIndex: number;
}

export const PLAYER_COLORS = ['red', 'blue', 'green', 'yellow'];
export const TOTAL_PIECES = 4;
export const BOARD_POSITIONS = 52;
export const HOME_STRETCH_START = 100;
