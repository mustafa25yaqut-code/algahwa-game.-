import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  WebSocketServer,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { LudoService } from './ludo.service';
import type {
  CreateGameDto,
  JoinGameDto,
  MovePieceDto,
  RollDiceDto,
} from './ludo.types';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
export class LudoGateway {
  @WebSocketServer()
  server: Server;

  constructor(private readonly ludoService: LudoService) {}

  @SubscribeMessage('createGame')
  async handleCreateGame(
    @MessageBody() dto: CreateGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const result = await this.ludoService.createGame(dto);
      client.join(result.game.id);
      client.emit('gameCreated', result);
      return result;
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('joinGame')
  async handleJoinGame(
    @MessageBody() dto: JoinGameDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const result = await this.ludoService.joinGame(dto);
      client.join(result.game.id);

      const players = await this.ludoService.getPlayers(result.game.id);
      this.server.to(result.game.id).emit('playerJoined', {
        game: result.game,
        player: result.player,
        players,
      });

      return result;
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('getGameState')
  async handleGetGameState(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const game = await this.ludoService.getGame(data.gameId);
      const players = await this.ludoService.getPlayers(data.gameId);
      const gameState = await this.ludoService.getGameState(data.gameId);

      client.emit('gameState', { game, players, gameState });
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('setReady')
  async handleSetReady(
    @MessageBody() data: { playerId: string; gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      await this.ludoService.setPlayerReady(data.playerId);
      const players = await this.ludoService.getPlayers(data.gameId);

      this.server.to(data.gameId).emit('playersUpdated', { players });
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('startGame')
  async handleStartGame(
    @MessageBody() data: { gameId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      await this.ludoService.startGame(data.gameId);
      const game = await this.ludoService.getGame(data.gameId);

      this.server.to(data.gameId).emit('gameStarted', { game });
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('rollDice')
  async handleRollDice(
    @MessageBody() dto: RollDiceDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const diceValue = this.ludoService.rollDice();
      this.server.to(dto.gameId).emit('diceRolled', {
        playerIndex: dto.playerIndex,
        diceValue,
      });
      return { diceValue };
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('movePiece')
  async handleMovePiece(
    @MessageBody() dto: MovePieceDto,
    @ConnectedSocket() client: Socket,
  ) {
    try {
      const updatedPiece = await this.ludoService.movePiece(dto);
      const game = await this.ludoService.getGame(dto.gameId);
      const gameState = await this.ludoService.getGameState(dto.gameId);

      this.server.to(dto.gameId).emit('pieceMoved', {
        piece: updatedPiece,
        game,
        gameState,
      });

      return { success: true };
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }
}
