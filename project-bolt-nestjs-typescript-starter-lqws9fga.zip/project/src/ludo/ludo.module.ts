import { Module } from '@nestjs/common';
import { LudoService } from './ludo.service';
import { LudoGateway } from './ludo.gateway';

@Module({
  providers: [LudoService, LudoGateway],
})
export class LudoModule {}
