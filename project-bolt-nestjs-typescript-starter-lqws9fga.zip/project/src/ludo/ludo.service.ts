import { Injectable } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Game,
  Player,
  GameState,
  CreateGameDto,
  JoinGameDto,
  MovePieceDto,
  TOTAL_PIECES,
  BOARD_POSITIONS,
  HOME_STRETCH_START,
} from './ludo.types';

@Injectable()
export class LudoService {
  private supabase: SupabaseClient;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '',
      process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || '',
    );
  }

  generateRoomCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  async createGame(dto: CreateGameDto): Promise<{
    game: Game;
    player: Player;
  }> {
    const roomCode = this.generateRoomCode();

    const { data: game, error: gameError } = await this.supabase
      .from('games')
      .insert({
        room_code: roomCode,
        status: 'waiting',
        current_turn: 0,
      })
      .select()
      .single();

    if (gameError) throw new Error(gameError.message);

    const { data: player, error: playerError } = await this.supabase
      .from('players')
      .insert({
        game_id: game.id,
        player_index: 0,
        player_name: dto.playerName,
        is_ready: false,
      })
      .select()
      .single();

    if (playerError) throw new Error(playerError.message);

    for (let i = 0; i < TOTAL_PIECES; i++) {
      await this.supabase.from('game_state').insert({
        game_id: game.id,
        player_index: 0,
        piece_index: i,
        position: -1,
      });
    }

    return { game, player };
  }

  async joinGame(dto: JoinGameDto): Promise<{
    game: Game;
    player: Player;
  }> {
    const { data: game, error: gameError } = await this.supabase
      .from('games')
      .select()
      .eq('room_code', dto.roomCode)
      .eq('status', 'waiting')
      .maybeSingle();

    if (gameError) throw new Error(gameError.message);
    if (!game) throw new Error('Game not found or already started');

    const { data: existingPlayers } = await this.supabase
      .from('players')
      .select()
      .eq('game_id', game.id);

    if (existingPlayers && existingPlayers.length >= 4) {
      throw new Error('Game is full');
    }

    const playerIndex = existingPlayers?.length || 0;

    const { data: player, error: playerError } = await this.supabase
      .from('players')
      .insert({
        game_id: game.id,
        player_index: playerIndex,
        player_name: dto.playerName,
        is_ready: false,
      })
      .select()
      .single();

    if (playerError) throw new Error(playerError.message);

    for (let i = 0; i < TOTAL_PIECES; i++) {
      await this.supabase.from('game_state').insert({
        game_id: game.id,
        player_index: playerIndex,
        piece_index: i,
        position: -1,
      });
    }

    return { game, player };
  }

  async getGame(gameId: string): Promise<Game> {
    const { data, error } = await this.supabase
      .from('games')
      .select()
      .eq('id', gameId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) throw new Error('Game not found');

    return data;
  }

  async getPlayers(gameId: string): Promise<Player[]> {
    const { data, error } = await this.supabase
      .from('players')
      .select()
      .eq('game_id', gameId)
      .order('player_index');

    if (error) throw new Error(error.message);
    return data || [];
  }

  async getGameState(gameId: string): Promise<GameState[]> {
    const { data, error } = await this.supabase
      .from('game_state')
      .select()
      .eq('game_id', gameId)
      .order('player_index')
      .order('piece_index');

    if (error) throw new Error(error.message);
    return data || [];
  }

  async setPlayerReady(playerId: string): Promise<void> {
    await this.supabase
      .from('players')
      .update({ is_ready: true })
      .eq('id', playerId);
  }

  async startGame(gameId: string): Promise<void> {
    const players = await this.getPlayers(gameId);
    const allReady = players.every((p) => p.is_ready);

    if (!allReady || players.length < 2) {
      throw new Error('Not all players are ready or not enough players');
    }

    await this.supabase
      .from('games')
      .update({ status: 'in_progress', current_turn: 0 })
      .eq('id', gameId);
  }

  async movePiece(dto: MovePieceDto): Promise<GameState> {
    const { data: piece, error } = await this.supabase
      .from('game_state')
      .select()
      .eq('game_id', dto.gameId)
      .eq('player_index', dto.playerIndex)
      .eq('piece_index', dto.pieceIndex)
      .maybeSingle();

    if (error || !piece) throw new Error('Piece not found');

    let newPosition = piece.position;

    if (piece.position === -1 && dto.diceValue === 6) {
      newPosition = dto.playerIndex * 13;
    } else if (piece.position >= 0 && piece.position < BOARD_POSITIONS) {
      newPosition = piece.position + dto.diceValue;

      const startPos = dto.playerIndex * 13;
      const homeEntryPos = (startPos - 1 + BOARD_POSITIONS) % BOARD_POSITIONS;

      if (
        piece.position <= homeEntryPos &&
        newPosition > homeEntryPos &&
        newPosition <= homeEntryPos + dto.diceValue
      ) {
        const stepsIntoHome = newPosition - homeEntryPos;
        if (stepsIntoHome <= 6) {
          newPosition = HOME_STRETCH_START + dto.playerIndex * 10 + stepsIntoHome - 1;
        }
      }

      if (newPosition >= BOARD_POSITIONS && newPosition < HOME_STRETCH_START) {
        newPosition = newPosition % BOARD_POSITIONS;
      }
    } else if (piece.position >= HOME_STRETCH_START) {
      const homeStart = HOME_STRETCH_START + dto.playerIndex * 10;
      const homeEnd = homeStart + 5;
      newPosition = piece.position + dto.diceValue;

      if (newPosition > homeEnd) {
        newPosition = piece.position;
      }
    }

    const { data: updated } = await this.supabase
      .from('game_state')
      .update({ position: newPosition })
      .eq('id', piece.id)
      .select()
      .single();

    await this.checkForCapture(dto.gameId, dto.playerIndex, newPosition);

    const game = await this.getGame(dto.gameId);
    const nextTurn = (game.current_turn + 1) % (await this.getPlayers(dto.gameId)).length;

    await this.supabase
      .from('games')
      .update({ current_turn: nextTurn })
      .eq('id', dto.gameId);

    return updated!;
  }

  async checkForCapture(
    gameId: string,
    currentPlayer: number,
    position: number,
  ): Promise<void> {
    if (position < 0 || position >= HOME_STRETCH_START) return;

    const { data: pieces } = await this.supabase
      .from('game_state')
      .select()
      .eq('game_id', gameId)
      .eq('position', position)
      .neq('player_index', currentPlayer);

    if (pieces && pieces.length > 0) {
      for (const piece of pieces) {
        await this.supabase
          .from('game_state')
          .update({ position: -1 })
          .eq('id', piece.id);
      }
    }
  }

  rollDice(): number {
    return Math.floor(Math.random() * 6) + 1;
  }
}
