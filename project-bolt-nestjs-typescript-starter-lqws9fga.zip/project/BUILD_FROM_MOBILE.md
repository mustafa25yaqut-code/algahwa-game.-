# 📱 بناء APK من الموبايل مباشرة!

## 🎯 نعم! يمكنك بناء APK من موبايل Android!

باستخدام **Termux** - محاكي Linux على Android

---

## 📲 المتطلبات:

```
✅ هاتف Android (6.0+)
✅ مساحة 2-3 GB
✅ إنترنت
✅ 1-2 ساعة للإعداد الأولي
```

---

## 🚀 الخطوات:

### 1️⃣ تثبيت Termux

```
1. حمّل Termux من F-Droid (ليس من Play Store!)
   https://f-droid.org/packages/com.termux/

2. ثبّت التطبيق

3. افتح Termux
```

---

### 2️⃣ إعداد Termux

```bash
# في Termux:

# تحديث النظام
pkg update && pkg upgrade

# تثبيت المتطلبات الأساسية
pkg install git nodejs python wget

# إعطاء صلاحية التخزين
termux-setup-storage

# اختبار
node --version
npm --version
```

---

### 3️⃣ تثبيت Java و Android SDK

```bash
# تثبيت Java
pkg install openjdk-17

# تثبيت Android SDK (سيستغرق وقت)
pkg install android-sdk

# إعداد المتغيرات
echo "export ANDROID_HOME=$HOME/android-sdk" >> ~/.bashrc
echo "export PATH=\$PATH:\$ANDROID_HOME/tools:\$ANDROID_HOME/platform-tools" >> ~/.bashrc
source ~/.bashrc

# تثبيت أدوات البناء
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
```

---

### 4️⃣ استنساخ المشروع

```bash
# إنشاء مجلد للمشاريع
cd ~/storage/shared/
mkdir projects
cd projects

# استنساخ المشروع من GitHub
git clone https://github.com/YOUR_USERNAME/algahwa-game.git
cd algahwa-game

# تثبيت المكتبات
npm install
```

---

### 5️⃣ بناء المشروع

```bash
# بناء Backend
npm run build

# مزامنة Capacitor
npx cap sync android

# بناء APK
cd android
chmod +x gradlew
./gradlew assembleDebug

# ✅ APK جاهز!
```

---

### 6️⃣ موقع APK

```bash
# APK موجود في:
android/app/build/outputs/apk/debug/app-debug.apk

# نسخه إلى التخزين:
cp android/app/build/outputs/apk/debug/app-debug.apk \
   ~/storage/shared/Download/algahwa.apk

# ثبّته من مجلد Downloads!
```

---

## ⏱️ المدة المتوقعة:

```
الإعداد الأولي:  1-2 ساعة (مرة واحدة)
البناء الأول:     30-60 دقيقة
البناءات التالية: 10-20 دقيقة
```

---

## 📊 المساحة المطلوبة:

```
Termux:           ~100 MB
Node.js:          ~50 MB
Java JDK:         ~200 MB
Android SDK:      ~800 MB
المشروع:          ~200 MB
Build files:      ~500 MB
─────────────────────────
الإجمالي:        ~2 GB
```

---

## 💡 نصائح مهمة:

### 1. استخدم مجلد shared:
```bash
# دائماً اعمل في:
cd ~/storage/shared/projects/

# حتى تصل للملفات من File Manager
```

### 2. احفظ الطاقة:
```bash
# البناء يستهلك بطارية!
# وصّل الشاحن أثناء البناء
```

### 3. استخدم WiFi:
```bash
# التحديثات تحتاج إنترنت سريع
# استخدم WiFi بدلاً من البيانات
```

### 4. نظّف بعد البناء:
```bash
# لتوفير مساحة:
cd android
./gradlew clean
```

---

## 🔧 حل المشاكل الشائعة:

### المشكلة: Out of memory
```bash
# الحل:
# في android/gradle.properties أضف:
org.gradle.jvmargs=-Xmx2048m

# وأغلق التطبيقات الأخرى
```

### المشكلة: Command not found
```bash
# الحل:
pkg update
pkg upgrade
# أعد تثبيت الأداة المفقودة
```

### المشكلة: Permission denied
```bash
# الحل:
chmod +x gradlew
termux-setup-storage
```

### المشكلة: Gradle daemon died
```bash
# الحل:
cd android
./gradlew --stop
./gradlew assembleDebug --no-daemon
```

---

## ⚡ بدائل أسهل (بدون Termux):

### 1. GitHub Actions (الأفضل)
```
✅ ارفع الكود من الحاسوب مرة واحدة
✅ GitHub تبني APK تلقائياً
✅ حمّل APK من موبايلك
✅ لا يحتاج Termux
```

### 2. EAS Build
```bash
# من حاسوب أي شخص (مقهى، صديق، إلخ):
npm install -g eas-cli
eas login
eas build --platform android

# حمّل APK من موبايلك!
```

### 3. Replit (بناء أونلاين)
```
1. اذهب إلى replit.com
2. استورد المشروع من GitHub
3. ثبّت المكتبات
4. ابنِ المشروع
5. حمّل APK

✅ يعمل من أي جهاز (حتى تابلت!)
```

---

## 📱 الخلاصة:

### يمكنك بناء APK من الموبايل بـ 3 طرق:

| الطريقة | الصعوبة | الوقت | المساحة |
|---------|---------|-------|---------|
| **Termux** | 🔴 صعب | 2 ساعة | 2 GB |
| **GitHub Actions** | 🟢 سهل | 10 دقيقة | 0 MB |
| **EAS Build** | 🟢 سهل | 5 دقيقة | 0 MB |

---

## 🎯 التوصية:

### إذا كان لديك حاسوب:
✅ استخدم **GitHub Actions** (ارفع مرة وخلاص)

### إذا لم يكن لديك حاسوب:
1. ✅ استعير حاسوب لرفع الكود على GitHub (مرة واحدة)
2. ✅ GitHub Actions تبني APK تلقائياً
3. ✅ حمّل من موبايلك كل مرة

### إذا أردت التحدي:
🔴 جرّب Termux! (صعب لكن ممكن)

---

## 🔗 روابط مفيدة:

- **Termux:** https://f-droid.org/packages/com.termux/
- **Termux Wiki:** https://wiki.termux.com/
- **GitHub Actions:** https://github.com/features/actions
- **EAS Build:** https://expo.dev/eas

---

## 💬 خلاصة القول:

**نعم، يمكنك بناء APK من الموبايل، لكن:**

```
الطريقة الأسهل والأفضل:
1. استعير حاسوب 10 دقائق
2. ارفع الكود على GitHub
3. GitHub تبني APK تلقائياً
4. حمّل من موبايلك متى شئت

✅ بدون Termux
✅ بدون تعقيد
✅ بدون استهلاك بطارية
✅ مجاني 100%
```

---

**🎮 اختر الطريقة الأنسب لك! 🚀**
