# 🎮 الگهوة - AlGahwa

**لعبة متعددة اللاعبين تجمع أشهر الألعاب الشعبية العربية في تطبيق واحد!**

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/yourusername/algahwa-game)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-Web%20%7C%20Android%20%7C%20iOS-lightgrey.svg)](README.md)

---

## 🎯 نظرة عامة

الگهوة هو تطبيق ألعاب متكامل يضم:
- 🎲 **لودو** - اللعبة الكلاسيكية المحبوبة
- 🀄 **دومينو** - لعبة الدومينو الاستراتيجية
- 🎴 **جاكارو** - لعبة الورق الشعبية
- ⚫ **طاولة الزهر** - Backgammon الأصيلة

---

## ✨ المميزات الكاملة

### 🎮 الألعاب
- ✅ 4 ألعاب شعبية كاملة
- ✅ لعب متعدد اللاعبين في الوقت الفعلي
- ✅ نظام مطابقة ذكي
- ✅ وضع الرهان والمنافسة

### 👥 اجتماعي
- ✅ نظام أصدقاء كامل
- ✅ دردشة نصية وصوتية
- ✅ ملصقات وهدايا
- ✅ مجموعات ومسابقات

### 🏆 تنافسي
- ✅ نظام الترتيب العام
- ✅ بطولات منظمة
- ✅ إنجازات وشارات
- ✅ تحديات يومية

### 💰 نظام مالي
- ✅ محفظة إلكترونية
- ✅ شحن وسحب الأموال
- ✅ متجر للأيتمات والأفاتارات
- ✅ نظام VIP

### 📊 إحصائيات
- ✅ سجل المباريات
- ✅ معدلات الفوز
- ✅ سلسلة الانتصارات
- ✅ تحليلات مفصلة

### 🔔 إشعارات
- ✅ إشعارات فورية
- ✅ Push notifications
- ✅ تنبيهات الأحداث

### 🎨 تخصيص
- ✅ سمات وألوان
- ✅ أيقونات وإطارات
- ✅ أنماط النرد واللوحات

### 🔐 أمان
- ✅ RLS على جميع البيانات
- ✅ مصادقة ثنائية (2FA)
- ✅ سجلات أمان
- ✅ نظام إبلاغ وحظر

### 💬 دعم فني
- ✅ نظام تذاكر
- ✅ أسئلة شائعة
- ✅ تقييمات ومراجعات

---

## 🛠️ التقنيات المستخدمة

### Backend
- **NestJS** - إطار عمل Node.js قوي
- **Socket.io** - اتصال فوري ثنائي الاتجاه
- **TypeScript** - JavaScript مع الأنواع
- **Supabase** - قاعدة بيانات PostgreSQL

### Frontend
- **HTML5/CSS3** - واجهة حديثة
- **JavaScript** - تفاعلية متقدمة
- **PWA** - تطبيق ويب متقدم
- **Capacitor** - تحويل لـ Android/iOS

### قاعدة البيانات
- **PostgreSQL** (Supabase)
- **41 جدول**
- **50+ دالة**
- **RLS Security**

---

## 📱 منصات مدعومة

- 🌐 **متصفح الويب** - Chrome, Firefox, Safari, Edge
- 📱 **Android** - 5.1+ (API 22+)
- 🍎 **iOS** - قريباً
- 💻 **سطح المكتب** - عبر المتصفح

---

## 🚀 البدء السريع

### التثبيت

```bash
# استنسخ المشروع
git clone https://github.com/yourusername/algahwa-game.git
cd algahwa-game

# ثبّت المكتبات
npm install

# اضبط المتغيرات البيئية
cp .env.example .env
# عدّل .env وأضف مفاتيح Supabase
```

### التشغيل

```bash
# وضع التطوير
npm run start:dev

# وضع الإنتاج
npm run build
npm run start:prod
```

---

## 📱 بناء تطبيق Android

### خطوات سريعة:

```bash
# 1. مزامنة مع Android
npm run android:sync

# 2. فتح في Android Studio
npm run android:open

# 3. في Android Studio:
# Build → Build APK
```

### دلائل مفصلة:
- 📖 [دليل كامل لبناء APK](BUILD_ANDROID_APK.md)
- ⚡ [البدء السريع - Android](QUICK_START_ANDROID.md)

---

## 📊 إحصائيات المشروع

```
📁 إجمالي الملفات: 200+
📝 أسطر الكود: 15,000+
🗄️ جداول قاعدة البيانات: 41
⚡ دوال SQL: 50+
🎮 ألعاب: 4
💾 حجم APK: ~9 MB
```

---

## 🗺️ خارطة الطريق

### ✅ الإصدار 1.0 (مكتمل)
- جميع الألعاب الأساسية
- نظام مالي كامل
- إشعارات ودعم
- بطولات وترتيب
- Android APK

### 🔄 الإصدار 1.1 (قريباً)
- [ ] إعلانات Google AdMob
- [ ] Google Analytics
- [ ] نظام AI للعب ضد الكمبيوتر
- [ ] البث المباشر للمباريات

### 🔮 الإصدار 2.0 (مستقبلاً)
- [ ] تطبيق iOS
- [ ] المزيد من الألعاب
- [ ] وضع الفرق
- [ ] دعم لغات إضافية

## Project setup

```bash
$ npm install
```

## Compile and run the project

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```

## Run tests

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Deployment

When you're ready to deploy your NestJS application to production, there are some key steps you can take to ensure it runs as efficiently as possible. Check out the [deployment documentation](https://docs.nestjs.com/deployment) for more information.

If you are looking for a cloud-based platform to deploy your NestJS application, check out [Mau](https://mau.nestjs.com), our official platform for deploying NestJS applications on AWS. Mau makes deployment straightforward and fast, requiring just a few simple steps:

```bash
$ npm install -g @nestjs/mau
$ mau deploy
```

With Mau, you can deploy your application in just a few clicks, allowing you to focus on building features rather than managing infrastructure.

## Resources

Check out a few resources that may come in handy when working with NestJS:

- Visit the [NestJS Documentation](https://docs.nestjs.com) to learn more about the framework.
- For questions and support, please visit our [Discord channel](https://discord.gg/G7Qnnhy).
- To dive deeper and get more hands-on experience, check out our official video [courses](https://courses.nestjs.com/).
- Deploy your application to AWS with the help of [NestJS Mau](https://mau.nestjs.com) in just a few clicks.
- Visualize your application graph and interact with the NestJS application in real-time using [NestJS Devtools](https://devtools.nestjs.com).
- Need help with your project (part-time to full-time)? Check out our official [enterprise support](https://enterprise.nestjs.com).
- To stay in the loop and get updates, follow us on [X](https://x.com/nestframework) and [LinkedIn](https://linkedin.com/company/nestjs).
- Looking for a job, or have a job to offer? Check out our official [Jobs board](https://jobs.nestjs.com).

## Support

Nest is an MIT-licensed open source project. It can grow thanks to the sponsors and support by the amazing backers. If you'd like to join them, please [read more here](https://docs.nestjs.com/support).

## Stay in touch

- Author - [Kamil Myśliwiec](https://twitter.com/kammysliwiec)
- Website - [https://nestjs.com](https://nestjs.com/)
- Twitter - [@nestframework](https://twitter.com/nestframework)

## License

Nest is [MIT licensed](https://github.com/nestjs/nest/blob/master/LICENSE).
