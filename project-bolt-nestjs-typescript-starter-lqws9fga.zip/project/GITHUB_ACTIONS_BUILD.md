# 🤖 بناء APK تلقائياً باستخدام GitHub Actions

## ✨ الميزة الجديدة!

الآن يمكنك بناء APK **تلقائياً وبدون Android Studio** باستخدام GitHub Actions!

---

## 🚀 كيف يعمل؟

عند رفع الكود على GitHub، سيتم بناء APK تلقائياً وتحميله لك جاهزاً!

---

## 📋 الخطوات:

### 1️⃣ رفع المشروع على GitHub

```bash
# أنشئ مستودع جديد على GitHub
# ثم:

git init
git add .
git commit -m "Initial commit - AlGahwa Game"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/algahwa-game.git
git push -u origin main
```

### 2️⃣ تفعيل GitHub Actions

```
✅ تم إنشاء ملفات Workflows تلقائياً في:
   .github/workflows/android-build.yml
   .github/workflows/android-release.yml

✅ سيعمل تلقائياً عند:
   - Push إلى main
   - Pull Request
   - إنشاء Release
   - يدوياً من تبويب Actions
```

### 3️⃣ مشاهدة البناء

```
1. اذهب إلى:
   https://github.com/YOUR_USERNAME/algahwa-game/actions

2. انتظر 5-10 دقائق

3. حمّل APK من Artifacts
```

---

## 📦 أنواع البناء:

### Build 1: Debug APK (تلقائي)
```yaml
الملف: android-build.yml
يعمل عند: كل push
النتيجة: app-debug.apk
الحجم: ~10 MB
الاستخدام: الاختبار
```

### Build 2: Release APK/AAB (موقّع)
```yaml
الملف: android-release.yml
يعمل عند: إنشاء Release
النتيجة: app-release.apk + app-release.aab
الحجم: ~8-9 MB
الاستخدام: النشر على Google Play
```

---

## 🔐 للحصول على APK موقّع:

### الخطوة 1: إنشاء Keystore محلياً

```bash
keytool -genkey -v -keystore algahwa-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias algahwa-release

# احفظ:
# - كلمة مرور Keystore
# - كلمة مرور Key
# - Alias name
```

### الخطوة 2: تحويل Keystore إلى Base64

```bash
# في Linux/Mac:
base64 algahwa-key.jks > keystore.txt

# في Windows (PowerShell):
[Convert]::ToBase64String([IO.File]::ReadAllBytes("algahwa-key.jks")) | Out-File keystore.txt
```

### الخطوة 3: إضافة Secrets في GitHub

```
اذهب إلى:
Settings → Secrets and variables → Actions → New repository secret

أضف:
1. KEYSTORE_BASE64 = محتوى keystore.txt
2. KEYSTORE_PASSWORD = كلمة مرور Keystore
3. KEY_PASSWORD = كلمة مرور Key
4. KEY_ALIAS = algahwa-release
```

### الخطوة 4: إنشاء Release

```
1. اذهب إلى Releases
2. انقر "Create a new release"
3. اختر Tag: v1.0.0
4. انقر "Publish release"

✅ سيتم بناء APK موقّع تلقائياً!
```

---

## 🎯 البناء اليدوي

يمكنك بناء APK يدوياً في أي وقت:

```
1. اذهب إلى تبويب "Actions"
2. اختر "Build Android APK" أو "Build Signed APK/AAB"
3. انقر "Run workflow"
4. اختر الـ branch
5. انقر "Run workflow"

⏱️ انتظر 5-10 دقائق
📦 حمّل APK من Artifacts
```

---

## 📊 معلومات البناء:

```yaml
نظام البناء: Ubuntu Latest
Node.js: 20
Java JDK: 17
Gradle: Wrapper
المدة: 5-10 دقائق
التكلفة: مجاني 100% (GitHub Free)
```

---

## 📥 تحميل APK بعد البناء:

### من Artifacts:
```
1. اذهب إلى Actions
2. اختر آخر Workflow
3. انزل إلى Artifacts
4. حمّل "app-debug" أو "app-release-signed"
```

### من Releases:
```
1. اذهب إلى Releases
2. حمّل APK/AAB من Assets
```

---

## 🔧 تخصيص الإصدار:

عند البناء اليدوي، يمكنك تحديد:
- **Version Name**: 1.0.0, 1.1.0, etc
- **Version Code**: 1, 2, 3, etc

```yaml
# في واجهة Run workflow:
Version name: 1.0.0
Version code: 1
```

---

## ⚠️ ملاحظات مهمة:

### 1. الأمان:
```
✅ لا ترفع Keystore مباشرة في الكود
✅ استخدم Secrets فقط
✅ لا تشارك كلمات المرور
```

### 2. الحجم:
```
Debug APK: ~10 MB
Release APK: ~8 MB
AAB: ~7 MB (موصى به للنشر)
```

### 3. الصلاحيات:
```
✅ تأكد من تفعيل Actions في المستودع
✅ تحتاج صلاحيات Write في Settings
```

---

## 🐛 حل المشاكل:

### المشكلة: Build failed
```bash
# حلول:
1. تحقق من الـ Logs في Actions
2. تأكد من صحة package.json
3. تأكد من وجود android/ folder
4. أعد تشغيل Workflow
```

### المشكلة: Keystore error
```bash
# تحقق من:
1. KEYSTORE_BASE64 صحيح
2. كلمات المرور صحيحة
3. KEY_ALIAS صحيح
```

### المشكلة: Out of space
```bash
# نادر جداً، لكن:
1. نظف Dependencies cache
2. أعد تشغيل Workflow
```

---

## 📱 بعد الحصول على APK:

### للاختبار:
```bash
# ثبّت على هاتفك:
adb install app-debug.apk

# أو:
# انسخ APK إلى الهاتف وثبّته مباشرة
```

### للنشر:
```
✅ استخدم AAB (أفضل)
✅ ارفعه على Google Play Console
✅ اختبر مع 20 مستخدم (14 يوم)
✅ انشر!
```

---

## 🎉 المميزات:

```
✅ بناء تلقائي 100%
✅ لا يحتاج Android Studio
✅ مجاني تماماً
✅ APK جاهز في دقائق
✅ يدعم التوقيع
✅ AAB للنشر
✅ Versioning تلقائي
✅ سهل جداً
```

---

## 📚 روابط مفيدة:

- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [Gradle Android Plugin](https://developer.android.com/studio/build)
- [Capacitor Android](https://capacitorjs.com/docs/android)

---

## 🔄 سير العمل:

```
1. كتابة الكود محلياً
   ↓
2. Push إلى GitHub
   ↓
3. GitHub Actions تبني APK تلقائياً
   ↓
4. تحميل APK جاهز
   ↓
5. اختبار على الهاتف
   ↓
6. إنشاء Release
   ↓
7. بناء APK موقّع
   ↓
8. النشر على Google Play
```

---

## 💡 نصائح:

1. **استخدم Branches** للتطوير
2. **اعمل Release** للإصدارات المستقرة
3. **احفظ Keystore** في مكان آمن
4. **راقب Logs** إذا فشل البناء
5. **اختبر APK** قبل النشر

---

## 🎯 الخلاصة:

**الآن يمكنك بناء APK بدون Android Studio!**

```bash
# فقط:
1. ارفع الكود على GitHub
2. انتظر 5-10 دقائق
3. حمّل APK جاهز
4. ثبّت واختبر
5. انشر على Google Play

🎮 سهل وسريع! 🚀
```

---

**لا تنسَ: احفظ Keystore بأمان! لن تستطيع تحديث التطبيق بدونه.**
