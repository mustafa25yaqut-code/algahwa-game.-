# 📱 دليل بناء تطبيق Android APK - الگهوة

## ✅ الإعداد الأولي مكتمل!

تم تجهيز المشروع بالكامل لبناء APK جاهز للنشر على Google Play Store.

---

## 🎯 الطريقة 1: بناء APK محلياً (يتطلب Android Studio)

### المتطلبات:
```bash
✅ Node.js 20+ (مثبت)
✅ Capacitor (مثبت)
✅ مشروع Android (تم إنشاؤه)
⚠️ Android Studio (يجب تثبيته)
⚠️ Java JDK 17+ (يجب تثبيته)
```

### الخطوات:

#### 1. تثبيت Android Studio
```bash
# حمّل Android Studio من:
https://developer.android.com/studio

# بعد التثبيت، افتح Android Studio وثبت:
- Android SDK
- Android SDK Platform-Tools
- Android SDK Build-Tools
```

#### 2. نسخ الملفات إلى Android
```bash
npm run build
npx cap sync android
```

#### 3. فتح المشروع في Android Studio
```bash
npx cap open android
```

#### 4. بناء APK من Android Studio
```
1. انتظر حتى ينتهي Gradle من المزامنة
2. اذهب إلى: Build > Build Bundle(s) / APK(s) > Build APK(s)
3. انتظر حتى ينتهي البناء
4. انقر على "locate" للحصول على ملف APK
```

**موقع ملف APK:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🚀 الطريقة 2: بناء APK موقّع للنشر (Production)

### 1. إنشاء مفتاح التوقيع
```bash
keytool -genkey -v -keystore algahwa-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias algahwa-release
```

**ستُسأل عن:**
- كلمة المرور
- الاسم
- اسم المنظمة
- المدينة
- الدولة

**احفظ هذا المفتاح بأمان!**

### 2. تكوين التوقيع
أنشئ ملف: `android/key.properties`

```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=algahwa-release
storeFile=../algahwa-release-key.jks
```

### 3. تعديل build.gradle
أضف في `android/app/build.gradle` قبل `android {`:

```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

### 4. بناء APK موقّع
```bash
cd android
./gradlew assembleRelease
```

**موقع APK الموقّع:**
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 🌐 الطريقة 3: استخدام خدمة سحابية (الأسهل)

### خيار أ: EAS Build (Expo)
```bash
npm install -g eas-cli
eas build --platform android
```

### خيار ب: Bitrise
1. اذهب إلى: https://bitrise.io
2. أنشئ حساب
3. ارفع مشروعك على GitHub
4. اربط المشروع مع Bitrise
5. سيبني لك APK تلقائياً

### خيار ج: CircleCI / GitHub Actions
قم بإعداد CI/CD للبناء التلقائي

---

## 📦 النشر على Google Play Store

### 1. إنشاء حساب مطور
```bash
# اذهب إلى:
https://play.google.com/console

# رسوم التسجيل لمرة واحدة: $25
```

### 2. إنشاء تطبيق جديد
1. انقر "Create app"
2. أدخل اسم التطبيق: **الگهوة**
3. اختر اللغة الافتراضية: **العربية**
4. حدد نوع التطبيق: **مجاني**

### 3. ملء معلومات التطبيق

#### أ. Store listing
```
- العنوان: الگهوة - لعبة لودو متعددة اللاعبين
- الوصف المختصر: العب لودو، دومينو، جاكارو وطاولة الزهر مع أصدقائك!
- الوصف الكامل: (اكتب وصف مفصل عن التطبيق)
- الأيقونة: 512×512 pixels
- لقطات الشاشة: 3-8 صور
- فيديو ترويجي (اختياري)
```

#### ب. Content rating
1. أكمل الاستبيان
2. للألعاب: حدد **Everyone**

#### ج. Target audience
- الفئة العمرية: **13+ سنة**
- الموقع: **جميع الدول**

#### د. Privacy Policy
يجب أن يكون لديك سياسة خصوصية منشورة على موقعك

### 4. رفع APK/AAB
```bash
# الأفضل: بناء Android App Bundle (AAB)
cd android
./gradlew bundleRelease

# الملف سيكون في:
# android/app/build/outputs/bundle/release/app-release.aab
```

### 5. اختبار داخلي
1. أنشئ مسار **Internal testing**
2. ارفع AAB/APK
3. أضف مختبرين (على الأقل 20 شخص)
3. اختبر لمدة 14 يوم على الأقل

### 6. النشر للجميع
بعد المراجعة والموافقة، سيكون التطبيق متاحاً على Google Play!

---

## 🎨 الأيقونات والصور المطلوبة

### للتطبيق:
```
✅ أيقونة التطبيق: 512×512 px (PNG)
✅ Feature graphic: 1024×500 px
✅ لقطات شاشة:
   - هاتف: 1080×1920 px على الأقل
   - تابلت: 1536×2048 px (اختياري)
```

### توجد بالفعل:
```
✅ public/icon-192.png
✅ public/icon-512.png
```

---

## ⚙️ إعدادات متقدمة

### تحسين حجم APK
في `android/app/build.gradle`:

```gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt')
        }
    }

    splits {
        abi {
            enable true
            reset()
            include 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
            universalApk false
        }
    }
}
```

### دعم التطبيقات متعددة اللغات
```xml
<!-- في android/app/src/main/res/values/strings.xml -->
<string name="app_name">AlGahwa</string>

<!-- في android/app/src/main/res/values-ar/strings.xml -->
<string name="app_name">الگهوة</string>
```

---

## 🔧 حل المشاكل الشائعة

### مشكلة: Gradle build failed
```bash
# نظف وأعد البناء
cd android
./gradlew clean
./gradlew assembleDebug
```

### مشكلة: SDK not found
```bash
# حدد مسار SDK
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### مشكلة: Out of memory
في `android/gradle.properties`:
```properties
org.gradle.jvmargs=-Xmx4096m -XX:MaxPermSize=1024m
```

---

## 📊 أوامر مفيدة

```bash
# بناء للتطوير
npm run build && npx cap sync android

# فتح Android Studio
npx cap open android

# تشغيل على جهاز متصل
npx cap run android

# تحديث Plugins
npx cap sync

# نسخ الملفات فقط
npx cap copy android

# عرض معلومات المشروع
npx cap doctor
```

---

## 📝 ملاحظات مهمة

### ✅ تم بالفعل:
- تثبيت Capacitor
- تكوين المشروع
- إضافة Plugins (Push, Share, Haptics, etc)
- إعداد manifest بالصلاحيات المطلوبة
- تكوين الألوان والسمات
- دعم RTL للعربية

### ⚠️ يجب عليك:
1. تثبيت Android Studio
2. إنشاء مفتاح توقيع
3. بناء APK موقّع
4. اختبار على أجهزة حقيقية
5. إنشاء حساب مطور Google Play
6. رفع التطبيق للمراجعة

---

## 🎉 بعد النشر

### تحديث التطبيق:
```bash
# 1. زود رقم الإصدار في android/app/build.gradle
versionCode 2
versionName "1.0.1"

# 2. ابنِ APK جديد
npm run build && npx cap sync android
cd android && ./gradlew bundleRelease

# 3. ارفع على Google Play Console
```

### تحليلات:
- استخدم Google Analytics
- راقب Crash reports
- تابع التقييمات والتعليقات

---

## 🔗 روابط مفيدة

- [Capacitor Docs](https://capacitorjs.com/docs)
- [Android Developer Guide](https://developer.android.com/guide)
- [Google Play Console](https://play.google.com/console)
- [Material Design](https://material.io/design)

---

## 📞 الدعم

إذا واجهت أي مشاكل:
1. تحقق من الـ logs: `npx cap sync`
2. راجع [Capacitor Troubleshooting](https://capacitorjs.com/docs/android/troubleshooting)
3. ابحث في [Stack Overflow](https://stackoverflow.com/questions/tagged/capacitor)

---

**🎮 حظاً موفقاً في نشر تطبيق الگهوة! 🚀**
