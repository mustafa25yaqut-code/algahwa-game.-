package com.algahwa.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
