# 🚀 بناء APK بدون Android Studio - الطريقة الأسرع!

## ⚡ 3 طرق فورية:

---

## ✅ الطريقة 1: GitHub Actions (الأسهل)

### ما تحتاجه:
- حساب GitHub (مجاني)
- 5 دقائق

### الخطوات:
```bash
# 1. ارفع الكود على GitHub
git init
git add .
git commit -m "AlGahwa Game"
git remote add origin https://github.com/YOUR_USERNAME/algahwa-game.git
git push -u origin main

# 2. اذهب إلى:
https://github.com/YOUR_USERNAME/algahwa-game/actions

# 3. انتظر 5-10 دقائق

# 4. حمّل APK من "Artifacts"
```

**✅ تم! APK جاهز بدون أي برنامج!**

📖 [دليل مفصل](GITHUB_ACTIONS_BUILD.md)

---

## ✅ الطريقة 2: EAS Build (الأسرع)

### ما تحتاجه:
- حساب Expo (مجاني)
- 3 دقائق

### الخطوات:
```bash
# 1. ثبّت EAS CLI
npm install -g eas-cli

# 2. سجّل دخول
eas login

# 3. كوّن المشروع (مرة واحدة)
eas build:configure

# 4. ابنِ APK
eas build --platform android --profile preview

# 5. سيعطيك رابط تحميل مباشر!
# مثال: https://expo.dev/artifacts/eas/...apk
```

**✅ تم! APK جاهز في 5 دقائق!**

**موقع EAS:** https://expo.dev/

---

## ✅ الطريقة 3: Render/Railway (للسيرفر)

إذا كنت تريد أيضاً رفع السيرفر:

### Render (موصى به):
```yaml
# 1. اذهب إلى:
https://render.com/

# 2. أنشئ Web Service جديد
- اربط مع GitHub
- اختر algahwa-game

# 3. إعدادات:
Build Command: npm run build
Start Command: npm run start:prod

# 4. Environment Variables:
SUPABASE_URL=your_url
SUPABASE_ANON_KEY=your_key

# 5. Deploy
```

**السعر:** مجاني (750 ساعة/شهر)

---

## 📊 مقارنة سريعة:

| الطريقة | الوقت | السهولة | التكلفة |
|---------|-------|----------|---------|
| **GitHub Actions** | 10 دقيقة | ⭐⭐⭐⭐⭐ | مجاني |
| **EAS Build** | 5 دقائق | ⭐⭐⭐⭐⭐ | 30 بناء/شهر |
| **App Center** | 15 دقيقة | ⭐⭐⭐⭐ | مجاني |

---

## 🎯 أيهما أختار؟

### اختر GitHub Actions إذا:
- ✅ الكود على GitHub بالفعل
- ✅ تريد CI/CD تلقائي
- ✅ تريد بناء عند كل Push

### اختر EAS Build إذا:
- ✅ تريد أسرع نتيجة
- ✅ لا تريد إعداد معقد
- ✅ تريد APK فوراً

---

## 💾 حجم الملفات:

```
Debug APK:   ~10 MB
Release APK: ~8 MB
AAB:         ~7 MB (للنشر على Play Store)
```

---

## 📱 تثبيت APK على الهاتف:

### الطريقة 1: USB
```bash
adb install app-debug.apk
```

### الطريقة 2: مباشرة
```
1. حمّل APK على الهاتف
2. افتح الملف
3. فعّل "مصادر غير معروفة"
4. ثبّت
```

---

## 🔐 للحصول على APK موقّع:

### 1. أنشئ Keystore:
```bash
keytool -genkey -v -keystore algahwa-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias algahwa-release

# احفظ كلمات المرور!
```

### 2. أضفه للخدمة المختارة:
- **GitHub:** أضف في Secrets
- **EAS:** سيطلبه تلقائياً
- **App Center:** في Build settings

---

## 🎉 بعد الحصول على APK:

```
✅ اختبر على هاتفك
✅ شارك مع أصدقائك للتجربة
✅ اجمع feedback
✅ حسّن التطبيق
✅ ابنِ نسخة Release
✅ انشر على Google Play!
```

---

## 📚 الملفات المتوفرة:

```
✅ .github/workflows/        → GitHub Actions configs
✅ eas.json                  → EAS Build config
✅ capacitor.config.ts       → Capacitor config
✅ android/                  → مشروع Android كامل

✅ GITHUB_ACTIONS_BUILD.md   → دليل GitHub Actions
✅ CLOUD_BUILD_OPTIONS.md    → مقارنة جميع الخيارات
✅ BUILD_ANDROID_APK.md      → دليل Android Studio
✅ QUICK_START_ANDROID.md    → بدء سريع
```

---

## 🔗 روابط مفيدة:

- **GitHub Actions:** https://github.com/features/actions
- **EAS Build:** https://expo.dev/eas
- **App Center:** https://appcenter.ms/
- **Bitrise:** https://www.bitrise.io/
- **Render:** https://render.com/

---

## ⚡ الملخص السريع:

### للحصول على APK فوراً:

**الطريقة الأسرع (3 دقائق):**
```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

**الطريقة المجانية الكاملة (10 دقائق):**
```bash
# ارفع على GitHub
# Actions ستبني تلقائياً
# حمّل من Artifacts
```

---

## 🎯 أنت الآن جاهز!

**لديك كل ما تحتاجه لبناء APK بدون Android Studio!**

اختر طريقتك المفضلة وابدأ الآن! 🚀

---

**💡 نصيحة:** ابدأ بـ GitHub Actions، إنها الأسهل والأكثر استخداماً!
