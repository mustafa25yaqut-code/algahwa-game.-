# ☁️ خيارات البناء السحابي - بدون Android Studio

## 🎯 لديك 4 خيارات مجانية لبناء APK تلقائياً:

---

## 1️⃣ GitHub Actions (الأسهل - موصى به)

### المميزات:
```
✅ مجاني 100%
✅ مدمج مع GitHub
✅ سهل الإعداد
✅ بناء تلقائي عند كل Push
✅ 2000 دقيقة/شهر مجاناً
```

### الإعداد:
```bash
# الملفات جاهزة في:
.github/workflows/android-build.yml
.github/workflows/android-release.yml

# فقط:
1. ارفع الكود على GitHub
2. Actions ستعمل تلقائياً
3. حمّل APK من Artifacts
```

📖 **الدليل الكامل:** [GITHUB_ACTIONS_BUILD.md](GITHUB_ACTIONS_BUILD.md)

---

## 2️⃣ Expo EAS Build

### المميزات:
```
✅ سهل جداً
✅ دعم رسمي لـ Capacitor
✅ 30 بناء/شهر مجاناً
✅ سريع (5 دقائق)
```

### الإعداد:
```bash
# 1. تثبيت EAS CLI
npm install -g eas-cli

# 2. تسجيل الدخول
eas login

# 3. تكوين المشروع
eas build:configure

# 4. بناء APK
eas build --platform android --profile preview

# 5. تحميل APK
# سيعطيك رابط تحميل مباشر!
```

### ملف التكوين (eas.json):
```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "app-bundle"
      }
    }
  }
}
```

**الموقع:** https://expo.dev/

---

## 3️⃣ App Center (Microsoft)

### المميزات:
```
✅ مجاني تماماً
✅ دعم CI/CD كامل
✅ Analytics مدمج
✅ Crash reporting
✅ بناءات غير محدودة
```

### الإعداد:
```bash
# 1. أنشئ حساب
https://appcenter.ms/

# 2. أنشئ تطبيق جديد
- اسم: AlGahwa
- OS: Android
- Platform: React Native (يعمل مع Capacitor)

# 3. اربط مع GitHub
Settings → Build → Connect to GitHub

# 4. اختر Branch
main → Configure Build

# 5. ضبط الإعدادات
Build Variant: debug/release
Build scripts:
  Pre-build: npm run build && npx cap sync android
  Post-build: (اختياري)

# 6. احفظ وابنِ
Save & Build

# 7. حمّل APK
من صفحة Build
```

**المدة:** 10-15 دقيقة
**التكلفة:** مجاني 100%

---

## 4️⃣ Bitrise

### المميزات:
```
✅ مخصص للـ Mobile
✅ 90 دقيقة/شهر مجاناً
✅ دعم Capacitor رسمي
✅ واجهة مرئية سهلة
```

### الإعداد:
```bash
# 1. أنشئ حساب
https://www.bitrise.io/

# 2. أضف تطبيق
+ Add new app

# 3. اربط مع GitHub
Connect your repository

# 4. اختر المشروع
algahwa-game

# 5. Bitrise سيكتشف Capacitor تلقائياً
✅ Detects Android project
✅ Suggests workflow

# 6. تخصيص Workflow (bitrise.yml):
```

```yaml
---
format_version: '11'
default_step_lib_source: https://github.com/bitrise-io/bitrise-steplib.git

workflows:
  primary:
    steps:
    - activate-ssh-key@4: {}
    - git-clone@8: {}
    - npm@1:
        inputs:
        - command: install
    - npm@1:
        inputs:
        - command: run build
    - script@1:
        title: Sync Capacitor
        inputs:
        - content: |-
            #!/bin/bash
            npx cap sync android
    - install-missing-android-tools@3:
        inputs:
        - gradlew_path: "$PROJECT_LOCATION/gradlew"
    - android-build@1:
        inputs:
        - project_location: "$PROJECT_LOCATION"
        - module: app
        - variant: debug
    - deploy-to-bitrise-io@2: {}
```

```bash
# 7. ابدأ البناء
Start/Schedule a build

# 8. حمّل APK
من Artifacts
```

**المدة:** 10-15 دقيقة

---

## 📊 مقارنة سريعة:

| الميزة | GitHub Actions | EAS Build | App Center | Bitrise |
|--------|---------------|-----------|------------|---------|
| **السعر** | مجاني | 30 بناء/شهر | مجاني | 90 دقيقة/شهر |
| **السرعة** | 5-10 دقائق | 5 دقائق | 10-15 دقيقة | 10-15 دقائق |
| **السهولة** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **الإعداد** | سهل | سهل جداً | متوسط | متوسط |
| **التوقيع** | ✅ | ✅ | ✅ | ✅ |
| **CI/CD** | ✅ | ✅ | ✅ | ✅ |

---

## 🎯 أيهما تختار؟

### ✅ اختر **GitHub Actions** إذا:
- الكود على GitHub
- تريد بناء تلقائي عند كل Push
- مجاني بالكامل
- **موصى به!**

### ✅ اختر **EAS Build** إذا:
- تريد أسهل طريقة
- لا تهتم بعدد البناءات (30 كافية)
- تريد نتيجة سريعة

### ✅ اختر **App Center** إذا:
- تريد Analytics مدمج
- تريد Crash reporting
- تريد بناءات غير محدودة
- تحب منتجات Microsoft

### ✅ اختر **Bitrise** إذا:
- تريد أداة متخصصة للـ Mobile
- تعمل على مشاريع متعددة
- تحتاج Workflows معقدة

---

## 🚀 الخطوات العامة لأي خيار:

```
1. أنشئ حساب في الخدمة
   ↓
2. اربط مع GitHub
   ↓
3. اختر المشروع
   ↓
4. كوّن Build
   ↓
5. انتظر البناء (5-15 دقيقة)
   ↓
6. حمّل APK جاهز
   ↓
7. ثبّت على الهاتف واختبر
```

---

## 💡 نصائح عامة:

### 1. التوقيع:
```bash
# لأي خيار، ستحتاج:
- Keystore file
- Store password
- Key password
- Key alias

# أنشئه مرة واحدة:
keytool -genkey -v -keystore algahwa-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias algahwa-release
```

### 2. الأمان:
```
✅ استخدم Environment Variables
✅ لا ترفع Keystore في Git
✅ استخدم .gitignore
✅ احفظ كلمات المرور بأمان
```

### 3. التحسين:
```
✅ استخدم Cache للـ dependencies
✅ نظف build outputs القديمة
✅ استخدم parallel builds
```

---

## 🐛 حل المشاكل الشائعة:

### المشكلة: Build timeout
```bash
# الحل:
1. قلل dependencies
2. استخدم cache
3. زود وقت timeout (في settings)
```

### المشكلة: Out of memory
```bash
# الحل:
1. زود heap size في gradle.properties:
   org.gradle.jvmargs=-Xmx4096m
2. قلل parallel threads
```

### المشكلة: Signing failed
```bash
# الحل:
1. تحقق من Keystore path
2. تحقق من كلمات المرور
3. تحقق من alias name
```

---

## 📱 بعد الحصول على APK:

### للاختبار الفوري:
```bash
# عبر ADB:
adb install app-debug.apk

# أو عبر الهاتف مباشرة:
1. انسخ APK إلى الهاتف
2. افتح الملف
3. ثبّت (فعّل "مصادر غير معروفة" إذا لزم)
```

### للنشر:
```
1. استخدم signed AAB
2. ارفع على Google Play Console
3. اختبر مع مستخدمين حقيقيين
4. انشر!
```

---

## 🎉 الخلاصة:

**لديك الآن 4 طرق لبناء APK بدون Android Studio!**

### الطريقة الموصى بها:
```
1. GitHub Actions (مجاني ومدمج)
   ↓
2. EAS Build (إذا أردت سهولة أكبر)
   ↓
3. App Center (إذا أردت analytics)
   ↓
4. Bitrise (إذا أردت أداة متخصصة)
```

### جميعها:
```
✅ مجانية
✅ لا تحتاج Android Studio
✅ بناء تلقائي
✅ APK جاهز في دقائق
✅ سهلة الاستخدام
```

---

**🎮 اختر ما يناسبك وابدأ البناء! 🚀**
