const supabaseUrl = window.location.hostname === 'localhost'
    ? 'YOUR_SUPABASE_URL'
    : window.ENV?.SUPABASE_URL;
const supabaseKey = window.location.hostname === 'localhost'
    ? 'YOUR_SUPABASE_ANON_KEY'
    : window.ENV?.SUPABASE_ANON_KEY;

const supabase = supabase.createClient(supabaseUrl, supabaseKey);

function showTab(tab) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));

    if (tab === 'login') {
        document.querySelectorAll('.auth-tab')[0].classList.add('active');
        document.getElementById('loginForm').classList.add('active');
    } else {
        document.querySelectorAll('.auth-tab')[1].classList.add('active');
        document.getElementById('registerForm').classList.add('active');
    }

    hideMessages();
}

function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    document.getElementById('successMessage').style.display = 'none';
}

function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    successDiv.textContent = message;
    successDiv.style.display = 'block';
    document.getElementById('errorMessage').style.display = 'none';
}

function hideMessages() {
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('successMessage').style.display = 'none';
}

async function handleLogin(event) {
    event.preventDefault();
    hideMessages();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
        });

        if (error) throw error;

        localStorage.setItem('user_id', data.user.id);
        localStorage.setItem('user_email', data.user.email);

        showSuccess('تم تسجيل الدخول بنجاح!');

        setTimeout(() => {
            window.location.href = '/profile.html';
        }, 1000);
    } catch (error) {
        showError(error.message || 'حدث خطأ أثناء تسجيل الدخول');
    }
}

async function handleRegister(event) {
    event.preventDefault();
    hideMessages();

    const fullName = document.getElementById('regFullName').value;
    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const birthDate = document.getElementById('regBirthDate').value;
    const country = document.getElementById('regCountry').value;
    const gender = document.getElementById('regGender').value;

    try {
        const { data: authData, error: authError } = await supabase.auth.signUp({
            email,
            password,
        });

        if (authError) throw authError;

        const { error: profileError } = await supabase
            .from('user_profiles')
            .insert({
                id: authData.user.id,
                username,
                full_name: fullName,
                birth_date: birthDate || null,
                country: country || null,
                gender: gender || null,
            });

        if (profileError) throw profileError;

        showSuccess('تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.');

        setTimeout(() => {
            showTab('login');
            document.getElementById('loginEmail').value = email;
        }, 2000);
    } catch (error) {
        showError(error.message || 'حدث خطأ أثناء إنشاء الحساب');
    }
}

async function checkAuth() {
    const { data: { session } } = await supabase.auth.getSession();

    if (session) {
        localStorage.setItem('user_id', session.user.id);
        localStorage.setItem('user_email', session.user.email);
    }
}

checkAuth();
