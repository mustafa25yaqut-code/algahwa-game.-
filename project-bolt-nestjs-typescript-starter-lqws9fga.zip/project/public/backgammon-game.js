const socket = io();

let gameState = null;
let playerId = null;
let selectedPosition = null;

function createGame() {
    const playerName = document.getElementById('playerName').value.trim();
    if (!playerName) {
        alert('الرجاء إدخال اسمك');
        return;
    }

    socket.emit('backgammon:createGame', { playerName });
}

function joinGame() {
    const playerName = document.getElementById('playerName').value.trim();
    const gameCode = document.getElementById('gameCode').value.trim().toUpperCase();

    if (!playerName || !gameCode) {
        alert('الرجاء إدخال اسمك ورمز اللعبة');
        return;
    }

    socket.emit('backgammon:joinGame', { gameId: gameCode, playerName });
}

function rollDice() {
    if (!gameState || !playerId) return;

    socket.emit('backgammon:rollDice', {
        gameId: gameState.id,
        playerId: playerId,
    });
}

function selectPosition(position) {
    if (!isMyTurn()) {
        alert('ليس دورك!');
        return;
    }

    if (!gameState.dice) {
        alert('ارمِ النرد أولاً!');
        return;
    }

    if (selectedPosition === null) {
        const myColor = getMyColor();
        const point = gameState.board[position];

        if (position === -1) {
            if (gameState.bar[myColor] > 0) {
                selectedPosition = position;
                renderGame();
            }
        } else if (point && point.checkers.length > 0 && point.checkers[point.checkers.length - 1] === myColor) {
            selectedPosition = position;
            renderGame();
        }
    } else {
        if (position === selectedPosition) {
            selectedPosition = null;
            renderGame();
        } else {
            socket.emit('backgammon:movePiece', {
                gameId: gameState.id,
                playerId: playerId,
                from: selectedPosition,
                to: position,
            });
            selectedPosition = null;
        }
    }
}

function isMyTurn() {
    if (!gameState || !playerId) return false;
    const myColor = getMyColor();
    return myColor === gameState.currentTurnColor;
}

function getMyColor() {
    const player = gameState.players.find(p => p.id === playerId);
    return player ? player.color : null;
}

function renderGame() {
    if (!gameState) return;

    document.getElementById('displayGameId').textContent = gameState.id;

    renderPlayers();
    renderDice();
    renderBoard();

    const rollButton = document.getElementById('rollButton');
    rollButton.disabled = !isMyTurn() || (gameState.dice && gameState.dice.used.some(u => !u));
}

function renderPlayers() {
    const playersList = document.getElementById('playersList');
    playersList.innerHTML = '';

    gameState.players.forEach((player) => {
        const isCurrentTurn = player.color === gameState.currentTurnColor;
        const isMe = player.id === playerId;

        const playerDiv = document.createElement('div');
        playerDiv.className = 'player-info';
        if (isCurrentTurn) playerDiv.classList.add('current-turn');
        if (isMe) playerDiv.classList.add('you');

        const colorEmoji = player.color === 'white' ? '⚪' : '⚫';
        playerDiv.innerHTML = `
            <strong>${colorEmoji} ${player.name}</strong>
            ${isMe ? ' (أنت)' : ''}
            ${isCurrentTurn ? ' 🎯' : ''}
            <br>
            <small>على اللوحة: ${player.checkers}</small>
            <br>
            <small>خارج اللعبة: ${player.bornOff}</small>
        `;
        playersList.appendChild(playerDiv);
    });
}

function renderDice() {
    const diceDisplay = document.getElementById('diceDisplay');
    diceDisplay.innerHTML = '';

    if (!gameState.dice) return;

    const dice = gameState.dice;
    const values = dice.die1 === dice.die2
        ? [dice.die1, dice.die1, dice.die1, dice.die1]
        : [dice.die1, dice.die2];

    values.forEach((value, index) => {
        const die = document.createElement('div');
        die.className = 'die';
        if (dice.used[index]) die.classList.add('used');
        die.textContent = value;
        diceDisplay.appendChild(die);
    });
}

function renderBoard() {
    const board = document.getElementById('gameBoard');
    board.innerHTML = '';

    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 13; col++) {
            if (col === 6) {
                if (row === 0 || row === 2) continue;

                const barArea = document.createElement('div');
                barArea.className = 'bar-area';

                if (gameState.bar.white > 0) {
                    const whiteBar = document.createElement('div');
                    whiteBar.style.display = 'flex';
                    whiteBar.style.flexDirection = 'column';
                    whiteBar.style.gap = '5px';
                    for (let i = 0; i < gameState.bar.white; i++) {
                        const checker = createChecker('white', -1);
                        whiteBar.appendChild(checker);
                    }
                    barArea.appendChild(whiteBar);
                }

                if (gameState.bar.black > 0) {
                    const blackBar = document.createElement('div');
                    blackBar.style.display = 'flex';
                    blackBar.style.flexDirection = 'column';
                    blackBar.style.gap = '5px';
                    for (let i = 0; i < gameState.bar.black; i++) {
                        const checker = createChecker('black', -1);
                        blackBar.appendChild(checker);
                    }
                    barArea.appendChild(blackBar);
                }

                board.appendChild(barArea);
                continue;
            }

            if (row === 1) continue;

            const adjustedCol = col > 6 ? col - 1 : col;
            const position = row === 0
                ? 12 + adjustedCol
                : 11 - adjustedCol;

            const point = document.createElement('div');
            point.className = `point ${row === 0 ? 'top' : 'bottom'} ${position % 2 === 0 ? 'light' : 'dark'}`;
            point.onclick = () => selectPosition(position);

            if (selectedPosition !== null && canMoveTo(selectedPosition, position)) {
                point.classList.add('highlighted');
            }

            const boardPoint = gameState.board[position];
            if (boardPoint && boardPoint.checkers.length > 0) {
                boardPoint.checkers.forEach((color, index) => {
                    if (index < 5 || index === boardPoint.checkers.length - 1) {
                        const checker = createChecker(color, position);
                        point.appendChild(checker);
                    } else if (index === 5) {
                        const count = document.createElement('div');
                        count.textContent = boardPoint.checkers.length;
                        count.style.color = 'white';
                        count.style.fontWeight = 'bold';
                        count.style.fontSize = '20px';
                        point.appendChild(count);
                    }
                });
            }

            board.appendChild(point);
        }
    }
}

function createChecker(color, position) {
    const checker = document.createElement('div');
    checker.className = `checker ${color}`;
    if (selectedPosition === position) {
        checker.classList.add('selected');
    }
    checker.onclick = (e) => {
        e.stopPropagation();
        selectPosition(position);
    };
    return checker;
}

function canMoveTo(from, to) {
    if (!gameState || !gameState.dice) return false;

    const diceValue = Math.abs(to - from);
    const dice = gameState.dice;
    const values = dice.die1 === dice.die2
        ? [dice.die1, dice.die1, dice.die1, dice.die1]
        : [dice.die1, dice.die2];

    return values.some((value, index) => !dice.used[index] && value === diceValue);
}

socket.on('backgammon:gameCreated', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
    alert('تم إنشاء اللعبة! شارك هذا الرمز: ' + gameState.id);
});

socket.on('backgammon:gameJoined', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
});

socket.on('backgammon:playerJoined', (data) => {
    gameState = data.game;
    renderGame();
    alert('انضم لاعب جديد: ' + data.newPlayer.name);
});

socket.on('backgammon:gameStarted', (data) => {
    gameState = data.game;
    renderGame();
    alert('بدأت اللعبة! اللاعب الأبيض يبدأ');
});

socket.on('backgammon:diceRolled', (data) => {
    gameState = data.game;
    renderGame();
});

socket.on('backgammon:pieceMoved', (data) => {
    gameState = data.game;
    selectedPosition = null;
    renderGame();
});

socket.on('backgammon:gameFinished', (data) => {
    gameState = data.game;
    renderGame();

    const winner = gameState.players.find(p => p.id === gameState.winner);
    if (winner) {
        alert('انتهت اللعبة! الفائز: ' + winner.name);
    }
});

socket.on('backgammon:error', (data) => {
    alert('خطأ: ' + data.message);
    selectedPosition = null;
    if (gameState) renderGame();
});
