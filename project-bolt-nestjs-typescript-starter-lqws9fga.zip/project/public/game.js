const socket = io('http://localhost:3000');

let currentGame = null;
let currentPlayer = null;
let currentDiceValue = null;
let gameState = [];
let players = [];

const PLAYER_COLORS = ['#e74c3c', '#3498db', '#2ecc71', '#f39c12'];
const COLOR_NAMES = ['أحمر', 'أزرق', 'أخضر', 'أصفر'];

const screens = {
    menu: document.getElementById('menu-screen'),
    create: document.getElementById('create-screen'),
    join: document.getElementById('join-screen'),
    lobby: document.getElementById('lobby-screen'),
    game: document.getElementById('game-screen'),
};

function showScreen(screenName) {
    Object.values(screens).forEach((screen) => screen.classList.remove('active'));
    screens[screenName].classList.add('active');
}

function showError(message) {
    const errorEl = document.getElementById('error-message');
    errorEl.textContent = message;
    errorEl.classList.add('show');
    setTimeout(() => {
        errorEl.classList.remove('show');
    }, 3000);
}

document.getElementById('create-game-btn').addEventListener('click', () => {
    showScreen('create');
});

document.getElementById('join-game-btn').addEventListener('click', () => {
    showScreen('join');
});

document.getElementById('back-from-create-btn').addEventListener('click', () => {
    showScreen('menu');
});

document.getElementById('back-from-join-btn').addEventListener('click', () => {
    showScreen('menu');
});

document.getElementById('create-submit-btn').addEventListener('click', () => {
    const playerName = document.getElementById('create-player-name').value.trim();
    if (!playerName) {
        showError('الرجاء إدخال اسمك');
        return;
    }
    socket.emit('createGame', { playerName });
});

document.getElementById('join-submit-btn').addEventListener('click', () => {
    const roomCode = document.getElementById('join-room-code').value.trim().toUpperCase();
    const playerName = document.getElementById('join-player-name').value.trim();
    if (!roomCode || !playerName) {
        showError('الرجاء إدخال كود الغرفة واسمك');
        return;
    }
    socket.emit('joinGame', { roomCode, playerName });
});

document.getElementById('ready-btn').addEventListener('click', () => {
    if (!currentPlayer || !currentGame) return;
    socket.emit('setReady', { playerId: currentPlayer.id, gameId: currentGame.id });
    document.getElementById('ready-btn').disabled = true;
});

document.getElementById('start-game-btn').addEventListener('click', () => {
    if (!currentGame) return;
    socket.emit('startGame', { gameId: currentGame.id });
});

document.getElementById('roll-dice-btn').addEventListener('click', () => {
    if (!currentGame || !currentPlayer) return;
    if (currentGame.current_turn !== currentPlayer.player_index) {
        showError('ليس دورك');
        return;
    }
    socket.emit('rollDice', { gameId: currentGame.id, playerIndex: currentPlayer.player_index });
    document.getElementById('roll-dice-btn').disabled = true;
});

socket.on('gameCreated', (data) => {
    currentGame = data.game;
    currentPlayer = data.player;
    document.getElementById('room-code').textContent = data.game.room_code;
    updatePlayersList([data.player]);
    showScreen('lobby');
});

socket.on('playerJoined', (data) => {
    currentGame = data.game;
    updatePlayersList(data.players);
    if (data.players.length >= 2 && data.players[0].id === currentPlayer.id) {
        const allReady = data.players.every((p) => p.is_ready);
        if (allReady) {
            document.getElementById('start-game-btn').style.display = 'block';
        }
    }
});

socket.on('playersUpdated', (data) => {
    updatePlayersList(data.players);
    if (data.players.length >= 2 && currentPlayer && data.players[0].id === currentPlayer.id) {
        const allReady = data.players.every((p) => p.is_ready);
        if (allReady) {
            document.getElementById('start-game-btn').style.display = 'block';
        }
    }
});

socket.on('gameStarted', (data) => {
    currentGame = data.game;
    socket.emit('getGameState', { gameId: currentGame.id });
});

socket.on('gameState', (data) => {
    currentGame = data.game;
    players = data.players;
    gameState = data.gameState;
    showScreen('game');
    updateGameBoard();
    updateCurrentPlayer();
    updateGamePlayersList();
});

socket.on('diceRolled', (data) => {
    currentDiceValue = data.diceValue;
    const diceEl = document.getElementById('dice');
    diceEl.textContent = data.diceValue;
    diceEl.style.animation = 'none';
    setTimeout(() => {
        diceEl.style.animation = 'diceRoll 0.5s ease';
    }, 10);

    if (data.playerIndex === currentPlayer.player_index) {
        setTimeout(() => {
            const movablePieces = getMovablePieces(currentPlayer.player_index, data.diceValue);
            if (movablePieces.length === 0) {
                socket.emit('movePiece', {
                    gameId: currentGame.id,
                    playerIndex: currentPlayer.player_index,
                    pieceIndex: 0,
                    diceValue: 0,
                });
            }
        }, 1000);
    }
});

socket.on('pieceMoved', (data) => {
    currentGame = data.game;
    gameState = data.gameState;
    currentDiceValue = null;
    updateGameBoard();
    updateCurrentPlayer();
    document.getElementById('roll-dice-btn').disabled = false;
});

socket.on('error', (data) => {
    showError(data.message);
});

function updatePlayersList(playersList) {
    const container = document.getElementById('players-list');
    container.innerHTML = '';
    playersList.forEach((player) => {
        const div = document.createElement('div');
        div.className = 'player-item';
        div.innerHTML = `
            <div style="display: flex; align-items: center;">
                <div class="player-color" style="background-color: ${PLAYER_COLORS[player.player_index]}"></div>
                <span>${player.player_name}</span>
            </div>
            <span class="${player.is_ready ? 'player-ready' : ''}">${player.is_ready ? 'جاهز' : 'غير جاهز'}</span>
        `;
        container.appendChild(div);
    });
}

function updateGamePlayersList() {
    const container = document.getElementById('game-players-list');
    container.innerHTML = '';
    players.forEach((player) => {
        const div = document.createElement('div');
        div.className = 'game-player-card';
        div.style.borderColor = PLAYER_COLORS[player.player_index];
        if (currentGame.current_turn === player.player_index) {
            div.classList.add('active');
        }
        div.innerHTML = `
            <div><strong>${player.player_name}</strong></div>
            <div style="color: ${PLAYER_COLORS[player.player_index]}">${COLOR_NAMES[player.player_index]}</div>
            <div>القطع في المنزل: ${player.pieces_home}/4</div>
        `;
        container.appendChild(div);
    });
}

function updateCurrentPlayer() {
    if (currentGame && players.length > 0) {
        const currentPlayerData = players[currentGame.current_turn];
        if (currentPlayerData) {
            document.getElementById('current-player-name').textContent = currentPlayerData.player_name;
        }
    }
}

function getMovablePieces(playerIndex, diceValue) {
    const pieces = gameState.filter(
        (p) => p.player_index === playerIndex
    );
    return pieces.filter((piece) => {
        if (piece.position === -1 && diceValue === 6) return true;
        if (piece.position >= 0 && piece.position < 52) return true;
        if (piece.position >= 100) {
            const homeStart = 100 + playerIndex * 10;
            const homeEnd = homeStart + 5;
            return piece.position + diceValue <= homeEnd;
        }
        return false;
    });
}

const canvas = document.getElementById('game-board');
const ctx = canvas.getContext('2d');

canvas.addEventListener('click', (e) => {
    if (!currentDiceValue || currentGame.current_turn !== currentPlayer.player_index) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const pieces = gameState.filter((p) => p.player_index === currentPlayer.player_index);
    pieces.forEach((piece) => {
        const pos = getPiecePosition(piece);
        const distance = Math.sqrt(Math.pow(x - pos.x, y - pos.y));
        if (distance < 15) {
            const movable = getMovablePieces(currentPlayer.player_index, currentDiceValue);
            if (movable.find((p) => p.piece_index === piece.piece_index)) {
                socket.emit('movePiece', {
                    gameId: currentGame.id,
                    playerIndex: currentPlayer.player_index,
                    pieceIndex: piece.piece_index,
                    diceValue: currentDiceValue,
                });
            }
        }
    });
});

function updateGameBoard() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawBoard();

    gameState.forEach((piece) => {
        drawPiece(piece);
    });
}

function drawBoard() {
    const cellSize = 40;
    const boardSize = 15;
    const offset = (canvas.width - boardSize * cellSize) / 2;

    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(offset, offset, boardSize * cellSize, boardSize * cellSize);

    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    for (let i = 0; i <= boardSize; i++) {
        ctx.beginPath();
        ctx.moveTo(offset, offset + i * cellSize);
        ctx.lineTo(offset + boardSize * cellSize, offset + i * cellSize);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(offset + i * cellSize, offset);
        ctx.lineTo(offset + i * cellSize, offset + boardSize * cellSize);
        ctx.stroke();
    }

    const homePositions = [
        { x: 1, y: 1, color: PLAYER_COLORS[0] },
        { x: 9, y: 1, color: PLAYER_COLORS[1] },
        { x: 1, y: 9, color: PLAYER_COLORS[2] },
        { x: 9, y: 9, color: PLAYER_COLORS[3] },
    ];

    homePositions.forEach((home) => {
        ctx.fillStyle = home.color;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(offset + home.x * cellSize, offset + home.y * cellSize, cellSize * 5, cellSize * 5);
        ctx.globalAlpha = 1;
    });

    ctx.fillStyle = '#667eea';
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, canvas.height / 2);
    ctx.lineTo(canvas.width / 2 + 60, canvas.height / 2);
    ctx.lineTo(canvas.width / 2, canvas.height / 2 - 60);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, canvas.height / 2);
    ctx.lineTo(canvas.width / 2, canvas.height / 2 + 60);
    ctx.lineTo(canvas.width / 2 - 60, canvas.height / 2);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, canvas.height / 2);
    ctx.lineTo(canvas.width / 2 - 60, canvas.height / 2);
    ctx.lineTo(canvas.width / 2, canvas.height / 2 + 60);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, canvas.height / 2);
    ctx.lineTo(canvas.width / 2, canvas.height / 2 - 60);
    ctx.lineTo(canvas.width / 2 + 60, canvas.height / 2);
    ctx.closePath();
    ctx.fill();
}

function getPiecePosition(piece) {
    const cellSize = 40;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    if (piece.position === -1) {
        const homeOffsets = [
            { x: -180, y: -180 },
            { x: 180, y: -180 },
            { x: -180, y: 180 },
            { x: 180, y: 180 },
        ];
        const offset = homeOffsets[piece.player_index];
        const pieceOffset = [
            { x: 20, y: 20 },
            { x: 60, y: 20 },
            { x: 20, y: 60 },
            { x: 60, y: 60 },
        ][piece.piece_index];
        return {
            x: centerX + offset.x + pieceOffset.x,
            y: centerY + offset.y + pieceOffset.y,
        };
    }

    if (piece.position >= 100) {
        const homeStretchPositions = [
            [
                { x: 0, y: -120 },
                { x: 0, y: -80 },
                { x: 0, y: -40 },
                { x: 0, y: -20 },
                { x: 0, y: 0 },
            ],
            [
                { x: 120, y: 0 },
                { x: 80, y: 0 },
                { x: 40, y: 0 },
                { x: 20, y: 0 },
                { x: 0, y: 0 },
            ],
            [
                { x: 0, y: 120 },
                { x: 0, y: 80 },
                { x: 0, y: 40 },
                { x: 0, y: 20 },
                { x: 0, y: 0 },
            ],
            [
                { x: -120, y: 0 },
                { x: -80, y: 0 },
                { x: -40, y: 0 },
                { x: -20, y: 0 },
                { x: 0, y: 0 },
            ],
        ];
        const playerStretch = homeStretchPositions[piece.player_index];
        const stretchIndex = (piece.position - 100 - piece.player_index * 10) % 10;
        if (stretchIndex < playerStretch.length) {
            return {
                x: centerX + playerStretch[stretchIndex].x,
                y: centerY + playerStretch[stretchIndex].y,
            };
        }
    }

    const pathPositions = [];
    for (let i = 0; i < 52; i++) {
        const side = Math.floor(i / 13);
        const posInSide = i % 13;

        let x, y;
        switch (side) {
            case 0:
                x = centerX + (posInSide - 6) * cellSize;
                y = centerY - 120;
                break;
            case 1:
                x = centerX + 120;
                y = centerY + (posInSide - 6) * cellSize;
                break;
            case 2:
                x = centerX - (posInSide - 6) * cellSize;
                y = centerY + 120;
                break;
            case 3:
                x = centerX - 120;
                y = centerY - (posInSide - 6) * cellSize;
                break;
        }
        pathPositions.push({ x, y });
    }

    return pathPositions[piece.position] || { x: centerX, y: centerY };
}

function drawPiece(piece) {
    const pos = getPiecePosition(piece);
    const color = PLAYER_COLORS[piece.player_index];

    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 12, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 10px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(piece.piece_index + 1, pos.x, pos.y);
}
