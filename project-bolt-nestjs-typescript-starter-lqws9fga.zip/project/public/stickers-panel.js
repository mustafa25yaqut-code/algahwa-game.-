class StickersPanel {
  constructor(gameId, playerId, playerName, teamPlayers = []) {
    this.gameId = gameId;
    this.playerId = playerId;
    this.playerName = playerName;
    this.teamPlayers = teamPlayers;
    this.stickersSocket = null;
    this.isOpen = false;

    this.stickers = {
      laugh: { emoji: '😂', name: 'ضحك', animation: 'bounce' },
      sad: { emoji: '😢', name: 'حزن', animation: 'shake' },
      thinking: { emoji: '🤔', name: 'تفكير', animation: 'pulse' },
      sleep: { emoji: '😴', name: 'نوم', animation: 'fade' },
      joy: { emoji: '🎉', name: 'ابتهاج', animation: 'tada' },
      surprise: { emoji: '😮', name: 'تعجب', animation: 'jump' },
    };

    this.quickMessages = {
      sorry: { text: 'آسف', emoji: '🙏', color: '#e74c3c' },
      well_done: { text: 'أحسنت', emoji: '👏', color: '#50c878' },
      good_luck: { text: 'حظ أوفر', emoji: '🍀', color: '#3498db' },
      game_over: { text: 'جيم أوفر', emoji: '🎮', color: '#e67e22' },
      hahaha: { text: 'هههههه', emoji: '🤣', color: '#f39c12' },
    };

    this.gifts = {
      flower: { emoji: '🌹', name: 'وردة', color: '#e91e63' },
      heart: { emoji: '❤️', name: 'قلب', color: '#e74c3c' },
      hammer: { emoji: '🔨', name: 'شاكوش', color: '#95a5a6' },
    };

    this.init();
  }

  init() {
    this.connectSocket();
    this.createUI();
    this.attachEventListeners();
  }

  connectSocket() {
    const serverUrl = window.location.origin;
    this.stickersSocket = io(`${serverUrl}/stickers`, {
      transports: ['websocket'],
    });

    this.stickersSocket.on('connect', () => {
      this.stickersSocket.emit('joinStickerRoom', { gameId: this.gameId });
    });

    this.stickersSocket.on('newSticker', (sticker) => {
      this.displaySticker(sticker);
    });

    this.stickersSocket.on('newQuickMessage', (message) => {
      this.displayQuickMessage(message);
    });

    this.stickersSocket.on('newGift', (gift) => {
      this.displayGift(gift);
    });
  }

  createUI() {
    const panelHTML = `
      <!-- زر فتح لوحة الملصقات -->
      <button id="open-stickers-btn" style="position: fixed; right: 20px; top: 50%; transform: translateY(-50%); background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); color: #1a1a2e; border: none; padding: 15px; border-radius: 50%; cursor: pointer; font-size: 28px; width: 60px; height: 60px; box-shadow: 0 5px 20px rgba(212, 175, 55, 0.5); z-index: 999; transition: all 0.3s;">
        😊
      </button>

      <!-- لوحة الملصقات -->
      <div id="stickers-panel" style="position: fixed; right: -350px; top: 50%; transform: translateY(-50%); width: 320px; background: rgba(26, 26, 46, 0.98); border-radius: 20px 0 0 20px; padding: 20px; box-shadow: -5px 0 30px rgba(0,0,0,0.5); z-index: 998; transition: right 0.3s ease; max-height: 90vh; overflow-y: auto;">

        <!-- عنوان -->
        <div style="text-align: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid rgba(212, 175, 55, 0.3);">
          <h3 style="color: #d4af37; margin: 0; font-size: 22px;">الملصقات والهدايا</h3>
        </div>

        <!-- الإيموجيز -->
        <div style="margin-bottom: 20px;">
          <h4 style="color: #d4af37; font-size: 16px; margin-bottom: 10px;">😊 الملصقات</h4>
          <div id="stickers-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
            ${Object.entries(this.stickers)
              .map(
                ([key, sticker]) => `
              <button class="sticker-btn" data-sticker="${key}" style="background: rgba(212, 175, 55, 0.2); border: 2px solid rgba(212, 175, 55, 0.5); padding: 15px; border-radius: 12px; cursor: pointer; font-size: 32px; transition: all 0.3s; display: flex; flex-direction: column; align-items: center; gap: 5px;">
                <span>${sticker.emoji}</span>
                <span style="font-size: 11px; color: #d4af37;">${sticker.name}</span>
              </button>
            `,
              )
              .join('')}
          </div>
        </div>

        <!-- الرسائل السريعة -->
        <div style="margin-bottom: 20px;">
          <h4 style="color: #d4af37; font-size: 16px; margin-bottom: 10px;">💬 رسائل سريعة</h4>
          <div style="display: flex; flex-direction: column; gap: 8px;">
            ${Object.entries(this.quickMessages)
              .map(
                ([key, msg]) => `
              <button class="quick-msg-btn" data-msg="${key}" style="background: ${msg.color}; color: white; border: none; padding: 12px 15px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: bold; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 10px;">
                <span style="font-size: 24px;">${msg.emoji}</span>
                <span>${msg.text}</span>
              </button>
            `,
              )
              .join('')}
          </div>
        </div>

        <!-- الهدايا -->
        <div style="margin-bottom: 20px;">
          <h4 style="color: #d4af37; font-size: 16px; margin-bottom: 10px;">🎁 إرسال هدية</h4>

          <!-- اختيار المستقبل -->
          <select id="gift-receiver" style="width: 100%; padding: 10px; border-radius: 8px; border: 2px solid rgba(212, 175, 55, 0.5); background: rgba(255,255,255,0.1); color: white; margin-bottom: 10px; font-size: 14px;">
            <option value="">اختر اللاعب...</option>
            ${this.teamPlayers
              .filter((p) => p.id !== this.playerId)
              .map((p) => `<option value="${p.id}">${p.name}</option>`)
              .join('')}
          </select>

          <!-- أزرار الهدايا -->
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
            ${Object.entries(this.gifts)
              .map(
                ([key, gift]) => `
              <button class="gift-btn" data-gift="${key}" style="background: ${gift.color}; color: white; border: none; padding: 15px; border-radius: 12px; cursor: pointer; font-size: 32px; transition: all 0.3s; display: flex; flex-direction: column; align-items: center; gap: 5px;">
                <span>${gift.emoji}</span>
                <span style="font-size: 11px;">${gift.name}</span>
              </button>
            `,
              )
              .join('')}
          </div>
        </div>

      </div>

      <!-- منطقة عرض الملصقات -->
      <div id="stickers-display" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); width: 80%; max-width: 600px; z-index: 997; pointer-events: none;"></div>
    `;

    document.body.insertAdjacentHTML('beforeend', panelHTML);
  }

  attachEventListeners() {
    const openBtn = document.getElementById('open-stickers-btn');
    const panel = document.getElementById('stickers-panel');

    openBtn.addEventListener('click', () => {
      this.isOpen = !this.isOpen;
      panel.style.right = this.isOpen ? '0' : '-350px';
      openBtn.textContent = this.isOpen ? '✖️' : '😊';
    });

    document.querySelectorAll('.sticker-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const stickerType = btn.dataset.sticker;
        this.sendSticker(stickerType);
        this.addClickEffect(btn);
      });
    });

    document.querySelectorAll('.quick-msg-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const msgType = btn.dataset.msg;
        this.sendQuickMessage(msgType);
        this.addClickEffect(btn);
      });
    });

    document.querySelectorAll('.gift-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const giftType = btn.dataset.gift;
        this.sendGift(giftType);
        this.addClickEffect(btn);
      });
    });
  }

  addClickEffect(button) {
    button.style.transform = 'scale(0.9)';
    setTimeout(() => {
      button.style.transform = 'scale(1)';
    }, 150);
  }

  sendSticker(stickerType) {
    this.stickersSocket.emit('sendSticker', {
      gameId: this.gameId,
      senderId: this.playerId,
      senderName: this.playerName,
      stickerType: stickerType,
    });
  }

  sendQuickMessage(messageType) {
    this.stickersSocket.emit('sendQuickMessage', {
      gameId: this.gameId,
      senderId: this.senderId,
      senderName: this.playerName,
      messageType: messageType,
    });
  }

  sendGift(giftType) {
    const receiverSelect = document.getElementById('gift-receiver');
    const receiverId = receiverSelect.value;

    if (!receiverId) {
      alert('الرجاء اختيار اللاعب أولاً');
      return;
    }

    const receiver = this.teamPlayers.find((p) => p.id === receiverId);
    if (!receiver) return;

    this.stickersSocket.emit('sendGift', {
      gameId: this.gameId,
      senderId: this.playerId,
      senderName: this.playerName,
      receiverId: receiverId,
      receiverName: receiver.name,
      giftType: giftType,
    });

    receiverSelect.value = '';
  }

  displaySticker(sticker) {
    const display = document.getElementById('stickers-display');
    const stickerData = this.stickers[sticker.sticker_type];

    if (!stickerData) return;

    const stickerEl = document.createElement('div');
    stickerEl.style.cssText = `
      background: linear-gradient(135deg, rgba(212, 175, 55, 0.9) 0%, rgba(244, 208, 63, 0.9) 100%);
      padding: 15px 25px;
      border-radius: 15px;
      margin-bottom: 10px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      gap: 15px;
      animation: ${this.getAnimation(stickerData.animation)} 0.6s ease;
      pointer-events: auto;
    `;

    stickerEl.innerHTML = `
      <span style="font-size: 48px;">${stickerData.emoji}</span>
      <div>
        <div style="color: #1a1a2e; font-weight: bold; font-size: 16px;">${sticker.sender_name}</div>
        <div style="color: rgba(26, 26, 46, 0.8); font-size: 13px;">${stickerData.name}</div>
      </div>
    `;

    display.appendChild(stickerEl);

    setTimeout(() => {
      stickerEl.style.opacity = '0';
      stickerEl.style.transform = 'translateY(-20px)';
      stickerEl.style.transition = 'all 0.5s ease';
      setTimeout(() => stickerEl.remove(), 500);
    }, 3000);
  }

  displayQuickMessage(message) {
    const display = document.getElementById('stickers-display');
    const msgData = this.quickMessages[message.sticker_type];

    if (!msgData) return;

    const msgEl = document.createElement('div');
    msgEl.style.cssText = `
      background: ${msgData.color};
      color: white;
      padding: 15px 25px;
      border-radius: 15px;
      margin-bottom: 10px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      gap: 15px;
      animation: slideInRight 0.5s ease;
      pointer-events: auto;
      font-weight: bold;
    `;

    msgEl.innerHTML = `
      <span style="font-size: 32px;">${msgData.emoji}</span>
      <div>
        <div style="font-size: 16px;">${message.sender_name}</div>
        <div style="font-size: 20px;">${msgData.text}</div>
      </div>
    `;

    display.appendChild(msgEl);

    setTimeout(() => {
      msgEl.style.opacity = '0';
      msgEl.style.transform = 'translateX(100%)';
      msgEl.style.transition = 'all 0.5s ease';
      setTimeout(() => msgEl.remove(), 500);
    }, 3500);
  }

  displayGift(gift) {
    const display = document.getElementById('stickers-display');
    const giftData = this.gifts[gift.gift_type];

    if (!giftData) return;

    const giftEl = document.createElement('div');
    giftEl.style.cssText = `
      background: linear-gradient(135deg, ${giftData.color}, rgba(255,255,255,0.2));
      color: white;
      padding: 20px 30px;
      border-radius: 20px;
      margin-bottom: 10px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.4);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      animation: heartBeat 0.8s ease;
      pointer-events: auto;
      font-weight: bold;
      border: 3px solid white;
    `;

    giftEl.innerHTML = `
      <span style="font-size: 64px;">${giftData.emoji}</span>
      <div style="text-align: center;">
        <div style="font-size: 18px;">${gift.sender_name}</div>
        <div style="font-size: 14px; opacity: 0.9;">أرسل ${giftData.name} إلى</div>
        <div style="font-size: 18px;">${gift.receiver_name}</div>
      </div>
    `;

    display.appendChild(giftEl);

    setTimeout(() => {
      giftEl.style.opacity = '0';
      giftEl.style.transform = 'scale(0.5)';
      giftEl.style.transition = 'all 0.6s ease';
      setTimeout(() => giftEl.remove(), 600);
    }, 4000);
  }

  getAnimation(animationType) {
    const animations = {
      bounce: 'bounce',
      shake: 'shake',
      pulse: 'pulse',
      fade: 'fadeIn',
      tada: 'tada',
      jump: 'jump',
    };
    return animations[animationType] || 'fadeIn';
  }

  destroy() {
    if (this.stickersSocket) this.stickersSocket.disconnect();

    const elements = [
      'open-stickers-btn',
      'stickers-panel',
      'stickers-display',
    ];
    elements.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.remove();
    });
  }
}

const style = document.createElement('style');
style.textContent = `
  @keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
  }

  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-10px); }
    75% { transform: translateX(10px); }
  }

  @keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes tada {
    0% { transform: scale(1) rotate(0deg); }
    10%, 20% { transform: scale(0.9) rotate(-3deg); }
    30%, 50%, 70%, 90% { transform: scale(1.1) rotate(3deg); }
    40%, 60%, 80% { transform: scale(1.1) rotate(-3deg); }
    100% { transform: scale(1) rotate(0deg); }
  }

  @keyframes jump {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-30px) scale(1.2); }
  }

  @keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }

  @keyframes heartBeat {
    0%, 100% { transform: scale(1); }
    10%, 30% { transform: scale(0.9); }
    20%, 40%, 60%, 80% { transform: scale(1.1); }
    50%, 70% { transform: scale(1.05); }
  }

  .sticker-btn:hover, .gift-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 5px 15px rgba(212, 175, 55, 0.5);
  }

  .quick-msg-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  }

  #stickers-panel::-webkit-scrollbar {
    width: 8px;
  }

  #stickers-panel::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
  }

  #stickers-panel::-webkit-scrollbar-thumb {
    background: rgba(212, 175, 55, 0.5);
    border-radius: 10px;
  }

  #stickers-panel::-webkit-scrollbar-thumb:hover {
    background: rgba(212, 175, 55, 0.7);
  }
`;
document.head.appendChild(style);

window.StickersPanel = StickersPanel;
