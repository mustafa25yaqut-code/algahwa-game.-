class FriendsPanel {
  constructor(profileId) {
    this.profileId = profileId;
    this.friends = [];
    this.pendingRequests = [];
    this.init();
  }

  async init() {
    await this.loadData();
    this.createUI();
    this.attachEventListeners();
  }

  async loadData() {
    try {
      const [friendsRes, requestsRes] = await Promise.all([
        fetch(`/friends/list/${this.profileId}`),
        fetch(`/friends/requests/${this.profileId}`),
      ]);

      const friendsData = await friendsRes.json();
      const requestsData = await requestsRes.json();

      this.friends = friendsData.success ? friendsData.friends : [];
      this.pendingRequests = requestsData.success ? requestsData.requests : [];
    } catch (error) {
      console.error('Error loading friends data:', error);
    }
  }

  createUI() {
    const panelHTML = `
      <div id="friends-panel" style="background: rgba(26, 26, 46, 0.95); border-radius: 20px; padding: 25px; margin: 20px 0; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">

        <!-- طلبات الصداقة المعلقة -->
        ${
          this.pendingRequests.length > 0
            ? `
        <div style="margin-bottom: 30px; padding-bottom: 25px; border-bottom: 2px solid rgba(212, 175, 55, 0.3);">
          <h3 style="color: #d4af37; margin-bottom: 20px; font-size: 20px; display: flex; align-items: center; gap: 10px;">
            <span style="background: #e74c3c; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px;">${this.pendingRequests.length}</span>
            طلبات الصداقة
          </h3>
          <div id="pending-requests-list" style="display: flex; flex-direction: column; gap: 12px;">
            ${this.renderPendingRequests()}
          </div>
        </div>
        `
            : ''
        }

        <!-- قائمة الأصدقاء -->
        <div>
          <h3 style="color: #d4af37; margin-bottom: 20px; font-size: 20px; display: flex; align-items: center; gap: 10px;">
            👥 الأصدقاء (${this.friends.length})
          </h3>

          ${
            this.friends.length > 0
              ? `
          <div id="friends-list" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
            ${this.renderFriends()}
          </div>
          `
              : `
          <div style="text-align: center; padding: 40px; color: rgba(255,255,255,0.5);">
            <div style="font-size: 64px; margin-bottom: 15px;">👥</div>
            <div style="font-size: 18px;">لا يوجد أصدقاء حتى الآن</div>
            <div style="font-size: 14px; margin-top: 8px;">ابحث عن لاعبين وأضفهم كأصدقاء!</div>
          </div>
          `
          }
        </div>
      </div>
    `;

    const container = document.getElementById('friends-container');
    if (container) {
      container.innerHTML = panelHTML;
    } else {
      document.body.insertAdjacentHTML('beforeend', panelHTML);
    }
  }

  renderPendingRequests() {
    return this.pendingRequests
      .map(
        (request) => `
      <div style="background: linear-gradient(135deg, rgba(231, 76, 60, 0.2) 0%, rgba(231, 76, 60, 0.1) 100%); border: 2px solid rgba(231, 76, 60, 0.5); padding: 15px; border-radius: 12px; display: flex; align-items: center; gap: 15px;">

        <div style="width: 50px; height: 50px; border-radius: 50%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); display: flex; align-items: center; justify-content: center; font-size: 24px; color: #1a1a2e; font-weight: bold; flex-shrink: 0;">
          ${request.sender.avatar_url ? `<img src="${request.sender.avatar_url}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : request.sender.username.charAt(0).toUpperCase()}
        </div>

        <div style="flex: 1; min-width: 0;">
          <div style="color: white; font-size: 16px; font-weight: bold; margin-bottom: 3px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${request.sender.username}</div>
          <div style="color: rgba(255,255,255,0.6); font-size: 13px;">المستوى ${request.sender.level || 1}</div>
          <div style="color: rgba(255,255,255,0.5); font-size: 11px; font-family: 'Courier New', monospace; margin-top: 2px;">${request.sender.player_id}</div>
        </div>

        <div style="display: flex; gap: 8px; flex-shrink: 0;">
          <button onclick="window.friendsPanel.acceptRequest('${request.id}')" style="background: #50c878; color: white; border: none; padding: 8px 15px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: bold; transition: all 0.3s;" title="قبول">
            ✓
          </button>
          <button onclick="window.friendsPanel.rejectRequest('${request.id}')" style="background: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: bold; transition: all 0.3s;" title="رفض">
            ✕
          </button>
        </div>
      </div>
    `,
      )
      .join('');
  }

  renderFriends() {
    return this.friends
      .map(
        (item) => `
      <div style="background: linear-gradient(135deg, rgba(212, 175, 55, 0.2) 0%, rgba(244, 208, 63, 0.1) 100%); border: 2px solid rgba(212, 175, 55, 0.4); padding: 20px; border-radius: 15px; display: flex; flex-direction: column; align-items: center; gap: 12px; transition: all 0.3s;">

        <div style="width: 70px; height: 70px; border-radius: 50%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); display: flex; align-items: center; justify-content: center; font-size: 32px; color: #1a1a2e; font-weight: bold; box-shadow: 0 5px 15px rgba(0,0,0,0.2);">
          ${item.friend.avatar_url ? `<img src="${item.friend.avatar_url}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : item.friend.username.charAt(0).toUpperCase()}
        </div>

        <div style="text-align: center; width: 100%;">
          <div style="color: white; font-size: 18px; font-weight: bold; margin-bottom: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.friend.username}</div>
          <div style="color: rgba(255,255,255,0.7); font-size: 14px; margin-bottom: 5px;">المستوى ${item.friend.level || 1}</div>
          <div style="background: rgba(26, 26, 46, 0.6); color: #d4af37; font-size: 12px; font-family: 'Courier New', monospace; padding: 5px 10px; border-radius: 6px; display: inline-block;">${item.friend.player_id}</div>
        </div>

        <button onclick="window.friendsPanel.removeFriend('${item.friendshipId}', '${item.friend.username}')" style="width: 100%; background: rgba(231, 76, 60, 0.8); color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: bold; transition: all 0.3s;">
          🗑️ إزالة
        </button>
      </div>
    `,
      )
      .join('');
  }

  attachEventListeners() {
    // سيتم إضافة المستمعات في renderPendingRequests و renderFriends
  }

  async acceptRequest(requestId) {
    try {
      const response = await fetch(`/friends/accept/${requestId}`, {
        method: 'POST',
      });

      const data = await response.json();

      if (data.success) {
        alert('✅ تمت إضافة الصديق بنجاح!');
        await this.loadData();
        this.createUI();
      }
    } catch (error) {
      console.error('Error accepting request:', error);
      alert('حدث خطأ أثناء قبول الطلب');
    }
  }

  async rejectRequest(requestId) {
    try {
      const response = await fetch(`/friends/reject/${requestId}`, {
        method: 'POST',
      });

      const data = await response.json();

      if (data.success) {
        alert('تم رفض الطلب');
        await this.loadData();
        this.createUI();
      }
    } catch (error) {
      console.error('Error rejecting request:', error);
      alert('حدث خطأ أثناء رفض الطلب');
    }
  }

  async removeFriend(friendshipId, friendName) {
    const confirmed = confirm(
      `هل أنت متأكد من إزالة ${friendName} من قائمة الأصدقاء؟`,
    );

    if (!confirmed) return;

    try {
      const response = await fetch(`/friends/${friendshipId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        alert('تمت إزالة الصديق');
        await this.loadData();
        this.createUI();
      }
    } catch (error) {
      console.error('Error removing friend:', error);
      alert('حدث خطأ أثناء الإزالة');
    }
  }

  async refresh() {
    await this.loadData();
    this.createUI();
  }
}

window.FriendsPanel = FriendsPanel;
