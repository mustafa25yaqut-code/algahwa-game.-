class GameControls {
  constructor(gameId, playerId, playerName, teamId = null) {
    this.gameId = gameId;
    this.playerId = playerId;
    this.playerName = playerName;
    this.teamId = teamId;

    this.voiceSocket = null;
    this.chatSocket = null;
    this.musicSocket = null;

    this.localStream = null;
    this.peerConnections = {};
    this.micEnabled = false;
    this.mutedPlayers = [];

    this.init();
  }

  init() {
    this.connectSockets();
    this.createUI();
    this.attachEventListeners();
  }

  connectSockets() {
    const serverUrl = window.location.origin;

    this.voiceSocket = io(`${serverUrl}/voice`, { transports: ['websocket'] });
    this.chatSocket = io(`${serverUrl}/chat`, { transports: ['websocket'] });
    this.musicSocket = io(`${serverUrl}/music`, { transports: ['websocket'] });

    this.voiceSocket.on('connect', () => {
      this.voiceSocket.emit('joinVoiceRoom', {
        gameId: this.gameId,
        playerId: this.playerId,
        playerName: this.playerName,
      });
    });

    this.chatSocket.on('connect', () => {
      this.chatSocket.emit('joinChatRoom', {
        gameId: this.gameId,
        playerId: this.playerId,
        teamId: this.teamId,
      });
    });

    this.musicSocket.on('connect', () => {
      this.musicSocket.emit('joinMusicRoom', {
        gameId: this.gameId,
        teamId: this.teamId,
      });
    });

    this.setupVoiceListeners();
    this.setupChatListeners();
    this.setupMusicListeners();
  }

  setupVoiceListeners() {
    this.voiceSocket.on('micToggled', (data) => {
      console.log('Mic toggled:', data);
    });

    this.voiceSocket.on('voiceOffer', async (data) => {
      await this.handleVoiceOffer(data);
    });

    this.voiceSocket.on('voiceAnswer', async (data) => {
      await this.handleVoiceAnswer(data);
    });

    this.voiceSocket.on('iceCandidate', async (data) => {
      await this.handleIceCandidate(data);
    });
  }

  setupChatListeners() {
    this.chatSocket.on('newMessage', (message) => {
      this.displayMessage(message, 'public');
    });

    this.chatSocket.on('newTeamMessage', (message) => {
      this.displayMessage(message, 'team');
    });
  }

  setupMusicListeners() {
    this.musicSocket.on('musicStarted', (music) => {
      this.playMusic(music);
    });

    this.musicSocket.on('musicPaused', () => {
      this.pauseMusic();
    });

    this.musicSocket.on('musicResumed', () => {
      this.resumeMusic();
    });

    this.musicSocket.on('musicStopped', () => {
      this.stopMusic();
    });
  }

  createUI() {
    const controlsHTML = `
      <div id="game-controls" style="position: fixed; bottom: 20px; left: 20px; right: 20px; background: rgba(26, 26, 46, 0.95); padding: 15px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.3); z-index: 1000; display: flex; flex-direction: column; gap: 15px;">

        <!-- Voice Controls -->
        <div style="display: flex; align-items: center; gap: 10px; padding-bottom: 15px; border-bottom: 2px solid rgba(212, 175, 55, 0.3);">
          <button id="toggle-mic" class="control-btn" style="background: #e74c3c; color: white; border: none; padding: 12px; border-radius: 50%; cursor: pointer; font-size: 20px; width: 50px; height: 50px; transition: all 0.3s;">
            🎤
          </button>
          <input type="range" id="volume-slider" min="0" max="100" value="50" style="flex: 1; height: 8px; border-radius: 5px; background: rgba(255,255,255,0.2);">
          <span id="volume-label" style="color: white; min-width: 45px; text-align: right;">50%</span>
        </div>

        <!-- Chat Section -->
        <div style="display: flex; flex-direction: column; gap: 10px;">
          <div id="chat-messages" style="max-height: 150px; overflow-y: auto; background: rgba(0,0,0,0.3); padding: 10px; border-radius: 10px; color: white; font-size: 14px; display: none;"></div>

          <div style="display: flex; gap: 10px;">
            <input type="text" id="chat-input" placeholder="اكتب رسالة..." style="flex: 1; padding: 10px; border-radius: 8px; border: 2px solid rgba(212, 175, 55, 0.5); background: rgba(255,255,255,0.1); color: white; font-size: 14px;">
            <button id="send-public" style="background: #d4af37; color: #1a1a2e; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px;">عام</button>
            ${this.teamId ? '<button id="send-team" style="background: #50c878; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 14px;">فريق</button>' : ''}
            <button id="toggle-chat" style="background: #30d5c8; color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-size: 18px;">💬</button>
          </div>
        </div>

        <!-- Music Controls -->
        ${this.teamId ? `
        <div style="display: flex; gap: 10px; align-items: center; padding-top: 15px; border-top: 2px solid rgba(212, 175, 55, 0.3);">
          <input type="text" id="music-url" placeholder="رابط الأغنية (YouTube, SoundCloud...)" style="flex: 1; padding: 10px; border-radius: 8px; border: 2px solid rgba(212, 175, 55, 0.5); background: rgba(255,255,255,0.1); color: white; font-size: 13px;">
          <button id="play-music" style="background: #9b59b6; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 16px;">🎵 تشغيل</button>
          <button id="stop-music" style="background: #e74c3c; color: white; border: none; padding: 10px; border-radius: 8px; cursor: pointer; font-size: 16px; display: none;">⏹️</button>
        </div>
        <div id="music-info" style="color: #d4af37; font-size: 13px; text-align: center; display: none;"></div>
        ` : ''}
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', controlsHTML);
  }

  attachEventListeners() {
    const toggleMic = document.getElementById('toggle-mic');
    const volumeSlider = document.getElementById('volume-slider');
    const volumeLabel = document.getElementById('volume-label');
    const chatInput = document.getElementById('chat-input');
    const sendPublic = document.getElementById('send-public');
    const sendTeam = document.getElementById('send-team');
    const toggleChat = document.getElementById('toggle-chat');

    toggleMic.addEventListener('click', () => this.toggleMic());

    volumeSlider.addEventListener('input', (e) => {
      const volume = e.target.value;
      volumeLabel.textContent = `${volume}%`;
      this.updateVolume(volume);
    });

    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.sendPublicMessage();
      }
    });

    sendPublic.addEventListener('click', () => this.sendPublicMessage());

    if (sendTeam) {
      sendTeam.addEventListener('click', () => this.sendTeamMessage());
    }

    toggleChat.addEventListener('click', () => {
      const chatMessages = document.getElementById('chat-messages');
      chatMessages.style.display =
        chatMessages.style.display === 'none' ? 'block' : 'none';
    });

    if (this.teamId) {
      const playMusicBtn = document.getElementById('play-music');
      const stopMusicBtn = document.getElementById('stop-music');

      playMusicBtn.addEventListener('click', () => this.startMusic());
      stopMusicBtn.addEventListener('click', () => this.stopMusicControl());
    }
  }

  async toggleMic() {
    const button = document.getElementById('toggle-mic');

    if (!this.micEnabled) {
      try {
        this.localStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });
        this.micEnabled = true;
        button.style.background = '#50c878';
        button.textContent = '🎤';

        this.voiceSocket.emit('toggleMic', {
          playerId: this.playerId,
          gameId: this.gameId,
          enabled: true,
        });

        this.connectToOtherPlayers();
      } catch (error) {
        console.error('Error accessing microphone:', error);
        alert('لا يمكن الوصول إلى المايك. الرجاء التحقق من الأذونات.');
      }
    } else {
      if (this.localStream) {
        this.localStream.getTracks().forEach((track) => track.stop());
        this.localStream = null;
      }

      Object.values(this.peerConnections).forEach((pc) => pc.close());
      this.peerConnections = {};

      this.micEnabled = false;
      button.style.background = '#e74c3c';

      this.voiceSocket.emit('toggleMic', {
        playerId: this.playerId,
        gameId: this.gameId,
        enabled: false,
      });
    }
  }

  async connectToOtherPlayers() {
    console.log('Connecting to other players...');
  }

  async handleVoiceOffer(data) {
    const pc = this.createPeerConnection(data.from, data.socketId);

    await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);

    this.voiceSocket.emit('voiceAnswer', {
      targetSocketId: data.socketId,
      answer: answer,
      from: this.playerId,
    });
  }

  async handleVoiceAnswer(data) {
    const pc = this.peerConnections[data.from];
    if (pc) {
      await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
    }
  }

  async handleIceCandidate(data) {
    const pc = this.peerConnections[data.from];
    if (pc && data.candidate) {
      await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
    }
  }

  createPeerConnection(playerId, socketId) {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        pc.addTrack(track, this.localStream);
      });
    }

    pc.ontrack = (event) => {
      if (!this.mutedPlayers.includes(playerId)) {
        const audio = new Audio();
        audio.srcObject = event.streams[0];
        audio.play();
      }
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.voiceSocket.emit('iceCandidate', {
          targetSocketId: socketId,
          candidate: event.candidate,
          from: this.playerId,
        });
      }
    };

    this.peerConnections[playerId] = pc;
    return pc;
  }

  updateVolume(volume) {
    this.voiceSocket.emit('updateVolume', {
      playerId: this.playerId,
      gameId: this.gameId,
      volume: parseInt(volume),
    });
  }

  sendPublicMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (message) {
      this.chatSocket.emit('sendPublicMessage', {
        gameId: this.gameId,
        playerId: this.playerId,
        playerName: this.playerName,
        message: message,
      });

      input.value = '';
    }
  }

  sendTeamMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (message && this.teamId) {
      this.chatSocket.emit('sendTeamMessage', {
        gameId: this.gameId,
        playerId: this.playerId,
        playerName: this.playerName,
        teamId: this.teamId,
        message: message,
      });

      input.value = '';
    }
  }

  displayMessage(message, type) {
    const chatMessages = document.getElementById('chat-messages');
    chatMessages.style.display = 'block';

    const messageEl = document.createElement('div');
    messageEl.style.cssText = `
      padding: 8px;
      margin-bottom: 5px;
      border-radius: 8px;
      background: ${type === 'team' ? 'rgba(80, 200, 120, 0.2)' : 'rgba(212, 175, 55, 0.2)'};
      border-right: 3px solid ${type === 'team' ? '#50c878' : '#d4af37'};
    `;

    const time = new Date(message.created_at).toLocaleTimeString('ar', {
      hour: '2-digit',
      minute: '2-digit',
    });

    messageEl.innerHTML = `
      <div style="display: flex; justify-content: space-between; margin-bottom: 3px;">
        <span style="font-weight: bold; color: ${type === 'team' ? '#50c878' : '#d4af37'};">
          ${message.player_name} ${type === 'team' ? '(فريق)' : ''}
        </span>
        <span style="font-size: 11px; color: rgba(255,255,255,0.5);">${time}</span>
      </div>
      <div style="color: white; word-wrap: break-word;">${message.message_content}</div>
    `;

    chatMessages.appendChild(messageEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    if (chatMessages.children.length > 50) {
      chatMessages.removeChild(chatMessages.firstChild);
    }
  }

  startMusic() {
    const input = document.getElementById('music-url');
    const url = input.value.trim();

    if (url) {
      this.musicSocket.emit('playMusic', {
        gameId: this.gameId,
        teamId: this.teamId,
        musicUrl: url,
        musicTitle: 'أغنية',
        playerId: this.playerId,
        playerName: this.playerName,
      });
    }
  }

  playMusic(music) {
    const musicInfo = document.getElementById('music-info');
    const playBtn = document.getElementById('play-music');
    const stopBtn = document.getElementById('stop-music');

    musicInfo.textContent = `🎵 يشغّل: ${music.started_by_player_name}`;
    musicInfo.style.display = 'block';
    playBtn.style.display = 'none';
    stopBtn.style.display = 'block';

    console.log('Playing music:', music.music_url);
  }

  pauseMusic() {
    console.log('Music paused');
  }

  resumeMusic() {
    console.log('Music resumed');
  }

  stopMusicControl() {
    this.musicSocket.emit('stopMusic', {
      gameId: this.gameId,
      teamId: this.teamId,
    });

    this.stopMusic();
  }

  stopMusic() {
    const musicInfo = document.getElementById('music-info');
    const playBtn = document.getElementById('play-music');
    const stopBtn = document.getElementById('stop-music');
    const musicUrl = document.getElementById('music-url');

    musicInfo.style.display = 'none';
    playBtn.style.display = 'block';
    stopBtn.style.display = 'none';
    musicUrl.value = '';

    console.log('Music stopped');
  }

  destroy() {
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
    }

    Object.values(this.peerConnections).forEach((pc) => pc.close());

    if (this.voiceSocket) this.voiceSocket.disconnect();
    if (this.chatSocket) this.chatSocket.disconnect();
    if (this.musicSocket) this.musicSocket.disconnect();

    const controls = document.getElementById('game-controls');
    if (controls) controls.remove();
  }
}

window.GameControls = GameControls;
