const socket = io();

let gameState = null;
let playerId = null;
let selectedHandCard = null;
let selectedTableCards = [];

const suitSymbols = {
    hearts: '♥',
    diamonds: '♦',
    clubs: '♣',
    spades: '♠'
};

function createGame() {
    const playerName = document.getElementById('playerName').value.trim();
    if (!playerName) {
        alert('الرجاء إدخال اسمك');
        return;
    }

    socket.emit('jakaro:createGame', { playerName });
}

function joinGame() {
    const playerName = document.getElementById('playerName').value.trim();
    const gameCode = document.getElementById('gameCode').value.trim().toUpperCase();

    if (!playerName || !gameCode) {
        alert('الرجاء إدخال اسمك ورمز اللعبة');
        return;
    }

    socket.emit('jakaro:joinGame', { gameId: gameCode, playerName });
}

function selectHandCard(card) {
    if (!isMyTurn()) {
        alert('ليس دورك!');
        return;
    }

    selectedHandCard = card;
    selectedTableCards = [];

    document.getElementById('overlay').classList.add('active');
    document.getElementById('captureMode').classList.add('active');
    renderCapturableCards();
}

function selectTableCard(card) {
    const index = selectedTableCards.findIndex(c => c.id === card.id);
    if (index === -1) {
        selectedTableCards.push(card);
    } else {
        selectedTableCards.splice(index, 1);
    }
    renderCapturableCards();
}

function renderCapturableCards() {
    const container = document.getElementById('capturableCards');
    container.innerHTML = '';

    if (!gameState || !selectedHandCard) return;

    const capturableCards = findCapturableCards(selectedHandCard);

    if (capturableCards.length === 0) {
        container.innerHTML = '<p style="color: #666; text-align: center;">لا يمكن أخذ أي أوراق بهذه الورقة</p>';
        return;
    }

    const tableDiv = document.createElement('div');
    tableDiv.style.display = 'flex';
    tableDiv.style.gap = '10px';
    tableDiv.style.flexWrap = 'wrap';
    tableDiv.style.justifyContent = 'center';
    tableDiv.style.marginTop = '20px';

    capturableCards.forEach(card => {
        const cardElement = createCardElement(card, () => selectTableCard(card));
        const isSelected = selectedTableCards.some(c => c.id === card.id);
        if (isSelected) {
            cardElement.classList.add('selected');
        }
        tableDiv.appendChild(cardElement);
    });

    container.appendChild(tableDiv);
}

function findCapturableCards(card) {
    if (!gameState) return [];

    const cardValue = getCardValue(card);
    const capturable = [];

    for (let i = 0; i < gameState.tableCards.length; i++) {
        const tableCard = gameState.tableCards[i];
        if (getCardValue(tableCard) === cardValue) {
            capturable.push(tableCard);
        }
    }

    for (let i = 0; i < gameState.tableCards.length; i++) {
        for (let j = i + 1; j < gameState.tableCards.length; j++) {
            const sum = getCardValue(gameState.tableCards[i]) + getCardValue(gameState.tableCards[j]);
            if (sum === cardValue) {
                if (!capturable.some(c => c.id === gameState.tableCards[i].id)) {
                    capturable.push(gameState.tableCards[i]);
                }
                if (!capturable.some(c => c.id === gameState.tableCards[j].id)) {
                    capturable.push(gameState.tableCards[j]);
                }
            }
        }
    }

    return capturable;
}

function getCardValue(card) {
    const rankValues = {
        'A': 1, '2': 2, '3': 3, '4': 4, '5': 5,
        '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
        'J': 11, 'Q': 12, 'K': 13
    };
    return rankValues[card.rank] || 0;
}

function confirmCapture() {
    if (!selectedHandCard) return;

    const capturableCards = findCapturableCards(selectedHandCard);
    const validSelection = selectedTableCards.every(card =>
        capturableCards.some(c => c.id === card.id)
    );

    if (!validSelection && selectedTableCards.length > 0) {
        alert('اختيار غير صحيح! الأوراق المختارة لا يمكن أخذها معاً');
        return;
    }

    socket.emit('jakaro:playCard', {
        gameId: gameState.id,
        playerId: playerId,
        card: selectedHandCard,
        capturedCards: selectedTableCards.length > 0 ? selectedTableCards : undefined,
    });

    cancelCardPlay();
}

function playWithoutCapture() {
    if (!selectedHandCard) return;

    socket.emit('jakaro:playCard', {
        gameId: gameState.id,
        playerId: playerId,
        card: selectedHandCard,
    });

    cancelCardPlay();
}

function cancelCardPlay() {
    selectedHandCard = null;
    selectedTableCards = [];
    document.getElementById('overlay').classList.remove('active');
    document.getElementById('captureMode').classList.remove('active');
}

function isMyTurn() {
    if (!gameState || !playerId) return false;
    const currentPlayer = gameState.players[gameState.currentTurnIndex];
    return currentPlayer && currentPlayer.id === playerId;
}

function renderGame() {
    if (!gameState) return;

    document.getElementById('displayGameId').textContent = gameState.id;
    document.getElementById('playerCount').textContent = gameState.players.length;
    document.getElementById('deckCount').textContent = gameState.deck.length;
    document.getElementById('roundNumber').textContent = gameState.round;

    renderPlayers();
    renderTable();
    renderPlayerHand();
}

function renderPlayers() {
    const playersList = document.getElementById('playersList');
    playersList.innerHTML = '';

    gameState.players.forEach((player, index) => {
        const isCurrentTurn = index === gameState.currentTurnIndex;
        const isMe = player.id === playerId;

        const playerDiv = document.createElement('div');
        playerDiv.className = 'player-card';
        if (isCurrentTurn) playerDiv.classList.add('current-turn');
        if (isMe) playerDiv.classList.add('you');

        playerDiv.innerHTML = `
            <strong>${player.name}</strong>
            ${isMe ? ' (أنت)' : ''}
            ${isCurrentTurn ? ' 🎯' : ''}
            <br>
            <small>الأوراق: ${player.hand.length}</small>
            <br>
            <small>النقاط: ${player.score}</small>
            <br>
            <small>المجموعة: ${player.collectedCards.length} ورقة</small>
        `;
        playersList.appendChild(playerDiv);
    });
}

function renderTable() {
    const table = document.getElementById('gameTable');
    table.innerHTML = '';

    if (gameState.tableCards.length === 0) {
        table.innerHTML = '<p style="color: white;">لا توجد أوراق على الطاولة</p>';
        return;
    }

    gameState.tableCards.forEach(card => {
        const cardElement = createCardElement(card, null, true);
        table.appendChild(cardElement);
    });
}

function renderPlayerHand() {
    const hand = document.getElementById('playerHand');
    hand.innerHTML = '';

    const player = gameState.players.find(p => p.id === playerId);
    if (!player) return;

    if (player.hand.length === 0) {
        hand.innerHTML = '<p>لا توجد أوراق</p>';
        return;
    }

    player.hand.forEach(card => {
        const cardElement = createCardElement(card, () => selectHandCard(card));
        hand.appendChild(cardElement);
    });
}

function createCardElement(card, onClick, isTableCard = false) {
    const cardDiv = document.createElement('div');
    cardDiv.className = `card ${card.suit}`;
    if (isTableCard) cardDiv.classList.add('table-card');
    if (onClick) cardDiv.onclick = onClick;

    const rankTop = document.createElement('div');
    rankTop.className = 'card-rank';
    rankTop.textContent = card.rank;

    const suit = document.createElement('div');
    suit.className = 'card-suit';
    suit.innerHTML = `<span class="suit-symbol">${suitSymbols[card.suit]}</span>`;

    const rankBottom = document.createElement('div');
    rankBottom.className = 'card-rank';
    rankBottom.textContent = card.rank;
    rankBottom.style.transform = 'rotate(180deg)';

    cardDiv.appendChild(rankTop);
    cardDiv.appendChild(suit);
    cardDiv.appendChild(rankBottom);

    return cardDiv;
}

socket.on('jakaro:gameCreated', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
    alert('تم إنشاء اللعبة! شارك هذا الرمز: ' + gameState.id);
});

socket.on('jakaro:gameJoined', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
});

socket.on('jakaro:playerJoined', (data) => {
    gameState = data.game;
    renderGame();
    alert('انضم لاعب جديد: ' + data.newPlayer.name);
});

socket.on('jakaro:gameStarted', (data) => {
    gameState = data.game;
    renderGame();
    alert('بدأت اللعبة!');
});

socket.on('jakaro:cardPlayed', (data) => {
    gameState = data.game;
    renderGame();
});

socket.on('jakaro:gameFinished', (data) => {
    gameState = data.game;
    renderGame();

    const winner = gameState.players.find(p => p.id === gameState.winner);
    if (winner) {
        const scores = gameState.players.map(p => `${p.name}: ${p.score}`).join('\n');
        alert(`انتهت اللعبة!\n\nالفائز: ${winner.name}\n\nالنقاط النهائية:\n${scores}`);
    }
});

socket.on('jakaro:error', (data) => {
    alert('خطأ: ' + data.message);
});
