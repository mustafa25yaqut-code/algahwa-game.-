const API_URL = window.location.origin;
let currentUser = null;

async function checkAuth() {
    const userId = localStorage.getItem('user_id');
    if (!userId) {
        window.location.href = '/auth.html';
        return;
    }
    await loadProfile(userId);
}

async function loadProfile(userId) {
    try {
        const response = await fetch(`${API_URL}/profile/${userId}`);
        const profile = await response.json();

        currentUser = profile;

        document.getElementById('profileName').textContent = profile.full_name;
        document.getElementById('profileUsername').textContent = '@' + profile.username;
        document.getElementById('levelBadge').textContent = `المستوى ${profile.level}`;

        const initial = profile.full_name.charAt(0);
        document.getElementById('avatarInitial').textContent = initial;

        const currentXP = profile.xp % 100;
        const nextLevelXP = 100;
        document.getElementById('xpProgress').style.width = `${(currentXP / nextLevelXP) * 100}%`;
        document.getElementById('xpText').textContent = `${profile.xp} XP / ${(profile.level * 100)} XP للمستوى التالي`;

        await loadStatistics(userId);
        await loadAchievements(userId);
        await loadFriends(userId);
        await loadFriendRequests(userId);
    } catch (error) {
        console.error('Error loading profile:', error);
        alert('حدث خطأ أثناء تحميل الملف الشخصي');
    }
}

async function loadStatistics(userId) {
    try {
        const response = await fetch(`${API_URL}/profile/${userId}/statistics`);
        const stats = await response.json();

        const statsGrid = document.getElementById('statsGrid');
        statsGrid.innerHTML = '';

        const gameNames = {
            ludo: 'لودو',
            domino: 'دومينو',
            jakaro: 'جاكرو',
            backgammon: 'طاولي'
        };

        const gameIcons = {
            ludo: '🎲',
            domino: '🀄',
            jakaro: '♠️',
            backgammon: '⚫'
        };

        const allGames = ['ludo', 'domino', 'jakaro', 'backgammon'];

        allGames.forEach(gameType => {
            const stat = stats.find(s => s.game_type === gameType) || {
                game_type: gameType,
                wins: 0,
                losses: 0,
                total_games: 0,
                win_rate: 0
            };

            const card = document.createElement('div');
            card.className = 'stat-card';
            card.innerHTML = `
                <h3>${gameIcons[gameType]} ${gameNames[gameType]}</h3>
                <div class="stat-row">
                    <span>المباريات:</span>
                    <span>${stat.total_games}</span>
                </div>
                <div class="stat-row">
                    <span>الانتصارات:</span>
                    <span style="color: #4caf50">${stat.wins}</span>
                </div>
                <div class="stat-row">
                    <span>الخسائر:</span>
                    <span style="color: #f44336">${stat.losses}</span>
                </div>
                <div class="stat-row">
                    <span>نسبة الفوز:</span>
                    <span>${stat.win_rate.toFixed(1)}%</span>
                </div>
            `;
            statsGrid.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

async function loadAchievements(userId) {
    try {
        const response = await fetch(`${API_URL}/profile/${userId}/achievements`);
        const userAchievements = await response.json();

        const achievementsGrid = document.getElementById('achievementsGrid');
        achievementsGrid.innerHTML = '';

        const allAchievements = [
            { code: 'first_win', name: 'الفوز الأول', description: 'فز بأول مباراة لك', icon: '🏆' },
            { code: 'win_streak_5', name: 'سلسلة انتصارات', description: 'فز بـ 5 مباريات متتالية', icon: '🔥' },
            { code: 'games_10', name: 'لاعب نشط', description: 'العب 10 مباريات', icon: '⚡' },
            { code: 'games_50', name: 'لاعب محترف', description: 'العب 50 مباراة', icon: '💎' },
            { code: 'games_100', name: 'أسطورة', description: 'العب 100 مباراة', icon: '👑' },
            { code: 'friend_5', name: 'اجتماعي', description: 'أضف 5 أصدقاء', icon: '👥' },
            { code: 'all_games', name: 'متعدد المواهب', description: 'العب جميع أنواع الألعاب', icon: '🎮' },
            { code: 'level_10', name: 'مستوى 10', description: 'وصل للمستوى 10', icon: '⭐' },
            { code: 'level_25', name: 'مستوى 25', description: 'وصل للمستوى 25', icon: '🌟' },
            { code: 'level_50', name: 'مستوى 50', description: 'وصل للمستوى 50', icon: '✨' },
        ];

        allAchievements.forEach(achievement => {
            const unlocked = userAchievements.some(ua => ua.achievement?.code === achievement.code);

            const card = document.createElement('div');
            card.className = `achievement-card ${unlocked ? '' : 'locked'}`;
            card.innerHTML = `
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-name">${achievement.name}</div>
                <div class="achievement-desc">${achievement.description}</div>
                ${unlocked ? '<div style="color: #4caf50; margin-top: 10px;">✓ تم الإنجاز</div>' : ''}
            `;
            achievementsGrid.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading achievements:', error);
    }
}

async function loadFriends(userId) {
    try {
        const response = await fetch(`${API_URL}/profile/${userId}/friends`);
        const friends = await response.json();

        const friendsList = document.getElementById('friendsList');
        friendsList.innerHTML = '';

        if (friends.length === 0) {
            friendsList.innerHTML = '<p style="color: rgba(255, 255, 255, 0.7);">لا يوجد أصدقاء بعد</p>';
            return;
        }

        friends.forEach(friend => {
            const card = document.createElement('div');
            card.className = 'friend-card';
            card.innerHTML = `
                <div class="friend-avatar">${friend.full_name.charAt(0)}</div>
                <div>
                    <div style="color: white; font-weight: bold;">${friend.full_name}</div>
                    <div style="color: rgba(255, 255, 255, 0.7); font-size: 14px;">@${friend.username}</div>
                    <div style="color: rgba(255, 255, 255, 0.7); font-size: 14px;">المستوى ${friend.level}</div>
                </div>
            `;
            friendsList.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading friends:', error);
    }
}

async function loadFriendRequests(userId) {
    try {
        const response = await fetch(`${API_URL}/profile/${userId}/friend-requests`);
        const requests = await response.json();

        const requestsDiv = document.getElementById('friendRequests');
        requestsDiv.innerHTML = '';

        if (requests.length === 0) {
            requestsDiv.innerHTML = '<p style="color: rgba(255, 255, 255, 0.7);">لا توجد طلبات صداقة</p>';
            return;
        }

        for (const request of requests) {
            const requesterResponse = await fetch(`${API_URL}/profile/${request.requester_id}`);
            const requester = await requesterResponse.json();

            const card = document.createElement('div');
            card.className = 'friend-card';
            card.innerHTML = `
                <div class="friend-avatar">${requester.full_name.charAt(0)}</div>
                <div style="flex: 1;">
                    <div style="color: white; font-weight: bold;">${requester.full_name}</div>
                    <div style="color: rgba(255, 255, 255, 0.7); font-size: 14px;">@${requester.username}</div>
                </div>
                <button onclick="respondToRequest('${request.id}', true)" class="edit-button" style="margin: 0 5px;">قبول</button>
                <button onclick="respondToRequest('${request.id}', false)" class="logout-button" style="margin: 0;">رفض</button>
            `;
            requestsDiv.appendChild(card);
        }
    } catch (error) {
        console.error('Error loading friend requests:', error);
    }
}

async function sendFriendRequest() {
    const username = document.getElementById('friendUsername').value.trim();
    if (!username) {
        alert('الرجاء إدخال اسم المستخدم');
        return;
    }

    const userId = localStorage.getItem('user_id');

    try {
        const response = await fetch(`${API_URL}/profile/${userId}/friend-request`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ addressee_username: username }),
        });

        if (response.ok) {
            alert('تم إرسال طلب الصداقة!');
            document.getElementById('friendUsername').value = '';
        } else {
            const error = await response.json();
            alert('خطأ: ' + (error.message || 'حدث خطأ'));
        }
    } catch (error) {
        alert('حدث خطأ أثناء إرسال الطلب');
    }
}

async function respondToRequest(friendshipId, accept) {
    const userId = localStorage.getItem('user_id');

    try {
        const response = await fetch(`${API_URL}/profile/${userId}/friend-request`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ friendship_id: friendshipId, accept }),
        });

        if (response.ok) {
            alert(accept ? 'تم قبول الطلب!' : 'تم رفض الطلب');
            await loadFriends(userId);
            await loadFriendRequests(userId);
        } else {
            alert('حدث خطأ');
        }
    } catch (error) {
        alert('حدث خطأ أثناء الرد على الطلب');
    }
}

function showProfileTab(tab) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

    const tabs = document.querySelectorAll('.tab');
    if (tab === 'stats') {
        tabs[0].classList.add('active');
        document.getElementById('statsTab').classList.add('active');
    } else if (tab === 'achievements') {
        tabs[1].classList.add('active');
        document.getElementById('achievementsTab').classList.add('active');
    } else if (tab === 'friends') {
        tabs[2].classList.add('active');
        document.getElementById('friendsTab').classList.add('active');
    }
}

async function handleLogout() {
    localStorage.removeItem('user_id');
    localStorage.removeItem('user_email');
    window.location.href = '/auth.html';
}

checkAuth();
