class MatchmakingSystem {
  constructor(profileId, gameType) {
    this.profileId = profileId;
    this.gameType = gameType;
    this.queueId = null;
    this.sessionId = null;
    this.socket = null;
    this.checkInterval = null;
    this.waitTime = 0;
    this.isSearching = false;
  }

  async startMatchmaking(betAmount) {
    if (this.isSearching) {
      throw new Error('Already searching for match');
    }

    this.isSearching = true;
    this.waitTime = 0;

    try {
      const response = await fetch('/matchmaking/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profileId: this.profileId,
          gameType: this.gameType,
          betAmount: betAmount,
        }),
      });

      const data = await response.json();

      if (data.success) {
        this.queueId = data.queueEntry.id;
        this.startWaitingUI();
        this.checkForMatch();
        return data.queueEntry;
      } else {
        throw new Error('Failed to join queue');
      }
    } catch (error) {
      this.isSearching = false;
      throw error;
    }
  }

  startWaitingUI() {
    const modal = document.createElement('div');
    modal.id = 'matchmaking-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.9);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(10px);
    `;

    modal.innerHTML = `
      <div style="background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%); border-radius: 30px; padding: 50px; max-width: 600px; width: 90%; box-shadow: 0 20px 80px rgba(0,0,0,0.5); border: 3px solid rgba(212, 175, 55, 0.5); text-align: center;">

        <div style="font-size: 80px; margin-bottom: 30px; animation: searchPulse 2s infinite;">
          🔍
        </div>

        <h2 style="color: #d4af37; font-size: 36px; margin-bottom: 20px; text-shadow: 0 0 20px rgba(212, 175, 55, 0.5);">
          البحث عن منافس
        </h2>

        <p style="color: rgba(255,255,255,0.8); font-size: 20px; margin-bottom: 30px;">
          جارٍ البحث عن لاعب بنفس قيمة الرهان...
        </p>

        <div style="background: rgba(0,0,0,0.3); border-radius: 20px; padding: 20px; margin-bottom: 30px;">
          <div style="color: #d4af37; font-size: 18px; margin-bottom: 10px;">وقت الانتظار</div>
          <div id="wait-time" style="color: white; font-size: 48px; font-weight: bold; font-family: 'Courier New', monospace;">
            00:00
          </div>
        </div>

        <div style="margin-bottom: 30px;">
          <div class="loading-dots" style="display: flex; justify-content: center; gap: 10px;">
            <div class="dot" style="width: 15px; height: 15px; background: #d4af37; border-radius: 50%; animation: bounce 1.4s infinite ease-in-out both; animation-delay: -0.32s;"></div>
            <div class="dot" style="width: 15px; height: 15px; background: #d4af37; border-radius: 50%; animation: bounce 1.4s infinite ease-in-out both; animation-delay: -0.16s;"></div>
            <div class="dot" style="width: 15px; height: 15px; background: #d4af37; border-radius: 50%; animation: bounce 1.4s infinite ease-in-out both;"></div>
          </div>
        </div>

        <button onclick="window.matchmaking.cancelMatchmaking()" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); color: white; border: none; padding: 15px 40px; border-radius: 15px; cursor: pointer; font-size: 18px; font-weight: bold; transition: all 0.3s;">
          ❌ إلغاء البحث
        </button>
      </div>

      <style>
        @keyframes searchPulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.2); opacity: 0.8; }
        }

        @keyframes bounce {
          0%, 80%, 100% { transform: scale(0); }
          40% { transform: scale(1); }
        }
      </style>
    `;

    document.body.appendChild(modal);

    this.updateWaitTime();
  }

  updateWaitTime() {
    const waitTimeEl = document.getElementById('wait-time');

    setInterval(() => {
      if (!this.isSearching) return;

      this.waitTime++;
      const minutes = Math.floor(this.waitTime / 60);
      const seconds = this.waitTime % 60;

      if (waitTimeEl) {
        waitTimeEl.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      }
    }, 1000);
  }

  checkForMatch() {
    this.checkInterval = setInterval(async () => {
      try {
        const response = await fetch(`/matchmaking/session/${this.profileId}`);
        const data = await response.json();

        if (data.success && data.session) {
          this.sessionId = data.session.id;
          this.onMatchFound(data.session);
        }
      } catch (error) {
        console.error('Error checking for match:', error);
      }
    }, 2000);
  }

  onMatchFound(session) {
    this.isSearching = false;
    clearInterval(this.checkInterval);

    const modal = document.getElementById('matchmaking-modal');
    if (modal) {
      modal.innerHTML = `
        <div style="background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%); border-radius: 30px; padding: 50px; max-width: 700px; width: 90%; box-shadow: 0 20px 80px rgba(0,0,0,0.5); border: 3px solid rgba(80, 200, 120, 0.5); text-align: center;">

          <div style="font-size: 100px; margin-bottom: 30px; animation: matchSuccess 1s;">
            ✅
          </div>

          <h2 style="color: #50c878; font-size: 42px; margin-bottom: 30px; text-shadow: 0 0 30px rgba(80, 200, 120, 0.5);">
            تم العثور على منافس!
          </h2>

          <div style="display: flex; justify-content: space-around; align-items: center; margin-bottom: 40px; gap: 30px;">

            <!-- اللاعب الأول -->
            <div style="flex: 1; text-align: center;">
              <div style="width: 100px; height: 100px; margin: 0 auto 15px; border-radius: 50%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); display: flex; align-items: center; justify-content: center; font-size: 48px; color: #1a1a2e; border: 4px solid rgba(212, 175, 55, 0.5); box-shadow: 0 10px 30px rgba(212, 175, 55, 0.4);">
                ${session.player1.avatar_url ? `<img src="${session.player1.avatar_url}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : session.player1.username.charAt(0).toUpperCase()}
              </div>
              <div style="color: white; font-size: 20px; font-weight: bold; margin-bottom: 5px;">${session.player1.username}</div>
              <div style="color: rgba(255,255,255,0.6); font-size: 14px;">المستوى ${session.player1.level || 1}</div>
            </div>

            <!-- VS -->
            <div style="color: #d4af37; font-size: 48px; font-weight: bold; text-shadow: 0 0 20px rgba(212, 175, 55, 0.6);">
              VS
            </div>

            <!-- اللاعب الثاني -->
            <div style="flex: 1; text-align: center;">
              <div style="width: 100px; height: 100px; margin: 0 auto 15px; border-radius: 50%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); display: flex; align-items: center; justify-content: center; font-size: 48px; color: #1a1a2e; border: 4px solid rgba(212, 175, 55, 0.5); box-shadow: 0 10px 30px rgba(212, 175, 55, 0.4);">
                ${session.player2.avatar_url ? `<img src="${session.player2.avatar_url}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : session.player2.username.charAt(0).toUpperCase()}
              </div>
              <div style="color: white; font-size: 20px; font-weight: bold; margin-bottom: 5px;">${session.player2.username}</div>
              <div style="color: rgba(255,255,255,0.6); font-size: 14px;">المستوى ${session.player2.level || 1}</div>
            </div>
          </div>

          <!-- معلومات المباراة -->
          <div style="background: rgba(0,0,0,0.3); border-radius: 20px; padding: 25px; margin-bottom: 30px;">
            <div style="display: flex; justify-content: space-around; gap: 30px;">
              <div>
                <div style="color: rgba(255,255,255,0.6); font-size: 14px; margin-bottom: 8px;">قيمة الرهان</div>
                <div style="color: #d4af37; font-size: 32px; font-weight: bold;">${session.bet_amount} 💰</div>
              </div>
              <div>
                <div style="color: rgba(255,255,255,0.6); font-size: 14px; margin-bottom: 8px;">إجمالي الجائزة</div>
                <div style="color: #50c878; font-size: 32px; font-weight: bold;">${session.total_pot} 🏆</div>
              </div>
            </div>
          </div>

          <button onclick="window.matchmaking.startGame('${session.id}')" style="background: linear-gradient(135deg, #50c878 0%, #3fa565 100%); color: white; border: none; padding: 20px 60px; border-radius: 15px; cursor: pointer; font-size: 22px; font-weight: bold; transition: all 0.3s; box-shadow: 0 10px 30px rgba(80, 200, 120, 0.4);">
            🎮 ابدأ اللعب
          </button>
        </div>

        <style>
          @keyframes matchSuccess {
            0% { transform: scale(0) rotate(0deg); opacity: 0; }
            50% { transform: scale(1.2) rotate(180deg); }
            100% { transform: scale(1) rotate(360deg); opacity: 1; }
          }
        </style>
      `;
    }
  }

  async cancelMatchmaking() {
    if (this.queueId) {
      try {
        await fetch(`/matchmaking/cancel/${this.queueId}`, {
          method: 'DELETE',
        });
      } catch (error) {
        console.error('Error cancelling queue:', error);
      }
    }

    this.isSearching = false;
    clearInterval(this.checkInterval);

    const modal = document.getElementById('matchmaking-modal');
    if (modal) {
      modal.remove();
    }
  }

  async startGame(sessionId) {
    try {
      await fetch(`/matchmaking/game-session/${sessionId}/start`, {
        method: 'POST',
      });

      const modal = document.getElementById('matchmaking-modal');
      if (modal) {
        modal.remove();
      }

      window.location.href = `/${this.gameType}.html?session=${sessionId}`;
    } catch (error) {
      console.error('Error starting game:', error);
      alert('حدث خطأ أثناء بدء اللعبة');
    }
  }
}

window.MatchmakingSystem = MatchmakingSystem;
