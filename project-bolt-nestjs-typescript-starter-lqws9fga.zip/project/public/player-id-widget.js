class PlayerIdWidget {
  constructor(playerId, position = 'top-left') {
    this.playerId = playerId;
    this.position = position;
    this.init();
  }

  init() {
    this.createWidget();
    this.attachEventListeners();
  }

  getPositionStyles() {
    const positions = {
      'top-left': 'top: 20px; left: 20px;',
      'top-right': 'top: 20px; right: 20px;',
      'bottom-left': 'bottom: 20px; left: 20px;',
      'bottom-right': 'bottom: 20px; right: 20px;',
    };
    return positions[this.position] || positions['top-left'];
  }

  createWidget() {
    const widgetHTML = `
      <div id="player-id-widget" style="position: fixed; ${this.getPositionStyles()} background: linear-gradient(135deg, rgba(212, 175, 55, 0.95) 0%, rgba(244, 208, 63, 0.95) 100%); padding: 12px 20px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.3); z-index: 1000; display: flex; align-items: center; gap: 12px; backdrop-filter: blur(10px); border: 2px solid rgba(255,255,255,0.3);">

        <div style="display: flex; flex-direction: column; gap: 4px;">
          <div style="font-size: 11px; color: rgba(26, 26, 46, 0.7); font-weight: bold;">معرف اللاعب</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <span id="player-id-display" style="font-size: 18px; font-weight: bold; color: #1a1a2e; font-family: 'Courier New', monospace; letter-spacing: 1px;">${this.playerId}</span>
            <button id="copy-player-id-btn" style="background: #1a1a2e; color: #d4af37; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 14px; transition: all 0.3s; display: flex; align-items: center; gap: 5px; font-weight: bold;" title="نسخ معرف اللاعب">
              <span id="copy-icon">📋</span>
              <span id="copy-text">نسخ</span>
            </button>
          </div>
        </div>

        <button id="search-player-btn" style="background: rgba(26, 26, 46, 0.8); color: white; border: none; padding: 8px 15px; border-radius: 8px; cursor: pointer; font-size: 20px; transition: all 0.3s;" title="البحث عن لاعب وإضافة صديق">
          🔍
        </button>
      </div>

      <!-- نافذة البحث عن لاعب -->
      <div id="search-player-modal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); z-index: 2000; display: none; align-items: center; justify-content: center; backdrop-filter: blur(5px);">
        <div style="background: linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%); border-radius: 20px; padding: 30px; max-width: 500px; width: 90%; box-shadow: 0 10px 50px rgba(0,0,0,0.5); border: 2px solid rgba(212, 175, 55, 0.5);">

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
            <h2 style="color: #d4af37; margin: 0; font-size: 24px;">البحث عن لاعب</h2>
            <button id="close-search-modal" style="background: none; border: none; color: white; font-size: 28px; cursor: pointer; padding: 0; line-height: 1;">×</button>
          </div>

          <div style="margin-bottom: 20px;">
            <label style="color: rgba(255,255,255,0.8); font-size: 14px; display: block; margin-bottom: 8px;">أدخل معرف اللاعب</label>
            <input type="text" id="search-player-input" placeholder="مثال: P12345678" style="width: 100%; padding: 15px; border-radius: 10px; border: 2px solid rgba(212, 175, 55, 0.5); background: rgba(255,255,255,0.1); color: white; font-size: 18px; font-family: 'Courier New', monospace; letter-spacing: 1px; text-align: center;">
          </div>

          <button id="search-submit-btn" style="width: 100%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); color: #1a1a2e; border: none; padding: 15px; border-radius: 10px; cursor: pointer; font-size: 18px; font-weight: bold; transition: all 0.3s; margin-bottom: 15px;">
            🔍 بحث
          </button>

          <!-- نتيجة البحث -->
          <div id="search-result" style="display: none;"></div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', widgetHTML);
  }

  attachEventListeners() {
    const copyBtn = document.getElementById('copy-player-id-btn');
    const searchBtn = document.getElementById('search-player-btn');
    const modal = document.getElementById('search-player-modal');
    const closeModal = document.getElementById('close-search-modal');
    const searchSubmitBtn = document.getElementById('search-submit-btn');
    const searchInput = document.getElementById('search-player-input');

    copyBtn.addEventListener('click', () => this.copyPlayerId());

    searchBtn.addEventListener('click', () => {
      modal.style.display = 'flex';
      searchInput.focus();
    });

    closeModal.addEventListener('click', () => {
      modal.style.display = 'none';
      this.clearSearch();
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
        this.clearSearch();
      }
    });

    searchSubmitBtn.addEventListener('click', () => this.searchPlayer());

    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.searchPlayer();
      }
    });
  }

  async copyPlayerId() {
    const copyIcon = document.getElementById('copy-icon');
    const copyText = document.getElementById('copy-text');
    const copyBtn = document.getElementById('copy-player-id-btn');

    try {
      await navigator.clipboard.writeText(this.playerId);

      copyIcon.textContent = '✅';
      copyText.textContent = 'تم النسخ';
      copyBtn.style.background = '#50c878';
      copyBtn.style.color = 'white';

      setTimeout(() => {
        copyIcon.textContent = '📋';
        copyText.textContent = 'نسخ';
        copyBtn.style.background = '#1a1a2e';
        copyBtn.style.color = '#d4af37';
      }, 2000);
    } catch (error) {
      console.error('Error copying:', error);
      alert('فشل النسخ. الرجاء المحاولة يدوياً.');
    }
  }

  async searchPlayer() {
    const input = document.getElementById('search-player-input');
    const searchPlayerId = input.value.trim().toUpperCase();
    const resultDiv = document.getElementById('search-result');
    const submitBtn = document.getElementById('search-submit-btn');

    if (!searchPlayerId) {
      alert('الرجاء إدخال معرف اللاعب');
      return;
    }

    if (searchPlayerId === this.playerId) {
      alert('لا يمكنك إضافة نفسك كصديق!');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '⏳ جاري البحث...';

    try {
      const response = await fetch(
        `/friends/search?playerId=${searchPlayerId}`,
      );
      const data = await response.json();

      if (data.success && data.player) {
        this.displaySearchResult(data.player);
      } else {
        resultDiv.innerHTML = `
          <div style="background: rgba(231, 76, 60, 0.2); border: 2px solid #e74c3c; padding: 20px; border-radius: 10px; text-align: center; color: white;">
            <div style="font-size: 48px; margin-bottom: 10px;">❌</div>
            <div style="font-size: 18px; font-weight: bold;">لم يتم العثور على اللاعب</div>
            <div style="font-size: 14px; opacity: 0.8; margin-top: 5px;">تأكد من المعرف وحاول مرة أخرى</div>
          </div>
        `;
        resultDiv.style.display = 'block';
      }
    } catch (error) {
      console.error('Search error:', error);
      alert('حدث خطأ أثناء البحث');
    }

    submitBtn.disabled = false;
    submitBtn.textContent = '🔍 بحث';
  }

  displaySearchResult(player) {
    const resultDiv = document.getElementById('search-result');

    resultDiv.innerHTML = `
      <div style="background: linear-gradient(135deg, rgba(212, 175, 55, 0.2) 0%, rgba(244, 208, 63, 0.2) 100%); border: 2px solid rgba(212, 175, 55, 0.5); padding: 20px; border-radius: 15px;">

        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
          <div style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #d4af37 0%, #f4d03f 100%); display: flex; align-items: center; justify-content: center; font-size: 28px; color: #1a1a2e; font-weight: bold;">
            ${player.avatar_url ? `<img src="${player.avatar_url}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : player.username.charAt(0).toUpperCase()}
          </div>

          <div style="flex: 1;">
            <div style="color: white; font-size: 20px; font-weight: bold; margin-bottom: 4px;">${player.username}</div>
            <div style="color: rgba(255,255,255,0.7); font-size: 14px;">المستوى ${player.level || 1}</div>
            <div style="color: #d4af37; font-size: 13px; font-family: 'Courier New', monospace;">${player.player_id}</div>
          </div>
        </div>

        <button onclick="window.playerIdWidget.sendFriendRequest('${player.profile_id}')" style="width: 100%; background: linear-gradient(135deg, #50c878 0%, #3fa565 100%); color: white; border: none; padding: 15px; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: bold; transition: all 0.3s;">
          ➕ إضافة كصديق
        </button>
      </div>
    `;

    resultDiv.style.display = 'block';
  }

  async sendFriendRequest(receiverProfileId) {
    const currentProfileId = localStorage.getItem('profileId');

    if (!currentProfileId) {
      alert('الرجاء تسجيل الدخول أولاً');
      return;
    }

    try {
      const response = await fetch('/friends/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderProfileId: currentProfileId,
          receiverProfileId: receiverProfileId,
        }),
      });

      const data = await response.json();

      if (data.success) {
        alert('✅ تم إرسال طلب الصداقة بنجاح!');
        document.getElementById('search-player-modal').style.display = 'none';
        this.clearSearch();
      } else {
        alert('❌ فشل إرسال طلب الصداقة');
      }
    } catch (error) {
      console.error('Friend request error:', error);
      alert('حدث خطأ أثناء إرسال الطلب');
    }
  }

  clearSearch() {
    document.getElementById('search-player-input').value = '';
    document.getElementById('search-result').style.display = 'none';
  }

  destroy() {
    const widget = document.getElementById('player-id-widget');
    const modal = document.getElementById('search-player-modal');
    if (widget) widget.remove();
    if (modal) modal.remove();
  }
}

window.PlayerIdWidget = PlayerIdWidget;
