const socket = io();

let gameState = null;
let playerId = null;
let selectedTile = null;

function createGame() {
    const playerName = document.getElementById('playerName').value.trim();
    if (!playerName) {
        alert('الرجاء إدخال اسمك');
        return;
    }

    socket.emit('domino:createGame', { playerName });
}

function joinGame() {
    const playerName = document.getElementById('playerName').value.trim();
    const gameCode = document.getElementById('gameCode').value.trim().toUpperCase();

    if (!playerName || !gameCode) {
        alert('الرجاء إدخال اسمك ورمز اللعبة');
        return;
    }

    socket.emit('domino:joinGame', { gameId: gameCode, playerName });
}

function drawTile() {
    if (!gameState || !playerId) return;

    socket.emit('domino:drawTile', {
        gameId: gameState.id,
        playerId: playerId,
    });
}

function selectTile(tile) {
    if (!isMyTurn()) {
        alert('ليس دورك!');
        return;
    }

    selectedTile = tile;

    if (gameState.board.tiles.length === 0) {
        playTileAtPosition('right');
    } else {
        document.getElementById('overlay').classList.add('active');
        document.getElementById('positionSelector').classList.add('active');
    }
}

function playTileAtPosition(position) {
    if (!selectedTile) return;

    socket.emit('domino:playTile', {
        gameId: gameState.id,
        playerId: playerId,
        tile: selectedTile,
        position: position,
    });

    cancelTilePlay();
}

function cancelTilePlay() {
    selectedTile = null;
    document.getElementById('overlay').classList.remove('active');
    document.getElementById('positionSelector').classList.remove('active');
}

function isMyTurn() {
    if (!gameState || !playerId) return false;
    const currentPlayer = gameState.players[gameState.currentTurnIndex];
    return currentPlayer && currentPlayer.id === playerId;
}

function renderGame() {
    if (!gameState) return;

    document.getElementById('displayGameId').textContent = gameState.id;
    document.getElementById('playerCount').textContent = gameState.players.length;
    document.getElementById('boneyardCount').textContent = gameState.boneyard.length;

    renderPlayers();
    renderBoard();
    renderPlayerHand();

    const drawButton = document.getElementById('drawButton');
    drawButton.disabled = !isMyTurn() || gameState.status !== 'active';
}

function renderPlayers() {
    const playersList = document.getElementById('playersList');
    playersList.innerHTML = '';

    gameState.players.forEach((player, index) => {
        const isCurrentTurn = index === gameState.currentTurnIndex;
        const playerDiv = document.createElement('div');
        playerDiv.className = 'player-info' + (isCurrentTurn ? ' current-turn' : '');
        playerDiv.innerHTML = `
            <strong>${player.name}</strong>
            ${player.id === playerId ? ' (أنت)' : ''}
            - الأحجار: ${player.hand.length}
            ${isCurrentTurn ? ' 🎯' : ''}
        `;
        playersList.appendChild(playerDiv);
    });
}

function renderBoard() {
    const board = document.getElementById('gameBoard');
    board.innerHTML = '';

    if (gameState.board.tiles.length === 0) {
        board.innerHTML = '<p style="color: white;">لا توجد أحجار على اللوحة بعد</p>';
        return;
    }

    gameState.board.tiles.forEach(tile => {
        board.appendChild(createDominoTile(tile, false));
    });
}

function renderPlayerHand() {
    const hand = document.getElementById('playerHand');
    hand.innerHTML = '';

    const player = gameState.players.find(p => p.id === playerId);
    if (!player) return;

    if (player.hand.length === 0) {
        hand.innerHTML = '<p>لا توجد أحجار</p>';
        return;
    }

    player.hand.forEach(tile => {
        const tileElement = createDominoTile(tile, true);
        hand.appendChild(tileElement);
    });
}

function createDominoTile(tile, clickable) {
    const tileDiv = document.createElement('div');
    tileDiv.className = 'domino-tile';

    if (clickable) {
        tileDiv.onclick = () => selectTile(tile);
    }

    const topHalf = document.createElement('div');
    topHalf.className = 'domino-half';
    topHalf.appendChild(createDots(tile.top));

    const bottomHalf = document.createElement('div');
    bottomHalf.className = 'domino-half';
    bottomHalf.appendChild(createDots(tile.bottom));

    tileDiv.appendChild(topHalf);
    tileDiv.appendChild(bottomHalf);

    return tileDiv;
}

function createDots(number) {
    const dotsContainer = document.createElement('div');
    dotsContainer.className = 'domino-dots';

    const patterns = {
        0: [],
        1: [[1, 1]],
        2: [[0, 0], [2, 2]],
        3: [[0, 0], [1, 1], [2, 2]],
        4: [[0, 0], [0, 2], [2, 0], [2, 2]],
        5: [[0, 0], [0, 2], [1, 1], [2, 0], [2, 2]],
        6: [[0, 0], [0, 1], [0, 2], [2, 0], [2, 1], [2, 2]],
    };

    dotsContainer.style.display = 'grid';
    dotsContainer.style.gridTemplateColumns = 'repeat(3, 1fr)';
    dotsContainer.style.gridTemplateRows = 'repeat(3, 1fr)';

    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            const cell = document.createElement('div');
            const shouldShowDot = patterns[number]?.some(([r, c]) => r === row && c === col);
            if (shouldShowDot) {
                const dot = document.createElement('div');
                dot.className = 'domino-dot';
                cell.appendChild(dot);
            }
            dotsContainer.appendChild(cell);
        }
    }

    return dotsContainer;
}

socket.on('domino:gameCreated', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
    alert('تم إنشاء اللعبة! شارك هذا الرمز: ' + gameState.id);
});

socket.on('domino:gameJoined', (data) => {
    gameState = data.game;
    playerId = data.playerId;
    document.getElementById('waitingScreen').style.display = 'none';
    document.getElementById('gameScreen').style.display = 'block';
    renderGame();
});

socket.on('domino:playerJoined', (data) => {
    gameState = data.game;
    renderGame();
    alert('انضم لاعب جديد: ' + data.newPlayer.name);
});

socket.on('domino:gameStarted', (data) => {
    gameState = data.game;
    renderGame();
    alert('بدأت اللعبة!');
});

socket.on('domino:tilePlayer', (data) => {
    gameState = data.game;
    renderGame();
});

socket.on('domino:tileDrawn', (data) => {
    if (data.tile) {
        console.log('تم سحب حجر:', data.tile);
    }
});

socket.on('domino:gameUpdated', (data) => {
    gameState = data.game;
    renderGame();
});

socket.on('domino:gameFinished', (data) => {
    gameState = data.game;
    renderGame();

    const winner = gameState.players.find(p => p.id === gameState.winner);
    if (winner) {
        alert('انتهت اللعبة! الفائز: ' + winner.name);
    }
});

socket.on('domino:error', (data) => {
    alert('خطأ: ' + data.message);
});
