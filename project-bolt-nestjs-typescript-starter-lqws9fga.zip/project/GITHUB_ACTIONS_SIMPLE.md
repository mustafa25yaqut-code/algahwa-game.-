# 🚀 شرح GitHub Actions بخطوات بسيطة جداً

## 🎯 ما هو GitHub Actions؟

**ببساطة:** عندما ترفع الكود على GitHub، يبني لك APK تلقائياً ومجاناً!

---

## 📋 الخطوات الكاملة:

### **الخطوة 1: إنشاء حساب GitHub** (إذا لم يكن لديك)

```
1. اذهب إلى: https://github.com
2. انقر "Sign up"
3. أدخل:
   - البريد الإلكتروني
   - كلمة المرور
   - اسم المستخدم
4. تحقق من البريد
5. ✅ حسابك جاهز!
```

---

### **الخطوة 2: إنشاء مستودع (Repository)**

```
1. بعد تسجيل الدخول، انقر "+" أعلى الصفحة
2. اختر "New repository"
3. أدخل:
   - Repository name: algahwa-game
   - Description: لعبة الگهوة - ألعاب شعبية
   - اختر: Public (عام)
   - ✅ لا تختر "Initialize with README"
4. انقر "Create repository"
5. ✅ مستودعك جاهز!
```

---

### **الخطوة 3: رفع الكود على GitHub**

#### أ. من الحاسوب (Terminal/CMD):

```bash
# 1. افتح Terminal/CMD في مجلد المشروع
cd /path/to/algahwa-game

# 2. إعداد Git (إذا لم تفعل من قبل)
git config --global user.name "اسمك"
git config --global user.email "بريدك@example.com"

# 3. تهيئة المشروع
git init
git add .
git commit -m "Initial commit - AlGahwa Game"

# 4. ربط مع GitHub (استبدل YOUR_USERNAME باسمك)
git remote add origin https://github.com/YOUR_USERNAME/algahwa-game.git

# 5. رفع الكود
git branch -M main
git push -u origin main
```

**سيطلب منك:**
- Username: اسم مستخدم GitHub
- Password: استخدم **Personal Access Token** (ليس كلمة المرور العادية)

#### ب. كيف تحصل على Personal Access Token:

```
1. اذهب إلى: https://github.com/settings/tokens
2. انقر "Generate new token" → "Generate new token (classic)"
3. أدخل:
   - Note: algahwa-game
   - Expiration: No expiration (أو اختر مدة)
   - اختر: ✅ repo (كل الصلاحيات)
4. انقر "Generate token"
5. ✅ انسخ التوكن واحفظه (لن تراه مرة أخرى!)
6. استخدم هذا التوكن بدلاً من كلمة المرور
```

---

### **الخطوة 4: تفعيل GitHub Actions**

```
✅ تلقائي! الملفات موجودة في المشروع:
   .github/workflows/android-build.yml
   .github/workflows/android-release.yml

لا تحتاج فعل أي شيء!
```

---

### **الخطوة 5: مشاهدة البناء**

```
1. اذهب إلى مستودعك على GitHub:
   https://github.com/YOUR_USERNAME/algahwa-game

2. انقر على تبويب "Actions" في الأعلى

3. ستشاهد:
   - Build Android APK (قيد التشغيل...)
   - أيقونة صفراء 🟡 = جاري البناء
   - أيقونة خضراء ✅ = نجح
   - أيقونة حمراء ❌ = فشل

4. انتظر 5-10 دقائق
```

---

### **الخطوة 6: تحميل APK**

```
1. بعد نجاح البناء (أيقونة خضراء ✅)

2. انقر على اسم الـ Workflow
   مثال: "Build Android APK"

3. انزل إلى أسفل الصفحة → قسم "Artifacts"

4. ستجد:
   📦 app-debug (أو app-release-signed)

5. انقر عليه لتحميل ZIP

6. فك الضغط → ستجد app-debug.apk

7. ✅ APK جاهز!
```

---

### **الخطوة 7: تثبيت APK على هاتفك**

#### من الحاسوب (USB):
```bash
# وصّل الهاتف بالكمبيوتر
# فعّل "تصحيح USB" في خيارات المطور
adb install app-debug.apk
```

#### مباشرة من الهاتف:
```
1. انسخ APK إلى هاتفك
2. افتح الملف من File Manager
3. سيطلب "السماح بمصادر غير معروفة"
4. فعّل الخيار
5. انقر "تثبيت"
6. ✅ التطبيق مثبت!
```

---

## 🔄 عند التحديث (Push جديد):

```bash
# بعد تعديل الكود:
git add .
git commit -m "وصف التعديلات"
git push origin main

# ✅ GitHub Actions ستبني APK جديد تلقائياً!
```

---

## 🎨 رسم توضيحي للعملية:

```
1. أنت تكتب الكود على الحاسوب
   ↓
2. ترفع الكود على GitHub (git push)
   ↓
3. GitHub Actions تكتشف التغيير تلقائياً
   ↓
4. تبدأ ببناء APK (5-10 دقائق)
   ↓
5. ✅ APK جاهز في Artifacts
   ↓
6. تحمّله من متصفحك (حاسوب أو موبايل)
   ↓
7. تثبته على الهاتف
   ↓
8. 🎉 تطبيقك يعمل!
```

---

## 📸 لقطات شاشة توضيحية:

### 1. صفحة Actions:
```
╔══════════════════════════════════════╗
║  < > Code   Issues   Pull requests   ║
║  [Actions]  Projects   Wiki          ║
╠══════════════════════════════════════╣
║  All workflows                       ║
║                                      ║
║  ✅ Build Android APK                ║
║     #1: Commit message               ║
║     main  10 minutes ago             ║
║                                      ║
║  🟡 Build Android APK                ║
║     #2: Another commit               ║
║     main  just now                   ║
╚══════════════════════════════════════╝
```

### 2. صفحة Workflow:
```
╔══════════════════════════════════════╗
║  Build Android APK  ✅ Success       ║
║  Triggered by: push                  ║
║  Duration: 8m 32s                    ║
╠══════════════════════════════════════╣
║  Jobs                                ║
║  ✅ build (8m 32s)                   ║
║     - Checkout code     ✅           ║
║     - Setup Node.js     ✅           ║
║     - Install deps      ✅           ║
║     - Build project     ✅           ║
║     - Build APK         ✅           ║
║     - Upload artifact   ✅           ║
╠══════════════════════════════════════╣
║  Artifacts (1)                       ║
║  📦 app-debug          2.4 MB        ║
╚══════════════════════════════════════╝
```

---

## ⚠️ ملاحظات مهمة:

### 1. المجانية:
```
✅ GitHub Actions مجاني 100%
✅ 2000 دقيقة بناء/شهر
✅ كل بناء يأخذ ~10 دقائق
✅ = 200 بناء/شهر مجاناً
✅ أكثر من كافي!
```

### 2. الأمان:
```
⚠️ لا ترفع ملفات حساسة:
   ❌ .env بكلمات مرور حقيقية
   ❌ مفاتيح API خاصة
   ❌ Keystore files

✅ استخدم GitHub Secrets للمعلومات الحساسة
```

### 3. حجم الملفات:
```
✅ APK حجمه ~9-10 MB
✅ التحميل سريع
✅ يمكن تحميله من الموبايل
```

---

## 🐛 حل المشاكل الشائعة:

### المشكلة 1: "fatal: not a git repository"
```bash
# الحل:
cd /path/to/your/project
git init
```

### المشكلة 2: "remote origin already exists"
```bash
# الحل:
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/algahwa-game.git
```

### المشكلة 3: "failed to push"
```bash
# الحل:
git pull origin main --rebase
git push origin main
```

### المشكلة 4: "Build failed في GitHub Actions"
```
1. اذهب إلى Actions
2. انقر على الـ Workflow الفاشل
3. اقرأ رسالة الخطأ
4. صحح المشكلة في الكود
5. git push مرة أخرى
```

### المشكلة 5: "لا أجد Artifacts"
```
✅ تأكد أن البناء نجح (أيقونة خضراء)
✅ انزل إلى أسفل صفحة Workflow
✅ Artifacts يظهر فقط بعد نجاح البناء
```

---

## 💡 نصائح إضافية:

### 1. استخدم GitHub Desktop (أسهل):
```
✅ برنامج مرئي بدلاً من الأوامر
✅ حمّله من: https://desktop.github.com/
✅ سحب وإفلات!
```

### 2. ابنِ APK موقّع للنشر:
```
1. أنشئ Keystore
2. أضفه في GitHub Secrets
3. أنشئ Release
4. APK موقّع جاهز تلقائياً!
```

### 3. شاهد الـ Logs:
```
✅ انقر على أي خطوة لرؤية التفاصيل
✅ مفيد لفهم العملية
✅ مفيد عند حدوث خطأ
```

---

## 🎯 الخلاصة السريعة:

### ملخص في 5 خطوات:

```
1️⃣ أنشئ حساب GitHub
2️⃣ ارفع الكود (git push)
3️⃣ انتظر 10 دقائق
4️⃣ حمّل APK من Artifacts
5️⃣ ثبّت على هاتفك

✅ انتهى!
```

---

## 📚 فيديوهات مفيدة:

إذا أردت شرح مرئي، ابحث على YouTube عن:
- "Git and GitHub tutorial Arabic"
- "GitHub Actions tutorial"
- "How to push code to GitHub"

---

## 🔗 روابط سريعة:

```
GitHub:              https://github.com
GitHub Desktop:      https://desktop.github.com
Personal Token:      https://github.com/settings/tokens
Your Repositories:   https://github.com/YOUR_USERNAME?tab=repositories
Actions Help:        https://docs.github.com/actions
```

---

## 🎉 مبروك!

**الآن تعرف كيف تستخدم GitHub Actions لبناء APK تلقائياً!**

كل ما عليك:
1. ارفع الكود مرة واحدة
2. GitHub تبني APK تلقائياً كل مرة
3. حمّل وثبّت

**سهل جداً! 🚀**
