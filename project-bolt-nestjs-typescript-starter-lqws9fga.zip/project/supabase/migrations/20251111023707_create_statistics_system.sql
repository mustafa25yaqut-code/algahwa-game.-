/*
  # نظام الإحصائيات وسجل المباريات

  1. جداول جديدة
    - `match_history` - سجل المباريات
      - `id` (uuid, primary key)
      - `game_session_id` (uuid)
      - `game_type` (text)
      - `player1_id` (uuid)
      - `player2_id` (uuid)
      - `winner_id` (uuid)
      - `loser_id` (uuid)
      - `bet_amount` (numeric)
      - `duration_seconds` (integer)
      - `game_data` (jsonb)
      - `played_at` (timestamp)

    - `player_statistics` - إحصائيات اللاعب
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `game_type` (text)
      - `total_games` (integer)
      - `total_wins` (integer)
      - `total_losses` (integer)
      - `total_draws` (integer)
      - `win_rate` (numeric)
      - `current_streak` (integer)
      - `best_streak` (integer)
      - `total_coins_won` (numeric)
      - `total_coins_lost` (numeric)
      - `average_game_duration` (integer)
      - `last_played_at` (timestamp)
      - `updated_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول

  3. دوال
    - تسجيل مباراة
    - تحديث الإحصائيات
    - حساب معدل الفوز
*/

CREATE TABLE IF NOT EXISTS match_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_session_id uuid REFERENCES game_sessions(id) ON DELETE SET NULL,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  player1_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  player2_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  winner_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  loser_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  bet_amount numeric DEFAULT 0,
  duration_seconds integer DEFAULT 0,
  game_data jsonb DEFAULT '{}'::jsonb,
  played_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_match_history_player1 ON match_history(player1_id);
CREATE INDEX IF NOT EXISTS idx_match_history_player2 ON match_history(player2_id);
CREATE INDEX IF NOT EXISTS idx_match_history_winner ON match_history(winner_id);
CREATE INDEX IF NOT EXISTS idx_match_history_game_type ON match_history(game_type);
CREATE INDEX IF NOT EXISTS idx_match_history_played_at ON match_history(played_at DESC);

ALTER TABLE match_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their matches" ON match_history
  FOR SELECT
  TO authenticated
  USING (auth.uid() = player1_id OR auth.uid() = player2_id);

CREATE POLICY "System can create matches" ON match_history
  FOR INSERT
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS player_statistics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon', 'overall')),
  total_games integer DEFAULT 0,
  total_wins integer DEFAULT 0,
  total_losses integer DEFAULT 0,
  total_draws integer DEFAULT 0,
  win_rate numeric(5,2) DEFAULT 0,
  current_streak integer DEFAULT 0,
  best_streak integer DEFAULT 0,
  total_coins_won numeric DEFAULT 0,
  total_coins_lost numeric DEFAULT 0,
  average_game_duration integer DEFAULT 0,
  last_played_at timestamptz,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(profile_id, game_type)
);

CREATE INDEX IF NOT EXISTS idx_player_stats_profile ON player_statistics(profile_id);
CREATE INDEX IF NOT EXISTS idx_player_stats_game_type ON player_statistics(game_type);
CREATE INDEX IF NOT EXISTS idx_player_stats_win_rate ON player_statistics(win_rate DESC);
CREATE INDEX IF NOT EXISTS idx_player_stats_total_wins ON player_statistics(total_wins DESC);

ALTER TABLE player_statistics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all statistics" ON player_statistics
  FOR SELECT
  USING (true);

CREATE POLICY "System can manage statistics" ON player_statistics
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE OR REPLACE FUNCTION record_match(
  p_game_session_id uuid,
  p_game_type text,
  p_player1_id uuid,
  p_player2_id uuid,
  p_winner_id uuid,
  p_bet_amount numeric,
  p_duration_seconds integer,
  p_game_data jsonb DEFAULT '{}'::jsonb
)
RETURNS uuid AS $$
DECLARE
  v_match_id uuid;
  v_loser_id uuid;
BEGIN
  IF p_winner_id = p_player1_id THEN
    v_loser_id := p_player2_id;
  ELSE
    v_loser_id := p_player1_id;
  END IF;
  
  INSERT INTO match_history (
    game_session_id, game_type, player1_id, player2_id,
    winner_id, loser_id, bet_amount, duration_seconds, game_data
  ) VALUES (
    p_game_session_id, p_game_type, p_player1_id, p_player2_id,
    p_winner_id, v_loser_id, p_bet_amount, p_duration_seconds, p_game_data
  )
  RETURNING id INTO v_match_id;
  
  PERFORM update_player_statistics(p_player1_id, p_game_type, p_player1_id = p_winner_id, p_bet_amount, p_duration_seconds);
  PERFORM update_player_statistics(p_player2_id, p_game_type, p_player2_id = p_winner_id, p_bet_amount, p_duration_seconds);
  
  PERFORM update_player_statistics(p_player1_id, 'overall', p_player1_id = p_winner_id, p_bet_amount, p_duration_seconds);
  PERFORM update_player_statistics(p_player2_id, 'overall', p_player2_id = p_winner_id, p_bet_amount, p_duration_seconds);
  
  RETURN v_match_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_player_statistics(
  p_profile_id uuid,
  p_game_type text,
  p_is_winner boolean,
  p_bet_amount numeric,
  p_duration_seconds integer
)
RETURNS void AS $$
DECLARE
  v_stats record;
  v_new_total_games integer;
  v_new_total_wins integer;
  v_new_total_losses integer;
  v_new_win_rate numeric;
  v_new_streak integer;
  v_new_best_streak integer;
  v_new_avg_duration integer;
BEGIN
  SELECT * INTO v_stats
  FROM player_statistics
  WHERE profile_id = p_profile_id AND game_type = p_game_type;
  
  IF v_stats.id IS NULL THEN
    INSERT INTO player_statistics (profile_id, game_type)
    VALUES (p_profile_id, p_game_type);
    
    SELECT * INTO v_stats
    FROM player_statistics
    WHERE profile_id = p_profile_id AND game_type = p_game_type;
  END IF;
  
  v_new_total_games := v_stats.total_games + 1;
  
  IF p_is_winner THEN
    v_new_total_wins := v_stats.total_wins + 1;
    v_new_total_losses := v_stats.total_losses;
    v_new_streak := v_stats.current_streak + 1;
  ELSE
    v_new_total_wins := v_stats.total_wins;
    v_new_total_losses := v_stats.total_losses + 1;
    v_new_streak := 0;
  END IF;
  
  v_new_best_streak := GREATEST(v_stats.best_streak, v_new_streak);
  
  IF v_new_total_games > 0 THEN
    v_new_win_rate := (v_new_total_wins::numeric / v_new_total_games::numeric) * 100;
  ELSE
    v_new_win_rate := 0;
  END IF;
  
  v_new_avg_duration := ((v_stats.average_game_duration * v_stats.total_games) + p_duration_seconds) / v_new_total_games;
  
  UPDATE player_statistics
  SET
    total_games = v_new_total_games,
    total_wins = v_new_total_wins,
    total_losses = v_new_total_losses,
    win_rate = v_new_win_rate,
    current_streak = v_new_streak,
    best_streak = v_new_best_streak,
    total_coins_won = CASE WHEN p_is_winner THEN total_coins_won + p_bet_amount ELSE total_coins_won END,
    total_coins_lost = CASE WHEN NOT p_is_winner THEN total_coins_lost + p_bet_amount ELSE total_coins_lost END,
    average_game_duration = v_new_avg_duration,
    last_played_at = now(),
    updated_at = now()
  WHERE profile_id = p_profile_id AND game_type = p_game_type;
  
  IF p_is_winner THEN
    PERFORM update_daily_challenge(p_profile_id, 'win_games', 1);
    
    PERFORM update_achievement_progress(p_profile_id, 'first_win', 1);
    PERFORM update_achievement_progress(p_profile_id, 'win_10', v_new_total_wins);
    PERFORM update_achievement_progress(p_profile_id, 'win_50', v_new_total_wins);
    PERFORM update_achievement_progress(p_profile_id, 'win_100', v_new_total_wins);
    PERFORM update_achievement_progress(p_profile_id, 'win_500', v_new_total_wins);
    
    IF v_new_streak >= 7 THEN
      PERFORM update_achievement_progress(p_profile_id, 'streak_7', v_new_streak);
    END IF;
  END IF;
  
  PERFORM update_daily_challenge(p_profile_id, 'play_games', 1);
  PERFORM update_achievement_progress(p_profile_id, 'play_10', v_new_total_games);
  PERFORM update_achievement_progress(p_profile_id, 'play_100', v_new_total_games);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_player_stats_summary(p_profile_id uuid)
RETURNS TABLE (
  game_type text,
  total_games bigint,
  total_wins bigint,
  total_losses bigint,
  win_rate numeric,
  current_streak bigint,
  best_streak bigint
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ps.game_type,
    ps.total_games::bigint,
    ps.total_wins::bigint,
    ps.total_losses::bigint,
    ps.win_rate,
    ps.current_streak::bigint,
    ps.best_streak::bigint
  FROM player_statistics ps
  WHERE ps.profile_id = p_profile_id
  ORDER BY 
    CASE ps.game_type
      WHEN 'overall' THEN 1
      ELSE 2
    END,
    ps.game_type;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_recent_matches(p_profile_id uuid, p_limit integer DEFAULT 10)
RETURNS TABLE (
  match_id uuid,
  game_type text,
  opponent_id uuid,
  opponent_username text,
  is_winner boolean,
  bet_amount numeric,
  played_at timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mh.id,
    mh.game_type,
    CASE 
      WHEN mh.player1_id = p_profile_id THEN mh.player2_id
      ELSE mh.player1_id
    END,
    CASE 
      WHEN mh.player1_id = p_profile_id THEN up2.username
      ELSE up1.username
    END,
    mh.winner_id = p_profile_id,
    mh.bet_amount,
    mh.played_at
  FROM match_history mh
  LEFT JOIN user_profiles up1 ON mh.player1_id = up1.id
  LEFT JOIN user_profiles up2 ON mh.player2_id = up2.id
  WHERE mh.player1_id = p_profile_id OR mh.player2_id = p_profile_id
  ORDER BY mh.played_at DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
