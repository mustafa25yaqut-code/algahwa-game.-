/*
  # إضافة معرف اللاعب وتحديث نظام الأصدقاء

  1. إضافة player_id لجدول user_profiles
    - معرف فريد لكل لاعب
    - دالة لتوليد المعرف تلقائياً

  2. تحديث جدول friendships الموجود
    - استخدام requester_id و addressee_id الموجودين

  3. إضافة جدول friend_requests إذا لم يكن موجوداً
*/

-- دالة لتوليد player_id فريد
CREATE OR REPLACE FUNCTION generate_player_id()
RETURNS text AS $$
DECLARE
  new_id text;
  id_exists boolean;
BEGIN
  LOOP
    new_id := 'P' || LPAD(FLOOR(RANDOM() * 100000000)::text, 8, '0');
    
    SELECT EXISTS(SELECT 1 FROM user_profiles WHERE player_id = new_id) INTO id_exists;
    
    EXIT WHEN NOT id_exists;
  END LOOP;
  
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;

-- إضافة player_id لجدول user_profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'player_id'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN player_id text;
    
    UPDATE user_profiles SET player_id = generate_player_id() WHERE player_id IS NULL;
    
    ALTER TABLE user_profiles ADD CONSTRAINT user_profiles_player_id_unique UNIQUE (player_id);
    ALTER TABLE user_profiles ALTER COLUMN player_id SET NOT NULL;
    ALTER TABLE user_profiles ALTER COLUMN player_id SET DEFAULT generate_player_id();
    
    CREATE INDEX idx_user_profiles_player_id ON user_profiles(player_id);
  END IF;
END $$;

-- جدول طلبات الصداقة (إذا لم يكن موجوداً)
CREATE TABLE IF NOT EXISTS friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  receiver_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(sender_profile_id, receiver_profile_id),
  CHECK (sender_profile_id != receiver_profile_id)
);

CREATE INDEX IF NOT EXISTS idx_friend_requests_sender ON friend_requests(sender_profile_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver ON friend_requests(receiver_profile_id);
CREATE INDEX IF NOT EXISTS idx_friend_requests_status ON friend_requests(status);

ALTER TABLE friend_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view friend requests" ON friend_requests FOR SELECT USING (true);
CREATE POLICY "Users can send friend requests" ON friend_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update friend requests" ON friend_requests FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Users can delete friend requests" ON friend_requests FOR DELETE USING (true);

-- دالة لقبول طلب الصداقة
CREATE OR REPLACE FUNCTION accept_friend_request(request_id uuid)
RETURNS void AS $$
DECLARE
  sender_prof_id uuid;
  receiver_prof_id uuid;
BEGIN
  SELECT sender_profile_id, receiver_profile_id INTO sender_prof_id, receiver_prof_id
  FROM friend_requests
  WHERE id = request_id AND status = 'pending';
  
  IF sender_prof_id IS NULL THEN
    RAISE EXCEPTION 'Friend request not found or already processed';
  END IF;
  
  UPDATE friend_requests SET status = 'accepted' WHERE id = request_id;
  
  INSERT INTO friendships (requester_id, addressee_id, status)
  VALUES (sender_prof_id, receiver_prof_id, 'accepted')
  ON CONFLICT (requester_id, addressee_id) DO NOTHING;
  
  INSERT INTO friendships (requester_id, addressee_id, status)
  VALUES (receiver_prof_id, sender_prof_id, 'accepted')
  ON CONFLICT (requester_id, addressee_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة للبحث عن لاعب بواسطة player_id
CREATE OR REPLACE FUNCTION search_player_by_id(search_player_id text)
RETURNS TABLE (
  profile_id uuid,
  player_id text,
  username text,
  avatar_url text,
  level integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    up.id,
    up.player_id,
    up.username,
    up.avatar_url,
    up.level
  FROM user_profiles up
  WHERE up.player_id = search_player_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
