/*
  # إضافة نظام الملصقات والهدايا

  1. جداول جديدة
    - `game_stickers` - الملصقات والإيموجيز المرسلة
      - `id` (uuid, primary key)
      - `game_id` (uuid, foreign key)
      - `sender_id` (uuid)
      - `sender_name` (text)
      - `sticker_type` (text) - نوع الملصق
      - `target_id` (uuid) - المستقبل (optional)
      - `target_name` (text)
      - `created_at` (timestamp)
    
    - `game_gifts` - الهدايا المرسلة (ورد، قلب، شاكوش)
      - `id` (uuid, primary key)
      - `game_id` (uuid, foreign key)
      - `sender_id` (uuid)
      - `sender_name` (text)
      - `receiver_id` (uuid)
      - `receiver_name` (text)
      - `gift_type` (text) - 'flower', 'heart', 'hammer'
      - `created_at` (timestamp)

  2. الأمان
    - تفعيل RLS على الجداول الجديدة
    - سياسات للقراءة والكتابة
*/

-- جدول الملصقات والإيموجيز
CREATE TABLE IF NOT EXISTS game_stickers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL,
  sender_id uuid NOT NULL,
  sender_name text NOT NULL,
  sticker_type text NOT NULL CHECK (sticker_type IN (
    'laugh', 'sad', 'thinking', 'sleep', 'joy', 'surprise',
    'sorry', 'well_done', 'good_luck', 'game_over', 'hahaha'
  )),
  target_id uuid,
  target_name text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_game_stickers_game_id ON game_stickers(game_id);
CREATE INDEX IF NOT EXISTS idx_game_stickers_created_at ON game_stickers(created_at DESC);

ALTER TABLE game_stickers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players can view stickers in game"
  ON game_stickers FOR SELECT
  USING (true);

CREATE POLICY "Players can send stickers"
  ON game_stickers FOR INSERT
  WITH CHECK (true);

-- جدول الهدايا
CREATE TABLE IF NOT EXISTS game_gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL,
  sender_id uuid NOT NULL,
  sender_name text NOT NULL,
  receiver_id uuid NOT NULL,
  receiver_name text NOT NULL,
  gift_type text NOT NULL CHECK (gift_type IN ('flower', 'heart', 'hammer')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_game_gifts_game_id ON game_gifts(game_id);
CREATE INDEX IF NOT EXISTS idx_game_gifts_receiver ON game_gifts(receiver_id);

ALTER TABLE game_gifts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players can view gifts in game"
  ON game_gifts FOR SELECT
  USING (true);

CREATE POLICY "Players can send gifts"
  ON game_gifts FOR INSERT
  WITH CHECK (true);
