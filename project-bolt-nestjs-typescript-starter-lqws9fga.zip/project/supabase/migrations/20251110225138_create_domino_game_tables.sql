/*
  # Create Domino Game Tables

  1. New Tables
    - `domino_games`
      - `id` (uuid, primary key) - Unique game identifier
      - `status` (text) - Game status: waiting, active, finished
      - `current_turn_index` (integer) - Index of player whose turn it is
      - `board_data` (jsonb) - Board state with tiles and ends
      - `boneyard_data` (jsonb) - Remaining tiles to draw
      - `winner_id` (uuid, nullable) - Winner player ID
      - `created_at` (timestamptz) - Game creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

    - `domino_players`
      - `id` (uuid, primary key) - Unique player identifier
      - `game_id` (uuid, foreign key) - Reference to domino_games
      - `name` (text) - Player name
      - `hand_data` (jsonb) - Player's tiles
      - `is_connected` (boolean) - Connection status
      - `created_at` (timestamptz) - Player join timestamp

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read game data
    - Add policies for players to update their own data

  3. Indexes
    - Index on game_id for faster player lookups
    - Index on status for game filtering
*/

CREATE TABLE IF NOT EXISTS domino_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'waiting',
  current_turn_index integer NOT NULL DEFAULT 0,
  board_data jsonb NOT NULL DEFAULT '{"tiles": [], "leftEnd": -1, "rightEnd": -1}'::jsonb,
  boneyard_data jsonb NOT NULL DEFAULT '[]'::jsonb,
  winner_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS domino_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES domino_games(id) ON DELETE CASCADE,
  name text NOT NULL,
  hand_data jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_connected boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_domino_players_game_id ON domino_players(game_id);
CREATE INDEX IF NOT EXISTS idx_domino_games_status ON domino_games(status);

ALTER TABLE domino_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE domino_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read game data"
  ON domino_games FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can create games"
  ON domino_games FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update games"
  ON domino_games FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read player data"
  ON domino_players FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can join games"
  ON domino_players FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Players can update own data"
  ON domino_players FOR UPDATE
  TO authenticated
  USING (true);
