/*
  # نظام الإبلاغ والحظر + الدعم الفني

  1. جداول جديدة
    - `user_reports` - الإبلاغات
      - `id` (uuid, primary key)
      - `reporter_id` (uuid) - المبلغ
      - `reported_user_id` (uuid) - المبلغ عنه
      - `reason` (text) - السبب
      - `description` (text) - الوصف
      - `evidence` (jsonb) - الأدلة
      - `status` (text) - الحالة
      - `reviewed_by` (uuid) - المراجع
      - `reviewed_at` (timestamp)
      - `action_taken` (text)
      - `created_at` (timestamp)

    - `blocked_users` - المستخدمون المحظورون
      - `id` (uuid, primary key)
      - `blocker_id` (uuid) - الحاظر
      - `blocked_user_id` (uuid) - المحظور
      - `reason` (text)
      - `created_at` (timestamp)

    - `user_bans` - الحظر من النظام
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `reason` (text)
      - `banned_by` (uuid)
      - `banned_until` (timestamp)
      - `permanent` (boolean)
      - `created_at` (timestamp)

    - `support_tickets` - تذاكر الدعم
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `subject` (text)
      - `message` (text)
      - `category` (text)
      - `priority` (text)
      - `status` (text)
      - `assigned_to` (uuid)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `closed_at` (timestamp)

    - `support_messages` - رسائل الدعم
      - `id` (uuid, primary key)
      - `ticket_id` (uuid)
      - `sender_id` (uuid)
      - `message` (text)
      - `attachments` (jsonb)
      - `created_at` (timestamp)

    - `faq` - الأسئلة الشائعة
      - `id` (uuid, primary key)
      - `question` (text)
      - `answer` (text)
      - `category` (text)
      - `order` (integer)
      - `active` (boolean)

  2. الأمان
    - RLS على جميع الجداول

  3. دوال
    - إبلاغ عن مستخدم
    - حظر مستخدم
    - إنشاء تذكرة دعم
*/

CREATE TABLE IF NOT EXISTS user_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reported_user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reason text NOT NULL CHECK (reason IN (
    'cheating', 'harassment', 'inappropriate_language', 'spam', 'other'
  )),
  description text NOT NULL,
  evidence jsonb DEFAULT '{}'::jsonb,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'resolved', 'dismissed')),
  reviewed_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  action_taken text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reports_reporter ON user_reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_reported ON user_reports(reported_user_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON user_reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_created ON user_reports(created_at DESC);

ALTER TABLE user_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reports" ON user_reports
  FOR SELECT
  TO authenticated
  USING (auth.uid() = reporter_id);

CREATE POLICY "Users can create reports" ON user_reports
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

CREATE TABLE IF NOT EXISTS blocked_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  blocked_user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reason text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(blocker_id, blocked_user_id)
);

CREATE INDEX IF NOT EXISTS idx_blocked_users_blocker ON blocked_users(blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocked_users_blocked ON blocked_users(blocked_user_id);

ALTER TABLE blocked_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own blocks" ON blocked_users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = blocker_id);

CREATE POLICY "Users can block others" ON blocked_users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = blocker_id);

CREATE POLICY "Users can unblock others" ON blocked_users
  FOR DELETE
  TO authenticated
  USING (auth.uid() = blocker_id);

CREATE TABLE IF NOT EXISTS user_bans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reason text NOT NULL,
  banned_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  banned_until timestamptz,
  permanent boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bans_profile ON user_bans(profile_id);
CREATE INDEX IF NOT EXISTS idx_bans_until ON user_bans(banned_until);

ALTER TABLE user_bans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bans" ON user_bans
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  subject text NOT NULL,
  message text NOT NULL,
  category text CHECK (category IN (
    'technical', 'payment', 'account', 'gameplay', 'report', 'other'
  )),
  priority text DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  status text DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'waiting', 'resolved', 'closed')),
  assigned_to uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  closed_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_tickets_profile ON support_tickets(profile_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_priority ON support_tickets(priority);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON support_tickets(created_at DESC);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tickets" ON support_tickets
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "Users can create tickets" ON support_tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = profile_id);

CREATE TABLE IF NOT EXISTS support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  message text NOT NULL,
  attachments jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_support_messages_ticket ON support_messages(ticket_id);
CREATE INDEX IF NOT EXISTS idx_support_messages_created ON support_messages(created_at);

ALTER TABLE support_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view ticket messages" ON support_messages
  FOR SELECT
  TO authenticated
  USING (
    ticket_id IN (
      SELECT id FROM support_tickets WHERE profile_id = auth.uid()
    )
  );

CREATE POLICY "Users can send messages" ON support_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    ticket_id IN (
      SELECT id FROM support_tickets WHERE profile_id = auth.uid()
    )
    AND sender_id = auth.uid()
  );

CREATE TABLE IF NOT EXISTS faq (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  answer text NOT NULL,
  category text CHECK (category IN (
    'general', 'gameplay', 'account', 'payment', 'technical'
  )),
  display_order integer DEFAULT 0,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_faq_category ON faq(category);
CREATE INDEX IF NOT EXISTS idx_faq_order ON faq(display_order);

INSERT INTO faq (question, answer, category, display_order) VALUES
  ('كيف أبدأ اللعب؟', 'قم بالتسجيل أولاً، ثم اختر لعبتك المفضلة واختر قيمة الرهان للبحث عن منافس.', 'general', 1),
  ('كيف أحصل على العملات؟', 'يمكنك شحن العملات من صفحة الشحن، أو الفوز في المباريات، أو إكمال التحديات اليومية.', 'payment', 2),
  ('كيف أضيف أصدقاء؟', 'اذهب إلى صفحة الملف الشخصي واستخدم معرف اللاعب للبحث عن أصدقائك وإضافتهم.', 'general', 3),
  ('ماذا أفعل إذا نسيت كلمة المرور؟', 'استخدم خيار "نسيت كلمة المرور" في صفحة تسجيل الدخول.', 'account', 4),
  ('كيف أسحب أرباحي؟', 'اذهب إلى صفحة السحب واتبع التعليمات لسحب أرباحك.', 'payment', 5)
ON CONFLICT DO NOTHING;

ALTER TABLE faq ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active FAQ" ON faq
  FOR SELECT
  USING (active = true);

CREATE OR REPLACE FUNCTION report_user(
  p_reporter_id uuid,
  p_reported_user_id uuid,
  p_reason text,
  p_description text,
  p_evidence jsonb DEFAULT '{}'::jsonb
)
RETURNS uuid AS $$
DECLARE
  v_report_id uuid;
BEGIN
  IF p_reporter_id = p_reported_user_id THEN
    RAISE EXCEPTION 'Cannot report yourself';
  END IF;
  
  INSERT INTO user_reports (
    reporter_id, reported_user_id, reason, description, evidence
  ) VALUES (
    p_reporter_id, p_reported_user_id, p_reason, p_description, p_evidence
  )
  RETURNING id INTO v_report_id;
  
  RETURN v_report_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION block_user(
  p_blocker_id uuid,
  p_blocked_user_id uuid,
  p_reason text DEFAULT NULL
)
RETURNS boolean AS $$
BEGIN
  IF p_blocker_id = p_blocked_user_id THEN
    RAISE EXCEPTION 'Cannot block yourself';
  END IF;
  
  INSERT INTO blocked_users (blocker_id, blocked_user_id, reason)
  VALUES (p_blocker_id, p_blocked_user_id, p_reason)
  ON CONFLICT (blocker_id, blocked_user_id) DO NOTHING;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION unblock_user(
  p_blocker_id uuid,
  p_blocked_user_id uuid
)
RETURNS boolean AS $$
BEGIN
  DELETE FROM blocked_users
  WHERE blocker_id = p_blocker_id AND blocked_user_id = p_blocked_user_id;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION is_user_blocked(
  p_user_id uuid,
  p_other_user_id uuid
)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM blocked_users
    WHERE (blocker_id = p_user_id AND blocked_user_id = p_other_user_id)
       OR (blocker_id = p_other_user_id AND blocked_user_id = p_user_id)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION create_support_ticket(
  p_profile_id uuid,
  p_subject text,
  p_message text,
  p_category text
)
RETURNS uuid AS $$
DECLARE
  v_ticket_id uuid;
BEGIN
  INSERT INTO support_tickets (profile_id, subject, message, category)
  VALUES (p_profile_id, p_subject, p_message, p_category)
  RETURNING id INTO v_ticket_id;
  
  INSERT INTO support_messages (ticket_id, sender_id, message)
  VALUES (v_ticket_id, p_profile_id, p_message);
  
  PERFORM create_notification(
    p_profile_id,
    'system',
    'تم إنشاء تذكرة دعم',
    'تم إنشاء تذكرتك بنجاح. سنرد عليك قريباً.',
    jsonb_build_object('ticket_id', v_ticket_id)
  );
  
  RETURN v_ticket_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
