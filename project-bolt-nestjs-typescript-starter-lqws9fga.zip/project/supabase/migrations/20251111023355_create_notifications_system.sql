/*
  # نظام الإشعارات

  1. جداول جديدة
    - `notifications` - الإشعارات
      - `id` (uuid, primary key)
      - `profile_id` (uuid) - المستلم
      - `type` (text) - نوع الإشعار
      - `title` (text) - العنوان
      - `message` (text) - الرسالة
      - `data` (jsonb) - بيانات إضافية
      - `read` (boolean) - مقروء
      - `action_url` (text) - رابط الإجراء
      - `created_at` (timestamp)
      - `read_at` (timestamp)

    - `push_tokens` - رموز الإشعارات
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `token` (text) - FCM token
      - `device_type` (text) - نوع الجهاز
      - `created_at` (timestamp)
      - `last_used_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول
    - المستخدمون يرون إشعاراتهم فقط

  3. دوال
    - إنشاء إشعار
    - تحديث حالة القراءة
    - حذف الإشعارات القديمة
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN (
    'friend_request', 'friend_accepted', 'game_invite', 'game_started',
    'game_ended', 'message', 'gift', 'achievement', 'level_up',
    'tournament_start', 'tournament_end', 'group_invite', 'system'
  )),
  title text NOT NULL,
  message text NOT NULL,
  data jsonb DEFAULT '{}'::jsonb,
  read boolean DEFAULT false,
  action_url text,
  created_at timestamptz DEFAULT now(),
  read_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_notifications_profile ON notifications(profile_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications" ON notifications
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "Users can update own notifications" ON notifications
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = profile_id)
  WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "Users can delete own notifications" ON notifications
  FOR DELETE
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "System can create notifications" ON notifications
  FOR INSERT
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS push_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  device_type text CHECK (device_type IN ('android', 'ios', 'web')),
  created_at timestamptz DEFAULT now(),
  last_used_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_push_tokens_profile ON push_tokens(profile_id);
CREATE INDEX IF NOT EXISTS idx_push_tokens_token ON push_tokens(token);

ALTER TABLE push_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tokens" ON push_tokens
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "Users can insert own tokens" ON push_tokens
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "Users can update own tokens" ON push_tokens
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = profile_id)
  WITH CHECK (auth.uid() = profile_id);

CREATE POLICY "Users can delete own tokens" ON push_tokens
  FOR DELETE
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE OR REPLACE FUNCTION create_notification(
  p_profile_id uuid,
  p_type text,
  p_title text,
  p_message text,
  p_data jsonb DEFAULT '{}'::jsonb,
  p_action_url text DEFAULT NULL
)
RETURNS uuid AS $$
DECLARE
  v_notification_id uuid;
BEGIN
  INSERT INTO notifications (
    profile_id, type, title, message, data, action_url
  ) VALUES (
    p_profile_id, p_type, p_title, p_message, p_data, p_action_url
  )
  RETURNING id INTO v_notification_id;
  
  RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION mark_notification_as_read(p_notification_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE notifications
  SET read = true, read_at = now()
  WHERE id = p_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION mark_all_notifications_as_read(p_profile_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE notifications
  SET read = true, read_at = now()
  WHERE profile_id = p_profile_id AND read = false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_unread_count(p_profile_id uuid)
RETURNS bigint AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)
    FROM notifications
    WHERE profile_id = p_profile_id AND read = false
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION cleanup_old_notifications()
RETURNS void AS $$
BEGIN
  DELETE FROM notifications
  WHERE created_at < now() - interval '30 days'
    AND read = true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
