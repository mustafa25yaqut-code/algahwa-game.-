/*
  # Add Withdrawal System

  1. New Tables
    - `withdrawal_methods`
      - `id` (uuid, primary key)
      - `country_code` (text) - Country code (SA, EG, AE, etc.)
      - `country_name` (text) - Country name in Arabic
      - `method_type` (text) - Method: bank_transfer, mobile_wallet, paypal, etc.
      - `method_name` (text) - Method name (e.g., "بنك الراجحي", "فودافون كاش")
      - `min_amount` (integer) - Minimum withdrawal in coins
      - `processing_time` (text) - Processing time description
      - `active` (boolean) - Is method active
      - `created_at` (timestamptz)

    - `withdrawal_requests`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `amount_coins` (integer) - Amount in coins
      - `amount_usd` (decimal) - Amount in USD
      - `withdrawal_method_id` (uuid) - References withdrawal_methods
      - `account_details` (jsonb) - Account details (encrypted in production)
      - `status` (text) - Status: pending, processing, completed, rejected
      - `rejection_reason` (text, nullable) - Reason if rejected
      - `processed_by` (text, nullable) - Admin who processed
      - `created_at` (timestamptz)
      - `processed_at` (timestamptz, nullable)

  2. Security
    - Enable RLS on all tables
    - Users can only read their own withdrawal requests
    - Users can create withdrawal requests
    - Only admins can update withdrawal status

  3. Initial Data
    - Add withdrawal methods for major Arab countries

  4. Constraints
    - Minimum withdrawal: 1000 coins
    - Must have sufficient balance
*/

CREATE TABLE IF NOT EXISTS withdrawal_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code text NOT NULL,
  country_name text NOT NULL,
  method_type text NOT NULL CHECK (method_type IN ('bank_transfer', 'mobile_wallet', 'paypal', 'wise', 'western_union', 'moneygram')),
  method_name text NOT NULL,
  min_amount integer NOT NULL DEFAULT 1000,
  processing_time text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  amount_coins integer NOT NULL CHECK (amount_coins >= 1000),
  amount_usd decimal(10,2) NOT NULL,
  withdrawal_method_id uuid NOT NULL REFERENCES withdrawal_methods(id),
  account_details jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'rejected', 'cancelled')),
  rejection_reason text,
  processed_by text,
  created_at timestamptz DEFAULT now(),
  processed_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_withdrawal_methods_country ON withdrawal_methods(country_code);
CREATE INDEX IF NOT EXISTS idx_withdrawal_methods_active ON withdrawal_methods(active);
CREATE INDEX IF NOT EXISTS idx_withdrawal_requests_user_id ON withdrawal_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawal_requests_status ON withdrawal_requests(status);

ALTER TABLE withdrawal_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawal_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active withdrawal methods"
  ON withdrawal_methods FOR SELECT
  TO authenticated
  USING (active = true);

CREATE POLICY "Users can read own withdrawal requests"
  ON withdrawal_requests FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create withdrawal requests"
  ON withdrawal_requests FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can cancel own pending requests"
  ON withdrawal_requests FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() AND status = 'pending')
  WITH CHECK (status = 'cancelled');

CREATE POLICY "System can manage withdrawal requests"
  ON withdrawal_requests FOR UPDATE
  TO authenticated
  USING (true);

INSERT INTO withdrawal_methods (country_code, country_name, method_type, method_name, min_amount, processing_time) VALUES
('SA', 'السعودية', 'bank_transfer', 'بنك الراجحي', 1000, '1-3 أيام عمل'),
('SA', 'السعودية', 'bank_transfer', 'البنك الأهلي السعودي', 1000, '1-3 أيام عمل'),
('SA', 'السعودية', 'bank_transfer', 'بنك الرياض', 1000, '1-3 أيام عمل'),
('SA', 'السعودية', 'mobile_wallet', 'STC Pay', 1000, 'فوري - 24 ساعة'),

('EG', 'مصر', 'bank_transfer', 'البنك الأهلي المصري', 1000, '1-3 أيام عمل'),
('EG', 'مصر', 'bank_transfer', 'بنك مصر', 1000, '1-3 أيام عمل'),
('EG', 'مصر', 'mobile_wallet', 'فودافون كاش', 1000, 'فوري - 24 ساعة'),
('EG', 'مصر', 'mobile_wallet', 'اتصالات كاش', 1000, 'فوري - 24 ساعة'),
('EG', 'مصر', 'mobile_wallet', 'أورنج كاش', 1000, 'فوري - 24 ساعة'),

('AE', 'الإمارات', 'bank_transfer', 'بنك الإمارات الإسلامي', 1000, '1-3 أيام عمل'),
('AE', 'الإمارات', 'bank_transfer', 'بنك دبي الإسلامي', 1000, '1-3 أيام عمل'),
('AE', 'الإمارات', 'bank_transfer', 'بنك أبوظبي الأول', 1000, '1-3 أيام عمل'),

('KW', 'الكويت', 'bank_transfer', 'بنك الكويت الوطني', 1000, '1-3 أيام عمل'),
('KW', 'الكويت', 'bank_transfer', 'بنك الخليج', 1000, '1-3 أيام عمل'),

('QA', 'قطر', 'bank_transfer', 'بنك قطر الوطني', 1000, '1-3 أيام عمل'),
('QA', 'قطر', 'bank_transfer', 'بنك قطر الإسلامي', 1000, '1-3 أيام عمل'),

('BH', 'البحرين', 'bank_transfer', 'بنك البحرين الوطني', 1000, '1-3 أيام عمل'),
('BH', 'البحرين', 'bank_transfer', 'بنك البحرين الإسلامي', 1000, '1-3 أيام عمل'),

('OM', 'عمان', 'bank_transfer', 'بنك مسقط', 1000, '1-3 أيام عمل'),
('OM', 'عمان', 'bank_transfer', 'البنك الأهلي العماني', 1000, '1-3 أيام عمل'),

('JO', 'الأردن', 'bank_transfer', 'البنك الأهلي الأردني', 1000, '1-3 أيام عمل'),
('JO', 'الأردن', 'bank_transfer', 'بنك الأردن', 1000, '1-3 أيام عمل'),

('LB', 'لبنان', 'bank_transfer', 'بنك لبنان والمهجر', 1000, '1-3 أيام عمل'),
('LB', 'لبنان', 'bank_transfer', 'البنك اللبناني الفرنسي', 1000, '1-3 أيام عمل'),

('IQ', 'العراق', 'bank_transfer', 'المصرف التجاري العراقي', 1000, '1-3 أيام عمل'),
('IQ', 'العراق', 'mobile_wallet', 'زين كاش', 1000, 'فوري - 24 ساعة'),

('MA', 'المغرب', 'bank_transfer', 'بنك المغرب', 1000, '1-3 أيام عمل'),
('MA', 'المغرب', 'mobile_wallet', 'CIH Mobile', 1000, 'فوري - 24 ساعة'),

('DZ', 'الجزائر', 'bank_transfer', 'بنك الجزائر الخارجي', 1000, '1-3 أيام عمل'),
('DZ', 'الجزائر', 'mobile_wallet', 'موبيليس', 1000, 'فوري - 24 ساعة'),

('TN', 'تونس', 'bank_transfer', 'البنك الوطني التونسي', 1000, '1-3 أيام عمل'),

('SD', 'السودان', 'bank_transfer', 'بنك الخرطوم', 1000, '1-3 أيام عمل'),

('YE', 'اليمن', 'bank_transfer', 'بنك اليمن الدولي', 1000, '1-3 أيام عمل'),

('PS', 'فلسطين', 'bank_transfer', 'بنك فلسطين', 1000, '1-3 أيام عمل'),

('GLOBAL', 'دولي', 'paypal', 'PayPal', 1000, '3-5 أيام عمل'),
('GLOBAL', 'دولي', 'wise', 'Wise (TransferWise)', 1000, '1-2 أيام عمل'),
('GLOBAL', 'دولي', 'western_union', 'Western Union', 1000, '1-2 أيام عمل')

ON CONFLICT DO NOTHING;
