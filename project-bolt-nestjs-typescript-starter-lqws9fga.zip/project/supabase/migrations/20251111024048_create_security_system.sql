/*
  # نظام الأمان المتقدم

  1. جداول جديدة
    - `two_factor_auth` - المصادقة الثنائية
    - `login_history` - سجل تسجيل الدخول
    - `security_logs` - سجلات الأمان

  2. الأمان
    - RLS
*/

CREATE TABLE IF NOT EXISTS two_factor_auth (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  enabled boolean DEFAULT false,
  secret text,
  backup_codes text[],
  verified_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(profile_id)
);

CREATE INDEX IF NOT EXISTS idx_2fa_profile ON two_factor_auth(profile_id);

ALTER TABLE two_factor_auth ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own 2FA" ON two_factor_auth
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "Users can manage own 2FA" ON two_factor_auth
  FOR ALL
  TO authenticated
  USING (auth.uid() = profile_id)
  WITH CHECK (auth.uid() = profile_id);

CREATE TABLE IF NOT EXISTS login_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  ip_address text,
  user_agent text,
  device_type text,
  location jsonb DEFAULT '{}'::jsonb,
  success boolean DEFAULT true,
  failure_reason text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_login_history_profile ON login_history(profile_id);
CREATE INDEX IF NOT EXISTS idx_login_history_created ON login_history(created_at DESC);

ALTER TABLE login_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own login history" ON login_history
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE TABLE IF NOT EXISTS security_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  description text,
  ip_address text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_security_logs_profile ON security_logs(profile_id);
CREATE INDEX IF NOT EXISTS idx_security_logs_created ON security_logs(created_at DESC);

ALTER TABLE security_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own security logs" ON security_logs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);
