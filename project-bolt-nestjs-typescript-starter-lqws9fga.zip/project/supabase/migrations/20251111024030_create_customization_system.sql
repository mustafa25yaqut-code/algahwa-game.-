/*
  # نظام التخصيص والسمات

  1. جداول جديدة
    - `user_themes` - سمات المستخدم

  2. الأمان
    - RLS
*/

CREATE TABLE IF NOT EXISTS user_themes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  theme_name text DEFAULT 'default',
  primary_color text DEFAULT '#d4af37',
  secondary_color text DEFAULT '#1a1a2e',
  accent_color text DEFAULT '#50c878',
  background_image text,
  board_style text DEFAULT 'classic',
  dice_style text DEFAULT 'standard',
  piece_style text DEFAULT 'modern',
  sound_pack text DEFAULT 'default',
  music_enabled boolean DEFAULT true,
  sound_effects_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(profile_id)
);

CREATE INDEX IF NOT EXISTS idx_user_themes_profile ON user_themes(profile_id);

ALTER TABLE user_themes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own theme" ON user_themes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "Users can manage own theme" ON user_themes
  FOR ALL
  TO authenticated
  USING (auth.uid() = profile_id)
  WITH CHECK (auth.uid() = profile_id);
