/*
  # Create User Profiles and Social Features

  1. New Tables
    - `user_profiles`
      - `id` (uuid, primary key) - References auth.users
      - `username` (text, unique) - Username
      - `full_name` (text) - Full name
      - `avatar_url` (text, nullable) - Profile picture URL
      - `birth_date` (date, nullable) - Birth date
      - `country` (text, nullable) - Country
      - `gender` (text, nullable) - Gender (male, female, other)
      - `level` (integer) - User level based on XP
      - `xp` (integer) - Experience points
      - `bio` (text, nullable) - User bio
      - `created_at` (timestamptz) - Account creation date
      - `updated_at` (timestamptz) - Last update

    - `game_statistics`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `game_type` (text) - Game type: ludo, domino, jakaro, backgammon
      - `wins` (integer) - Number of wins
      - `losses` (integer) - Number of losses
      - `total_games` (integer) - Total games played
      - `win_rate` (decimal) - Win rate percentage
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `friendships`
      - `id` (uuid, primary key)
      - `requester_id` (uuid, foreign key) - User who sent request
      - `addressee_id` (uuid, foreign key) - User who received request
      - `status` (text) - Status: pending, accepted, rejected
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `achievements`
      - `id` (uuid, primary key)
      - `code` (text, unique) - Achievement code
      - `name` (text) - Achievement name
      - `description` (text) - Achievement description
      - `icon` (text) - Achievement icon/emoji
      - `xp_reward` (integer) - XP reward for unlocking
      - `created_at` (timestamptz)

    - `user_achievements`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `achievement_id` (uuid, foreign key) - References achievements
      - `unlocked_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can read their own profile
    - Users can update their own profile
    - Users can read public profile data of others
    - Friend requests have proper access control

  3. Indexes
    - Index on user_id for faster lookups
    - Index on game_type for statistics
    - Unique constraint on friendships to prevent duplicates
*/

CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  birth_date date,
  country text,
  gender text CHECK (gender IN ('male', 'female', 'other')),
  level integer NOT NULL DEFAULT 1,
  xp integer NOT NULL DEFAULT 0,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS game_statistics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  wins integer NOT NULL DEFAULT 0,
  losses integer NOT NULL DEFAULT 0,
  total_games integer NOT NULL DEFAULT 0,
  win_rate decimal(5,2) NOT NULL DEFAULT 0.00,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, game_type)
);

CREATE TABLE IF NOT EXISTS friendships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  addressee_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT unique_friendship UNIQUE (requester_id, addressee_id),
  CONSTRAINT no_self_friendship CHECK (requester_id != addressee_id)
);

CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  xp_reward integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  achievement_id uuid NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);

CREATE INDEX IF NOT EXISTS idx_game_statistics_user_id ON game_statistics(user_id);
CREATE INDEX IF NOT EXISTS idx_game_statistics_game_type ON game_statistics(game_type);
CREATE INDEX IF NOT EXISTS idx_friendships_requester ON friendships(requester_id);
CREATE INDEX IF NOT EXISTS idx_friendships_addressee ON friendships(addressee_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON user_achievements(user_id);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can read public profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can read own statistics"
  ON game_statistics FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can view others statistics"
  ON game_statistics FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can insert statistics"
  ON game_statistics FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "System can update statistics"
  ON game_statistics FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can read own friendships"
  ON friendships FOR SELECT
  TO authenticated
  USING (requester_id = auth.uid() OR addressee_id = auth.uid());

CREATE POLICY "Users can send friend requests"
  ON friendships FOR INSERT
  TO authenticated
  WITH CHECK (requester_id = auth.uid());

CREATE POLICY "Users can update received friend requests"
  ON friendships FOR UPDATE
  TO authenticated
  USING (addressee_id = auth.uid());

CREATE POLICY "Users can delete own friendships"
  ON friendships FOR DELETE
  TO authenticated
  USING (requester_id = auth.uid() OR addressee_id = auth.uid());

CREATE POLICY "Anyone can read achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can read own achievements"
  ON user_achievements FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can view others achievements"
  ON user_achievements FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can insert achievements"
  ON user_achievements FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

INSERT INTO achievements (code, name, description, icon, xp_reward) VALUES
  ('first_win', 'الفوز الأول', 'فز بأول مباراة لك', '🏆', 50),
  ('win_streak_5', 'سلسلة انتصارات', 'فز بـ 5 مباريات متتالية', '🔥', 100),
  ('games_10', 'لاعب نشط', 'العب 10 مباريات', '⚡', 75),
  ('games_50', 'لاعب محترف', 'العب 50 مباراة', '💎', 200),
  ('games_100', 'أسطورة', 'العب 100 مباراة', '👑', 500),
  ('friend_5', 'اجتماعي', 'أضف 5 أصدقاء', '👥', 50),
  ('all_games', 'متعدد المواهب', 'العب جميع أنواع الألعاب', '🎮', 150),
  ('level_10', 'مستوى 10', 'وصل للمستوى 10', '⭐', 100),
  ('level_25', 'مستوى 25', 'وصل للمستوى 25', '🌟', 250),
  ('level_50', 'مستوى 50', 'وصل للمستوى 50', '✨', 500)
ON CONFLICT (code) DO NOTHING;
