/*
  # نظام المجموعات والمسابقات

  1. جداول جديدة
    - `groups` - المجموعات/الرومات
      - `id` (uuid, primary key)
      - `group_name` (text) - اسم المجموعة
      - `group_avatar` (text) - صورة المجموعة
      - `owner_profile_id` (uuid) - مالك المجموعة
      - `creation_fee` (numeric) - رسوم الإنشاء
      - `total_members` (integer) - عدد الأعضاء
      - `max_members` (integer) - الحد الأقصى للأعضاء
      - `group_rank` (integer) - تصنيف المجموعة
      - `total_competitions` (integer) - عدد المسابقات
      - `total_prizes` (numeric) - إجمالي الجوائز
      - `status` (text) - 'active', 'suspended'
      - `created_at` (timestamp)
    
    - `group_members` - أعضاء المجموعات
      - `id` (uuid, primary key)
      - `group_id` (uuid, foreign key)
      - `profile_id` (uuid)
      - `role` (text) - 'owner', 'admin', 'member'
      - `joined_at` (timestamp)
    
    - `group_join_requests` - طلبات الانضمام
      - `id` (uuid, primary key)
      - `group_id` (uuid, foreign key)
      - `profile_id` (uuid)
      - `status` (text) - 'pending', 'accepted', 'rejected'
      - `created_at` (timestamp)
    
    - `group_voice_channels` - قنوات الصوت (10 مايكات)
      - `id` (uuid, primary key)
      - `group_id` (uuid, foreign key)
      - `channel_number` (integer) - رقم القناة (1-10)
      - `profile_id` (uuid) - اللاعب الحالي
      - `is_active` (boolean)
      - `updated_at` (timestamp)
    
    - `group_competitions` - المسابقات
      - `id` (uuid, primary key)
      - `group_id` (uuid, foreign key)
      - `competition_name` (text)
      - `game_type` (text) - 'ludo', 'domino', 'jakaro', 'backgammon'
      - `total_prize_pool` (numeric) - مجموع الجوائز
      - `round_duration` (integer) - مدة الجولة بالثواني (180 = 3 دقائق)
      - `status` (text) - 'waiting', 'in_progress', 'completed'
      - `winner_profile_id` (uuid)
      - `winner_prize` (numeric) - ثلثي الجوائز
      - `owner_commission` (numeric) - ثلث للمالك
      - `created_at` (timestamp)
      - `started_at` (timestamp)
      - `completed_at` (timestamp)
    
    - `competition_participants` - المشاركين في المسابقة
      - `id` (uuid, primary key)
      - `competition_id` (uuid, foreign key)
      - `profile_id` (uuid)
      - `entry_fee` (numeric)
      - `current_score` (integer)
      - `rank` (integer)
      - `joined_at` (timestamp)
    
    - `competition_supporters` - الداعمين أثناء المسابقة
      - `id` (uuid, primary key)
      - `competition_id` (uuid, foreign key)
      - `supporter_profile_id` (uuid)
      - `participant_profile_id` (uuid) - المتحدي المدعوم
      - `support_amount` (numeric) - قيمة الدعم
      - `support_type` (text) - 'gift', 'boost', 'sponsor'
      - `created_at` (timestamp)
    
    - `group_music_queue` - قائمة تشغيل الموسيقى
      - `id` (uuid, primary key)
      - `group_id` (uuid, foreign key)
      - `music_url` (text)
      - `music_title` (text)
      - `requested_by_profile_id` (uuid)
      - `is_playing` (boolean)
      - `created_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول
    - فقط المالك يمكنه التحكم الكامل
*/

-- جدول المجموعات
CREATE TABLE IF NOT EXISTS groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_name text NOT NULL,
  group_avatar text,
  owner_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  creation_fee numeric DEFAULT 5.00,
  total_members integer DEFAULT 1,
  max_members integer DEFAULT 100,
  group_rank integer DEFAULT 0,
  total_competitions integer DEFAULT 0,
  total_prizes numeric DEFAULT 0,
  status text DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_groups_owner ON groups(owner_profile_id);
CREATE INDEX IF NOT EXISTS idx_groups_rank ON groups(group_rank DESC);
CREATE INDEX IF NOT EXISTS idx_groups_status ON groups(status);

ALTER TABLE groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active groups" ON groups FOR SELECT USING (status = 'active');
CREATE POLICY "Users can create groups" ON groups FOR INSERT WITH CHECK (true);
CREATE POLICY "Owners can update their groups" ON groups FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Owners can delete their groups" ON groups FOR DELETE USING (true);

-- جدول أعضاء المجموعات
CREATE TABLE IF NOT EXISTS group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  role text DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(group_id, profile_id)
);

CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_profile ON group_members(profile_id);

ALTER TABLE group_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view group members" ON group_members FOR SELECT USING (true);
CREATE POLICY "Users can join groups" ON group_members FOR INSERT WITH CHECK (true);
CREATE POLICY "Members can leave groups" ON group_members FOR DELETE USING (true);

-- جدول طلبات الانضمام
CREATE TABLE IF NOT EXISTS group_join_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  UNIQUE(group_id, profile_id)
);

CREATE INDEX IF NOT EXISTS idx_group_requests_group ON group_join_requests(group_id);
CREATE INDEX IF NOT EXISTS idx_group_requests_status ON group_join_requests(status);

ALTER TABLE group_join_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view requests" ON group_join_requests FOR SELECT USING (true);
CREATE POLICY "Users can create requests" ON group_join_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update requests" ON group_join_requests FOR UPDATE USING (true) WITH CHECK (true);

-- جدول قنوات الصوت
CREATE TABLE IF NOT EXISTS group_voice_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  channel_number integer NOT NULL CHECK (channel_number BETWEEN 1 AND 10),
  profile_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  is_active boolean DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(group_id, channel_number)
);

CREATE INDEX IF NOT EXISTS idx_voice_channels_group ON group_voice_channels(group_id);

ALTER TABLE group_voice_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view voice channels" ON group_voice_channels FOR SELECT USING (true);
CREATE POLICY "Users can manage voice channels" ON group_voice_channels FOR ALL USING (true) WITH CHECK (true);

-- جدول المسابقات
CREATE TABLE IF NOT EXISTS group_competitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  competition_name text NOT NULL,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  total_prize_pool numeric DEFAULT 0,
  round_duration integer DEFAULT 180,
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'in_progress', 'completed')),
  winner_profile_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  winner_prize numeric DEFAULT 0,
  owner_commission numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  started_at timestamptz,
  completed_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_competitions_group ON group_competitions(group_id);
CREATE INDEX IF NOT EXISTS idx_competitions_status ON group_competitions(status);

ALTER TABLE group_competitions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view competitions" ON group_competitions FOR SELECT USING (true);
CREATE POLICY "Users can manage competitions" ON group_competitions FOR ALL USING (true) WITH CHECK (true);

-- جدول المشاركين
CREATE TABLE IF NOT EXISTS competition_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id uuid NOT NULL REFERENCES group_competitions(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  entry_fee numeric DEFAULT 0,
  current_score integer DEFAULT 0,
  rank integer,
  joined_at timestamptz DEFAULT now(),
  UNIQUE(competition_id, profile_id)
);

CREATE INDEX IF NOT EXISTS idx_participants_competition ON competition_participants(competition_id);

ALTER TABLE competition_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view participants" ON competition_participants FOR SELECT USING (true);
CREATE POLICY "Users can join competitions" ON competition_participants FOR INSERT WITH CHECK (true);

-- جدول الداعمين
CREATE TABLE IF NOT EXISTS competition_supporters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id uuid NOT NULL REFERENCES group_competitions(id) ON DELETE CASCADE,
  supporter_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  participant_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  support_amount numeric NOT NULL,
  support_type text DEFAULT 'gift' CHECK (support_type IN ('gift', 'boost', 'sponsor')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_supporters_competition ON competition_supporters(competition_id);
CREATE INDEX IF NOT EXISTS idx_supporters_participant ON competition_supporters(participant_profile_id);

ALTER TABLE competition_supporters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view support" ON competition_supporters FOR SELECT USING (true);
CREATE POLICY "Users can support participants" ON competition_supporters FOR INSERT WITH CHECK (true);

-- جدول قائمة الموسيقى
CREATE TABLE IF NOT EXISTS group_music_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  music_url text NOT NULL,
  music_title text,
  requested_by_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  is_playing boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_music_queue_group ON group_music_queue(group_id);

ALTER TABLE group_music_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view music queue" ON group_music_queue FOR SELECT USING (true);
CREATE POLICY "Users can manage music" ON group_music_queue FOR ALL USING (true) WITH CHECK (true);

-- دالة لحساب تصنيف المجموعة
CREATE OR REPLACE FUNCTION calculate_group_rank(p_group_id uuid)
RETURNS integer AS $$
DECLARE
  v_rank integer;
BEGIN
  SELECT 
    (total_members * 10) + 
    (total_competitions * 50) + 
    (COALESCE(total_prizes, 0) / 10)::integer
  INTO v_rank
  FROM groups
  WHERE id = p_group_id;
  
  RETURN COALESCE(v_rank, 0);
END;
$$ LANGUAGE plpgsql;

-- دالة لإنهاء المسابقة وتوزيع الجوائز
CREATE OR REPLACE FUNCTION complete_competition(
  p_competition_id uuid,
  p_winner_profile_id uuid
)
RETURNS void AS $$
DECLARE
  v_total_prize numeric;
  v_winner_prize numeric;
  v_owner_commission numeric;
  v_group_id uuid;
BEGIN
  SELECT total_prize_pool, group_id 
  INTO v_total_prize, v_group_id
  FROM group_competitions
  WHERE id = p_competition_id;
  
  v_winner_prize := v_total_prize * 0.666667;
  v_owner_commission := v_total_prize * 0.333333;
  
  UPDATE group_competitions
  SET 
    status = 'completed',
    winner_profile_id = p_winner_profile_id,
    winner_prize = v_winner_prize,
    owner_commission = v_owner_commission,
    completed_at = now()
  WHERE id = p_competition_id;
  
  UPDATE groups
  SET 
    total_competitions = total_competitions + 1,
    total_prizes = total_prizes + v_total_prize,
    group_rank = calculate_group_rank(v_group_id)
  WHERE id = v_group_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
