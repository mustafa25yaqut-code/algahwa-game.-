/*
  # Ludo Game Database Schema

  ## Overview
  This migration creates the complete database structure for a multiplayer Ludo game application.

  ## Tables Created

  ### 1. games
  Stores information about each game session
  - `id` (uuid, primary key) - Unique game identifier
  - `room_code` (text, unique) - 6-character room code for joining games
  - `status` (text) - Game status: 'waiting', 'in_progress', 'completed'
  - `current_turn` (integer) - Index of player whose turn it is (0-3)
  - `winner_id` (uuid, nullable) - ID of winning player
  - `created_at` (timestamptz) - Game creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. players
  Stores player information for each game
  - `id` (uuid, primary key) - Unique player identifier
  - `game_id` (uuid, foreign key) - Reference to games table
  - `player_index` (integer) - Player position (0-3) representing colors
  - `player_name` (text) - Player's display name
  - `is_ready` (boolean) - Whether player is ready to start
  - `pieces_home` (integer) - Number of pieces that reached home (0-4)
  - `created_at` (timestamptz) - Player join timestamp

  ### 3. game_state
  Stores the current state of all pieces on the board
  - `id` (uuid, primary key) - Unique state identifier
  - `game_id` (uuid, foreign key) - Reference to games table
  - `player_index` (integer) - Which player's piece (0-3)
  - `piece_index` (integer) - Which piece (0-3)
  - `position` (integer) - Current position on board (-1 = start area, 0-51 = main path, 100+ = home stretch)
  - `updated_at` (timestamptz) - Last position update

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Public read access for game data (spectators allowed)
  - Authenticated users can create games
  - Only players in a game can update their moves

  ## Indexes
  - Index on room_code for fast game lookup
  - Index on game_id for efficient player and state queries
*/

CREATE TABLE IF NOT EXISTS games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_code text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'waiting',
  current_turn integer NOT NULL DEFAULT 0,
  winner_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('waiting', 'in_progress', 'completed')),
  CONSTRAINT valid_turn CHECK (current_turn >= 0 AND current_turn <= 3)
);

CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  player_index integer NOT NULL,
  player_name text NOT NULL,
  is_ready boolean DEFAULT false,
  pieces_home integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_player_index CHECK (player_index >= 0 AND player_index <= 3),
  CONSTRAINT valid_pieces_home CHECK (pieces_home >= 0 AND pieces_home <= 4),
  UNIQUE(game_id, player_index)
);

CREATE TABLE IF NOT EXISTS game_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  player_index integer NOT NULL,
  piece_index integer NOT NULL,
  position integer NOT NULL DEFAULT -1,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_player_idx CHECK (player_index >= 0 AND player_index <= 3),
  CONSTRAINT valid_piece_idx CHECK (piece_index >= 0 AND piece_index <= 3),
  UNIQUE(game_id, player_index, piece_index)
);

CREATE INDEX IF NOT EXISTS idx_games_room_code ON games(room_code);
CREATE INDEX IF NOT EXISTS idx_players_game_id ON players(game_id);
CREATE INDEX IF NOT EXISTS idx_game_state_game_id ON game_state(game_id);

ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view games"
  ON games FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create games"
  ON games FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update games"
  ON games FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view players"
  ON players FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can join games"
  ON players FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update player status"
  ON players FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view game state"
  ON game_state FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can create game state"
  ON game_state FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update game state"
  ON game_state FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);
