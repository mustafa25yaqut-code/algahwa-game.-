/*
  # نظام المتجر

  1. جداول جديدة
    - `store_items` - عناصر المتجر
      - `id` (uuid, primary key)
      - `category` (text) - الفئة
      - `name` (text) - الاسم
      - `description` (text) - الوصف
      - `image_url` (text) - صورة
      - `price_coins` (integer) - السعر بالعملات
      - `price_real` (numeric) - السعر الحقيقي
      - `rarity` (text) - الندرة
      - `limited` (boolean) - محدود
      - `available_until` (timestamp)
      - `stock` (integer) - المخزون
      - `active` (boolean) - نشط
      - `created_at` (timestamp)

    - `user_inventory` - مخزون المستخدم
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `item_id` (uuid)
      - `quantity` (integer)
      - `equipped` (boolean) - مجهز
      - `purchased_at` (timestamp)

    - `purchase_history` - سجل المشتريات
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `item_id` (uuid)
      - `quantity` (integer)
      - `total_price` (integer)
      - `currency_type` (text) - نوع العملة
      - `created_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول

  3. دوال
    - شراء عنصر
    - تجهيز عنصر
*/

CREATE TABLE IF NOT EXISTS store_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN (
    'avatar', 'frame', 'sticker_pack', 'theme', 'dice', 'board', 'vip', 'coins_pack'
  )),
  name text NOT NULL,
  description text,
  image_url text,
  price_coins integer DEFAULT 0,
  price_real numeric(10,2) DEFAULT 0,
  rarity text DEFAULT 'common' CHECK (rarity IN ('common', 'rare', 'epic', 'legendary')),
  limited boolean DEFAULT false,
  available_until timestamptz,
  stock integer DEFAULT -1,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_store_items_category ON store_items(category);
CREATE INDEX IF NOT EXISTS idx_store_items_active ON store_items(active);
CREATE INDEX IF NOT EXISTS idx_store_items_rarity ON store_items(rarity);

INSERT INTO store_items (category, name, description, price_coins, rarity) VALUES
  ('avatar', 'أفاتار الأسد', 'صورة رمزية للأسد الشجاع', 1000, 'rare'),
  ('avatar', 'أفاتار النسر', 'صورة رمزية للنسر المحلق', 1500, 'epic'),
  ('avatar', 'أفاتار التنين', 'صورة رمزية للتنين الأسطوري', 5000, 'legendary'),
  ('frame', 'إطار ذهبي', 'إطار ذهبي فاخر', 2000, 'epic'),
  ('frame', 'إطار ماسي', 'إطار ماسي نادر', 10000, 'legendary'),
  ('sticker_pack', 'حزمة ملصقات مضحكة', '20 ملصق مضحك', 500, 'common'),
  ('sticker_pack', 'حزمة ملصقات VIP', '50 ملصق حصري', 3000, 'epic'),
  ('theme', 'سمة الليل', 'سمة داكنة للعيون', 1000, 'rare'),
  ('theme', 'سمة الذهب', 'سمة ذهبية فاخرة', 5000, 'legendary'),
  ('dice', 'نرد ذهبي', 'نرد ذهبي لامع', 2000, 'rare'),
  ('dice', 'نرد الماس', 'نرد ماسي نادر', 8000, 'legendary'),
  ('board', 'لوحة كلاسيكية', 'لوحة بتصميم كلاسيكي', 1500, 'rare'),
  ('board', 'لوحة ملكية', 'لوحة بتصميم ملكي', 10000, 'legendary'),
  ('vip', 'VIP لمدة شهر', 'عضوية VIP لمدة شهر', 50000, 'epic'),
  ('vip', 'VIP لمدة سنة', 'عضوية VIP لمدة سنة', 500000, 'legendary'),
  ('coins_pack', 'حزمة 1000 عملة', '1000 عملة ذهبية', 0, 'common'),
  ('coins_pack', 'حزمة 5000 عملة', '5000 عملة ذهبية', 0, 'rare'),
  ('coins_pack', 'حزمة 10000 عملة', '10000 عملة ذهبية', 0, 'epic'),
  ('coins_pack', 'حزمة 50000 عملة', '50000 عملة ذهبية', 0, 'legendary')
ON CONFLICT DO NOTHING;

UPDATE store_items SET price_real = 0.99 WHERE name = 'حزمة 1000 عملة';
UPDATE store_items SET price_real = 4.99 WHERE name = 'حزمة 5000 عملة';
UPDATE store_items SET price_real = 9.99 WHERE name = 'حزمة 10000 عملة';
UPDATE store_items SET price_real = 49.99 WHERE name = 'حزمة 50000 عملة';

ALTER TABLE store_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active store items" ON store_items
  FOR SELECT
  USING (active = true);

CREATE TABLE IF NOT EXISTS user_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  item_id uuid NOT NULL REFERENCES store_items(id) ON DELETE CASCADE,
  quantity integer DEFAULT 1,
  equipped boolean DEFAULT false,
  purchased_at timestamptz DEFAULT now(),
  UNIQUE(profile_id, item_id)
);

CREATE INDEX IF NOT EXISTS idx_user_inventory_profile ON user_inventory(profile_id);
CREATE INDEX IF NOT EXISTS idx_user_inventory_equipped ON user_inventory(equipped);

ALTER TABLE user_inventory ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own inventory" ON user_inventory
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "System can manage inventory" ON user_inventory
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS purchase_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  item_id uuid NOT NULL REFERENCES store_items(id) ON DELETE SET NULL,
  quantity integer DEFAULT 1,
  total_price integer NOT NULL,
  currency_type text CHECK (currency_type IN ('coins', 'real')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_purchase_history_profile ON purchase_history(profile_id);
CREATE INDEX IF NOT EXISTS idx_purchase_history_created ON purchase_history(created_at DESC);

ALTER TABLE purchase_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own purchases" ON purchase_history
  FOR SELECT
  TO authenticated
  USING (auth.uid() = profile_id);

CREATE POLICY "System can create purchases" ON purchase_history
  FOR INSERT
  WITH CHECK (true);

CREATE OR REPLACE FUNCTION purchase_item(
  p_profile_id uuid,
  p_item_id uuid,
  p_quantity integer DEFAULT 1
)
RETURNS boolean AS $$
DECLARE
  v_item record;
  v_user_coins integer;
  v_total_price integer;
BEGIN
  SELECT * INTO v_item
  FROM store_items
  WHERE id = p_item_id AND active = true;
  
  IF v_item.id IS NULL THEN
    RAISE EXCEPTION 'Item not found or inactive';
  END IF;
  
  IF v_item.stock != -1 AND v_item.stock < p_quantity THEN
    RAISE EXCEPTION 'Insufficient stock';
  END IF;
  
  v_total_price := v_item.price_coins * p_quantity;
  
  SELECT coins INTO v_user_coins
  FROM user_profiles
  WHERE id = p_profile_id;
  
  IF v_user_coins < v_total_price THEN
    RAISE EXCEPTION 'Insufficient coins';
  END IF;
  
  UPDATE user_profiles
  SET coins = coins - v_total_price
  WHERE id = p_profile_id;
  
  INSERT INTO user_inventory (profile_id, item_id, quantity)
  VALUES (p_profile_id, p_item_id, p_quantity)
  ON CONFLICT (profile_id, item_id)
  DO UPDATE SET quantity = user_inventory.quantity + p_quantity;
  
  IF v_item.stock != -1 THEN
    UPDATE store_items
    SET stock = stock - p_quantity
    WHERE id = p_item_id;
  END IF;
  
  INSERT INTO purchase_history (profile_id, item_id, quantity, total_price, currency_type)
  VALUES (p_profile_id, p_item_id, p_quantity, v_total_price, 'coins');
  
  PERFORM create_notification(
    p_profile_id,
    'system',
    'عملية شراء ناجحة 🛒',
    'لقد اشتريت ' || v_item.name,
    jsonb_build_object('item_id', p_item_id)
  );
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION equip_item(
  p_profile_id uuid,
  p_item_id uuid
)
RETURNS boolean AS $$
DECLARE
  v_item_category text;
BEGIN
  SELECT si.category INTO v_item_category
  FROM user_inventory ui
  JOIN store_items si ON ui.item_id = si.id
  WHERE ui.profile_id = p_profile_id AND ui.item_id = p_item_id;
  
  IF v_item_category IS NULL THEN
    RETURN false;
  END IF;
  
  UPDATE user_inventory ui
  SET equipped = false
  FROM store_items si
  WHERE ui.profile_id = p_profile_id
    AND ui.item_id = si.id
    AND si.category = v_item_category;
  
  UPDATE user_inventory
  SET equipped = true
  WHERE profile_id = p_profile_id AND item_id = p_item_id;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
