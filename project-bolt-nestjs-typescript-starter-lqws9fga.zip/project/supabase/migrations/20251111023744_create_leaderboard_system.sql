/*
  # نظام الترتيب العام (Leaderboard)

  1. جداول جديدة
    - `global_leaderboard` - الترتيب العام
      - `id` (uuid, primary key)
      - `profile_id` (uuid)
      - `leaderboard_type` (text) - نوع الترتيب
      - `score` (numeric) - النقاط
      - `rank` (integer) - الترتيب
      - `period` (text) - الفترة (daily, weekly, monthly, all_time)
      - `period_start` (date)
      - `period_end` (date)
      - `updated_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول

  3. دوال
    - تحديث الترتيب
    - الحصول على الترتيب
    - إعادة حساب الترتيب
*/

CREATE TABLE IF NOT EXISTS global_leaderboard (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  leaderboard_type text NOT NULL CHECK (leaderboard_type IN (
    'total_wins', 'win_rate', 'coins_earned', 'level', 'xp', 'win_streak'
  )),
  score numeric NOT NULL DEFAULT 0,
  rank integer,
  period text NOT NULL CHECK (period IN ('daily', 'weekly', 'monthly', 'all_time')),
  period_start date,
  period_end date,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(profile_id, leaderboard_type, period, period_start)
);

CREATE INDEX IF NOT EXISTS idx_leaderboard_type ON global_leaderboard(leaderboard_type);
CREATE INDEX IF NOT EXISTS idx_leaderboard_period ON global_leaderboard(period);
CREATE INDEX IF NOT EXISTS idx_leaderboard_score ON global_leaderboard(score DESC);
CREATE INDEX IF NOT EXISTS idx_leaderboard_rank ON global_leaderboard(rank);
CREATE INDEX IF NOT EXISTS idx_leaderboard_profile ON global_leaderboard(profile_id);

ALTER TABLE global_leaderboard ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view leaderboard" ON global_leaderboard
  FOR SELECT
  USING (true);

CREATE POLICY "System can manage leaderboard" ON global_leaderboard
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE OR REPLACE FUNCTION update_leaderboard_entry(
  p_profile_id uuid,
  p_leaderboard_type text,
  p_score numeric,
  p_period text
)
RETURNS void AS $$
DECLARE
  v_period_start date;
  v_period_end date;
BEGIN
  IF p_period = 'daily' THEN
    v_period_start := CURRENT_DATE;
    v_period_end := CURRENT_DATE;
  ELSIF p_period = 'weekly' THEN
    v_period_start := date_trunc('week', CURRENT_DATE)::date;
    v_period_end := (date_trunc('week', CURRENT_DATE) + interval '6 days')::date;
  ELSIF p_period = 'monthly' THEN
    v_period_start := date_trunc('month', CURRENT_DATE)::date;
    v_period_end := (date_trunc('month', CURRENT_DATE) + interval '1 month' - interval '1 day')::date;
  ELSIF p_period = 'all_time' THEN
    v_period_start := '2000-01-01'::date;
    v_period_end := '2099-12-31'::date;
  END IF;
  
  INSERT INTO global_leaderboard (
    profile_id, leaderboard_type, score, period, period_start, period_end
  ) VALUES (
    p_profile_id, p_leaderboard_type, p_score, p_period, v_period_start, v_period_end
  )
  ON CONFLICT (profile_id, leaderboard_type, period, period_start)
  DO UPDATE SET
    score = p_score,
    updated_at = now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION recalculate_leaderboard_ranks(
  p_leaderboard_type text,
  p_period text
)
RETURNS void AS $$
DECLARE
  v_period_start date;
BEGIN
  IF p_period = 'daily' THEN
    v_period_start := CURRENT_DATE;
  ELSIF p_period = 'weekly' THEN
    v_period_start := date_trunc('week', CURRENT_DATE)::date;
  ELSIF p_period = 'monthly' THEN
    v_period_start := date_trunc('month', CURRENT_DATE)::date;
  ELSIF p_period = 'all_time' THEN
    v_period_start := '2000-01-01'::date;
  END IF;
  
  WITH ranked AS (
    SELECT 
      id,
      ROW_NUMBER() OVER (ORDER BY score DESC) as new_rank
    FROM global_leaderboard
    WHERE leaderboard_type = p_leaderboard_type
      AND period = p_period
      AND period_start = v_period_start
  )
  UPDATE global_leaderboard gl
  SET rank = ranked.new_rank
  FROM ranked
  WHERE gl.id = ranked.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_leaderboard(
  p_leaderboard_type text,
  p_period text,
  p_limit integer DEFAULT 100
)
RETURNS TABLE (
  rank integer,
  profile_id uuid,
  username text,
  avatar_url text,
  level integer,
  score numeric,
  player_id text
) AS $$
DECLARE
  v_period_start date;
BEGIN
  IF p_period = 'daily' THEN
    v_period_start := CURRENT_DATE;
  ELSIF p_period = 'weekly' THEN
    v_period_start := date_trunc('week', CURRENT_DATE)::date;
  ELSIF p_period = 'monthly' THEN
    v_period_start := date_trunc('month', CURRENT_DATE)::date;
  ELSIF p_period = 'all_time' THEN
    v_period_start := '2000-01-01'::date;
  END IF;
  
  RETURN QUERY
  SELECT 
    gl.rank,
    gl.profile_id,
    up.username,
    up.avatar_url,
    up.level,
    gl.score,
    up.player_id
  FROM global_leaderboard gl
  JOIN user_profiles up ON gl.profile_id = up.id
  WHERE gl.leaderboard_type = p_leaderboard_type
    AND gl.period = p_period
    AND gl.period_start = v_period_start
  ORDER BY gl.rank
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_player_rank(
  p_profile_id uuid,
  p_leaderboard_type text,
  p_period text
)
RETURNS TABLE (
  rank integer,
  score numeric,
  total_players bigint
) AS $$
DECLARE
  v_period_start date;
BEGIN
  IF p_period = 'daily' THEN
    v_period_start := CURRENT_DATE;
  ELSIF p_period = 'weekly' THEN
    v_period_start := date_trunc('week', CURRENT_DATE)::date;
  ELSIF p_period = 'monthly' THEN
    v_period_start := date_trunc('month', CURRENT_DATE)::date;
  ELSIF p_period = 'all_time' THEN
    v_period_start := '2000-01-01'::date;
  END IF;
  
  RETURN QUERY
  SELECT 
    gl.rank,
    gl.score,
    (SELECT COUNT(*) FROM global_leaderboard 
     WHERE leaderboard_type = p_leaderboard_type 
     AND period = p_period 
     AND period_start = v_period_start)
  FROM global_leaderboard gl
  WHERE gl.profile_id = p_profile_id
    AND gl.leaderboard_type = p_leaderboard_type
    AND gl.period = p_period
    AND gl.period_start = v_period_start;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION update_all_leaderboards(p_profile_id uuid)
RETURNS void AS $$
DECLARE
  v_stats record;
  v_profile record;
BEGIN
  SELECT * INTO v_profile
  FROM user_profiles
  WHERE id = p_profile_id;
  
  SELECT * INTO v_stats
  FROM player_statistics
  WHERE profile_id = p_profile_id AND game_type = 'overall';
  
  IF v_stats.id IS NULL THEN
    RETURN;
  END IF;
  
  PERFORM update_leaderboard_entry(p_profile_id, 'total_wins', v_stats.total_wins, 'all_time');
  PERFORM update_leaderboard_entry(p_profile_id, 'total_wins', v_stats.total_wins, 'monthly');
  PERFORM update_leaderboard_entry(p_profile_id, 'total_wins', v_stats.total_wins, 'weekly');
  PERFORM update_leaderboard_entry(p_profile_id, 'total_wins', v_stats.total_wins, 'daily');
  
  PERFORM update_leaderboard_entry(p_profile_id, 'win_rate', v_stats.win_rate, 'all_time');
  PERFORM update_leaderboard_entry(p_profile_id, 'win_rate', v_stats.win_rate, 'monthly');
  
  PERFORM update_leaderboard_entry(p_profile_id, 'coins_earned', v_stats.total_coins_won, 'all_time');
  PERFORM update_leaderboard_entry(p_profile_id, 'coins_earned', v_stats.total_coins_won, 'monthly');
  
  PERFORM update_leaderboard_entry(p_profile_id, 'level', v_profile.level, 'all_time');
  PERFORM update_leaderboard_entry(p_profile_id, 'xp', v_profile.xp, 'all_time');
  
  PERFORM update_leaderboard_entry(p_profile_id, 'win_streak', v_stats.best_streak, 'all_time');
  PERFORM update_leaderboard_entry(p_profile_id, 'win_streak', v_stats.current_streak, 'monthly');
  
  PERFORM recalculate_leaderboard_ranks('total_wins', 'all_time');
  PERFORM recalculate_leaderboard_ranks('total_wins', 'monthly');
  PERFORM recalculate_leaderboard_ranks('total_wins', 'weekly');
  PERFORM recalculate_leaderboard_ranks('total_wins', 'daily');
  PERFORM recalculate_leaderboard_ranks('win_rate', 'all_time');
  PERFORM recalculate_leaderboard_ranks('level', 'all_time');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
