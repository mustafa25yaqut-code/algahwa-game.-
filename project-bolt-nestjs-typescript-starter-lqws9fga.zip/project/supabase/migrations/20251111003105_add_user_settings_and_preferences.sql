/*
  # Add User Settings and Preferences

  1. New Tables
    - `user_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `language` (text) - User's preferred language (ar, en, fr, etc.)
      - `music_enabled` (boolean) - Background music on/off
      - `sound_effects_enabled` (boolean) - Sound effects on/off
      - `privacy_spectate` (boolean) - Allow others to spectate games
      - `privacy_tracking` (boolean) - Allow analytics tracking
      - `privacy_do_not_disturb` (boolean) - Do not disturb mode
      - `privacy_profile_visible` (boolean) - Profile visible to others
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on user_settings table
    - Users can only read and update their own settings

  3. Default Values
    - Language: 'ar' (Arabic)
    - All sound settings: true
    - All privacy settings: false (allow all by default)
*/

CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  language text NOT NULL DEFAULT 'ar',
  music_enabled boolean NOT NULL DEFAULT true,
  sound_effects_enabled boolean NOT NULL DEFAULT true,
  privacy_spectate boolean NOT NULL DEFAULT false,
  privacy_tracking boolean NOT NULL DEFAULT false,
  privacy_do_not_disturb boolean NOT NULL DEFAULT false,
  privacy_profile_visible boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_user_settings_user_id ON user_settings(user_id);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own settings"
  ON user_settings FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());
