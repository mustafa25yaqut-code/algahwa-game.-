/*
  # Create Jakaro Game Tables

  1. New Tables
    - `jakaro_games`
      - `id` (uuid, primary key) - Unique game identifier
      - `status` (text) - Game status: waiting, active, finished
      - `current_turn_index` (integer) - Index of player whose turn it is
      - `table_cards` (jsonb) - Cards on the table
      - `deck_data` (jsonb) - Remaining cards in deck
      - `round` (integer) - Current round number
      - `last_capture` (uuid, nullable) - Last player who captured cards
      - `winner_id` (uuid, nullable) - Winner player ID
      - `created_at` (timestamptz) - Game creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

    - `jakaro_players`
      - `id` (uuid, primary key) - Unique player identifier
      - `game_id` (uuid, foreign key) - Reference to jakaro_games
      - `name` (text) - Player name
      - `hand_data` (jsonb) - Player's cards in hand
      - `collected_cards` (jsonb) - Cards collected by player
      - `score` (integer) - Player's current score
      - `is_connected` (boolean) - Connection status
      - `created_at` (timestamptz) - Player join timestamp

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read game data
    - Add policies for players to update their own data

  3. Indexes
    - Index on game_id for faster player lookups
    - Index on status for game filtering
*/

CREATE TABLE IF NOT EXISTS jakaro_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'waiting',
  current_turn_index integer NOT NULL DEFAULT 0,
  table_cards jsonb NOT NULL DEFAULT '[]'::jsonb,
  deck_data jsonb NOT NULL DEFAULT '[]'::jsonb,
  round integer NOT NULL DEFAULT 1,
  last_capture uuid,
  winner_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS jakaro_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES jakaro_games(id) ON DELETE CASCADE,
  name text NOT NULL,
  hand_data jsonb NOT NULL DEFAULT '[]'::jsonb,
  collected_cards jsonb NOT NULL DEFAULT '[]'::jsonb,
  score integer NOT NULL DEFAULT 0,
  is_connected boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_jakaro_players_game_id ON jakaro_players(game_id);
CREATE INDEX IF NOT EXISTS idx_jakaro_games_status ON jakaro_games(status);

ALTER TABLE jakaro_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE jakaro_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read game data"
  ON jakaro_games FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can create games"
  ON jakaro_games FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update games"
  ON jakaro_games FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read player data"
  ON jakaro_players FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can join games"
  ON jakaro_players FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Players can update own data"
  ON jakaro_players FOR UPDATE
  TO authenticated
  USING (true);
