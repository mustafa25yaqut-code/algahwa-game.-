/*
  # Create Wallet and Coins System

  1. New Tables
    - `user_wallets`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `balance` (integer) - User's coin balance
      - `total_earned` (integer) - Total coins earned
      - `total_spent` (integer) - Total coins spent
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `admin_wallet`
      - `id` (uuid, primary key)
      - `total_revenue` (decimal) - Total revenue in USD
      - `coins_revenue` (bigint) - Total coins collected as commission
      - `updated_at` (timestamptz)

    - `transactions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `type` (text) - Type: purchase, bet, win, commission, refund
      - `amount` (integer) - Amount in coins
      - `game_id` (uuid, nullable) - Reference to game if applicable
      - `game_type` (text, nullable) - Game type: ludo, domino, jakaro, backgammon
      - `description` (text) - Transaction description
      - `created_at` (timestamptz)

    - `game_bets`
      - `id` (uuid, primary key)
      - `game_id` (text) - Game identifier
      - `game_type` (text) - Game type: ludo, domino, jakaro, backgammon
      - `bet_amount` (integer) - Bet amount in coins (0 for free games)
      - `player1_id` (uuid) - First player
      - `player2_id` (uuid, nullable) - Second player
      - `player3_id` (uuid, nullable) - Third player (for 4-player games)
      - `player4_id` (uuid, nullable) - Fourth player (for 4-player games)
      - `winner_id` (uuid, nullable) - Winner user ID
      - `status` (text) - Status: waiting, active, completed, cancelled
      - `total_pot` (integer) - Total coins in pot
      - `winner_payout` (integer, nullable) - Winner payout (75%)
      - `commission` (integer, nullable) - Commission (25%)
      - `created_at` (timestamptz)
      - `completed_at` (timestamptz, nullable)

    - `payment_orders`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key) - References user_profiles
      - `amount_usd` (decimal) - Amount in USD
      - `coins_amount` (integer) - Amount in coins (100 coins = 1 USD)
      - `status` (text) - Status: pending, completed, failed, refunded
      - `payment_method` (text) - Payment method used
      - `payment_id` (text, nullable) - External payment ID
      - `created_at` (timestamptz)
      - `completed_at` (timestamptz, nullable)

  2. Security
    - Enable RLS on all tables
    - Users can only read their own wallet
    - Only system can update wallets
    - Transactions are read-only for users

  3. Functions
    - Function to create wallet when user signs up
    - Function to process bet and deduct coins
    - Function to process payout with 75/25 split

  4. Initial Data
    - Create admin wallet record
*/

CREATE TABLE IF NOT EXISTS user_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  balance integer NOT NULL DEFAULT 1000,
  total_earned integer NOT NULL DEFAULT 0,
  total_spent integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS admin_wallet (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  total_revenue decimal(12,2) NOT NULL DEFAULT 0.00,
  coins_revenue bigint NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('purchase', 'bet', 'win', 'commission', 'refund', 'bonus')),
  amount integer NOT NULL,
  game_id text,
  game_type text CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS game_bets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id text UNIQUE NOT NULL,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  bet_amount integer NOT NULL DEFAULT 0,
  player1_id uuid NOT NULL REFERENCES user_profiles(id),
  player2_id uuid REFERENCES user_profiles(id),
  player3_id uuid REFERENCES user_profiles(id),
  player4_id uuid REFERENCES user_profiles(id),
  winner_id uuid REFERENCES user_profiles(id),
  status text NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'active', 'completed', 'cancelled')),
  total_pot integer NOT NULL DEFAULT 0,
  winner_payout integer,
  commission integer,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  amount_usd decimal(10,2) NOT NULL,
  coins_amount integer NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  payment_method text,
  payment_id text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_user_wallets_user_id ON user_wallets(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_game_bets_game_id ON game_bets(game_id);
CREATE INDEX IF NOT EXISTS idx_game_bets_status ON game_bets(status);
CREATE INDEX IF NOT EXISTS idx_payment_orders_user_id ON payment_orders(user_id);

ALTER TABLE user_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_bets ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own wallet"
  ON user_wallets FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can update wallets"
  ON user_wallets FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "System can insert wallets"
  ON user_wallets FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can read own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can insert transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read game bets"
  ON game_bets FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can manage game bets"
  ON game_bets FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Users can read own payment orders"
  ON payment_orders FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can manage payment orders"
  ON payment_orders FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read admin wallet"
  ON admin_wallet FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "System can update admin wallet"
  ON admin_wallet FOR UPDATE
  TO authenticated
  USING (true);

INSERT INTO admin_wallet (total_revenue, coins_revenue) 
VALUES (0.00, 0)
ON CONFLICT DO NOTHING;
