/*
  # نظام المطابقة العشوائية

  1. جداول جديدة
    - `matchmaking_queue` - قائمة الانتظار للمطابقة
      - `id` (uuid, primary key)
      - `profile_id` (uuid) - اللاعب
      - `game_type` (text) - نوع اللعبة
      - `bet_amount` (numeric) - قيمة الرهان
      - `status` (text) - 'waiting', 'matched', 'cancelled'
      - `matched_with_profile_id` (uuid) - اللاعب المطابق
      - `game_session_id` (uuid) - معرف الجلسة
      - `created_at` (timestamp)
      - `matched_at` (timestamp)

    - `game_sessions` - جلسات اللعب
      - `id` (uuid, primary key)
      - `game_type` (text) - نوع اللعبة
      - `player1_profile_id` (uuid)
      - `player2_profile_id` (uuid)
      - `bet_amount` (numeric)
      - `total_pot` (numeric) - إجمالي الرهان (player1 + player2)
      - `winner_profile_id` (uuid)
      - `status` (text) - 'waiting', 'in_progress', 'completed', 'cancelled'
      - `game_data` (jsonb) - بيانات اللعبة
      - `created_at` (timestamp)
      - `started_at` (timestamp)
      - `completed_at` (timestamp)

  2. الأمان
    - RLS على جميع الجداول
    - سياسات القراءة والكتابة

  3. دوال المطابقة
    - دالة للبحث عن لاعب مطابق
    - دالة لإنشاء جلسة لعب
*/

-- جدول قائمة انتظار المطابقة
CREATE TABLE IF NOT EXISTS matchmaking_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  bet_amount numeric NOT NULL CHECK (bet_amount >= 0),
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'matched', 'cancelled')),
  matched_with_profile_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  game_session_id uuid,
  created_at timestamptz DEFAULT now(),
  matched_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_matchmaking_queue_game_type ON matchmaking_queue(game_type);
CREATE INDEX IF NOT EXISTS idx_matchmaking_queue_bet_amount ON matchmaking_queue(bet_amount);
CREATE INDEX IF NOT EXISTS idx_matchmaking_queue_status ON matchmaking_queue(status);
CREATE INDEX IF NOT EXISTS idx_matchmaking_queue_created ON matchmaking_queue(created_at);

ALTER TABLE matchmaking_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view queue" ON matchmaking_queue FOR SELECT USING (true);
CREATE POLICY "Users can join queue" ON matchmaking_queue FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update own queue" ON matchmaking_queue FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Users can cancel own queue" ON matchmaking_queue FOR DELETE USING (true);

-- جدول جلسات اللعب
CREATE TABLE IF NOT EXISTS game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  player1_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  player2_profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  bet_amount numeric NOT NULL CHECK (bet_amount >= 0),
  total_pot numeric NOT NULL DEFAULT 0,
  winner_profile_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  status text DEFAULT 'waiting' CHECK (status IN ('waiting', 'in_progress', 'completed', 'cancelled')),
  game_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  started_at timestamptz,
  completed_at timestamptz,
  CHECK (player1_profile_id != player2_profile_id)
);

CREATE INDEX IF NOT EXISTS idx_game_sessions_game_type ON game_sessions(game_type);
CREATE INDEX IF NOT EXISTS idx_game_sessions_player1 ON game_sessions(player1_profile_id);
CREATE INDEX IF NOT EXISTS idx_game_sessions_player2 ON game_sessions(player2_profile_id);
CREATE INDEX IF NOT EXISTS idx_game_sessions_status ON game_sessions(status);

ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their sessions" ON game_sessions FOR SELECT USING (true);
CREATE POLICY "System can create sessions" ON game_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update their sessions" ON game_sessions FOR UPDATE USING (true) WITH CHECK (true);

-- دالة للبحث عن لاعب مطابق
CREATE OR REPLACE FUNCTION find_match(
  p_profile_id uuid,
  p_game_type text,
  p_bet_amount numeric
)
RETURNS uuid AS $$
DECLARE
  v_matched_queue_id uuid;
  v_matched_profile_id uuid;
BEGIN
  SELECT id, profile_id INTO v_matched_queue_id, v_matched_profile_id
  FROM matchmaking_queue
  WHERE 
    status = 'waiting'
    AND game_type = p_game_type
    AND bet_amount = p_bet_amount
    AND profile_id != p_profile_id
    AND created_at < now() - interval '1 second'
  ORDER BY created_at ASC
  LIMIT 1;
  
  RETURN v_matched_queue_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة لإنشاء جلسة لعب
CREATE OR REPLACE FUNCTION create_game_session(
  p_queue1_id uuid,
  p_queue2_id uuid
)
RETURNS uuid AS $$
DECLARE
  v_session_id uuid;
  v_queue1 record;
  v_queue2 record;
BEGIN
  SELECT * INTO v_queue1 FROM matchmaking_queue WHERE id = p_queue1_id;
  SELECT * INTO v_queue2 FROM matchmaking_queue WHERE id = p_queue2_id;
  
  IF v_queue1.id IS NULL OR v_queue2.id IS NULL THEN
    RAISE EXCEPTION 'Queue entries not found';
  END IF;
  
  IF v_queue1.game_type != v_queue2.game_type OR v_queue1.bet_amount != v_queue2.bet_amount THEN
    RAISE EXCEPTION 'Mismatched game type or bet amount';
  END IF;
  
  INSERT INTO game_sessions (
    game_type,
    player1_profile_id,
    player2_profile_id,
    bet_amount,
    total_pot,
    status
  ) VALUES (
    v_queue1.game_type,
    v_queue1.profile_id,
    v_queue2.profile_id,
    v_queue1.bet_amount,
    v_queue1.bet_amount + v_queue2.bet_amount,
    'waiting'
  )
  RETURNING id INTO v_session_id;
  
  UPDATE matchmaking_queue
  SET 
    status = 'matched',
    matched_with_profile_id = v_queue2.profile_id,
    game_session_id = v_session_id,
    matched_at = now()
  WHERE id = p_queue1_id;
  
  UPDATE matchmaking_queue
  SET 
    status = 'matched',
    matched_with_profile_id = v_queue1.profile_id,
    game_session_id = v_session_id,
    matched_at = now()
  WHERE id = p_queue2_id;
  
  RETURN v_session_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة لتنظيف قوائم الانتظار القديمة (أكثر من 5 دقائق)
CREATE OR REPLACE FUNCTION cleanup_old_queues()
RETURNS void AS $$
BEGIN
  UPDATE matchmaking_queue
  SET status = 'cancelled'
  WHERE 
    status = 'waiting'
    AND created_at < now() - interval '5 minutes';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- دالة للحصول على إحصائيات قائمة الانتظار
CREATE OR REPLACE FUNCTION get_queue_stats(p_game_type text)
RETURNS TABLE (
  bet_amount numeric,
  waiting_count bigint,
  avg_wait_time interval
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    mq.bet_amount,
    COUNT(*) as waiting_count,
    AVG(now() - mq.created_at) as avg_wait_time
  FROM matchmaking_queue mq
  WHERE 
    mq.game_type = p_game_type
    AND mq.status = 'waiting'
  GROUP BY mq.bet_amount
  ORDER BY mq.bet_amount ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
