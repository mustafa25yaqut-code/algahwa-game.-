/*
  # Create Backgammon Game Tables

  1. New Tables
    - `backgammon_games`
      - `id` (uuid, primary key) - Unique game identifier
      - `status` (text) - Game status: waiting, active, finished
      - `current_turn_color` (text) - Current player's color: white or black
      - `board_data` (jsonb) - Board state with all points and checkers
      - `dice_data` (jsonb, nullable) - Current dice roll and used status
      - `bar_data` (jsonb) - Checkers on the bar for each color
      - `winner_id` (uuid, nullable) - Winner player ID
      - `created_at` (timestamptz) - Game creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

    - `backgammon_players`
      - `id` (uuid, primary key) - Unique player identifier
      - `game_id` (uuid, foreign key) - Reference to backgammon_games
      - `name` (text) - Player name
      - `color` (text) - Player's color: white or black
      - `checkers` (integer) - Number of checkers on board
      - `born_off` (integer) - Number of checkers born off
      - `is_connected` (boolean) - Connection status
      - `created_at` (timestamptz) - Player join timestamp

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read game data
    - Add policies for players to update their own data

  3. Indexes
    - Index on game_id for faster player lookups
    - Index on status for game filtering
*/

CREATE TABLE IF NOT EXISTS backgammon_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'waiting',
  current_turn_color text NOT NULL DEFAULT 'white',
  board_data jsonb NOT NULL DEFAULT '[]'::jsonb,
  dice_data jsonb,
  bar_data jsonb NOT NULL DEFAULT '{"white": 0, "black": 0}'::jsonb,
  winner_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS backgammon_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL REFERENCES backgammon_games(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text NOT NULL,
  checkers integer NOT NULL DEFAULT 15,
  born_off integer NOT NULL DEFAULT 0,
  is_connected boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_backgammon_players_game_id ON backgammon_players(game_id);
CREATE INDEX IF NOT EXISTS idx_backgammon_games_status ON backgammon_games(status);

ALTER TABLE backgammon_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE backgammon_players ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read game data"
  ON backgammon_games FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can create games"
  ON backgammon_games FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update games"
  ON backgammon_games FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read player data"
  ON backgammon_players FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can join games"
  ON backgammon_players FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Players can update own data"
  ON backgammon_players FOR UPDATE
  TO authenticated
  USING (true);
