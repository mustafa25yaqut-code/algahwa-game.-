/*
  # إضافة ميزات الدردشة والصوت والفرق

  1. جداول جديدة
    - `game_messages` - رسائل الدردشة العامة والخاصة
    - `voice_settings` - إعدادات الصوت للاعبين
    - `game_music` - الموسيقى المشتركة في اللعبة

  2. تحديثات على الجداول الموجودة
    - إضافة `game_mode` ('single' أو 'doubles') لجداول الألعاب
    - إضافة `team_id` (text) للاعبين في الألعاب الزوجية
    - إضافة `socket_id` (text) لتتبع الاتصالات

  3. الأمان
    - تفعيل RLS على جميع الجداول الجديدة
    - سياسات للقراءة والكتابة حسب اللاعبين في اللعبة
*/

-- جدول رسائل الدردشة
CREATE TABLE IF NOT EXISTS game_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL,
  player_id uuid NOT NULL,
  player_name text NOT NULL,
  message_type text NOT NULL CHECK (message_type IN ('public', 'team')),
  message_content text NOT NULL,
  team_id text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_game_messages_game_id ON game_messages(game_id);
CREATE INDEX IF NOT EXISTS idx_game_messages_created_at ON game_messages(created_at DESC);

ALTER TABLE game_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read public messages"
  ON game_messages FOR SELECT
  USING (message_type = 'public');

CREATE POLICY "Players can read team messages"
  ON game_messages FOR SELECT
  USING (message_type = 'team');

CREATE POLICY "Players can send messages"
  ON game_messages FOR INSERT
  WITH CHECK (true);

-- جدول إعدادات الصوت
CREATE TABLE IF NOT EXISTS voice_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id uuid NOT NULL,
  game_id uuid NOT NULL,
  socket_id text NOT NULL,
  mic_enabled boolean DEFAULT false,
  muted_players jsonb DEFAULT '[]'::jsonb,
  volume_level integer DEFAULT 50 CHECK (volume_level BETWEEN 0 AND 100),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(player_id, game_id)
);

CREATE INDEX IF NOT EXISTS idx_voice_settings_game ON voice_settings(game_id);
CREATE INDEX IF NOT EXISTS idx_voice_settings_socket ON voice_settings(socket_id);

ALTER TABLE voice_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players can read voice settings in game"
  ON voice_settings FOR SELECT
  USING (true);

CREATE POLICY "Players can manage own voice settings"
  ON voice_settings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Players can update own voice settings"
  ON voice_settings FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Players can delete own voice settings"
  ON voice_settings FOR DELETE
  USING (true);

-- جدول الموسيقى المشتركة
CREATE TABLE IF NOT EXISTS game_music (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid NOT NULL,
  team_id text,
  music_url text NOT NULL,
  music_title text,
  is_playing boolean DEFAULT false,
  started_by_player_id uuid NOT NULL,
  started_by_player_name text NOT NULL,
  playback_time numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_game_music_game_id ON game_music(game_id);

ALTER TABLE game_music ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Players can view music in games"
  ON game_music FOR SELECT
  USING (true);

CREATE POLICY "Players can add music"
  ON game_music FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Players can update music"
  ON game_music FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Players can delete music"
  ON game_music FOR DELETE
  USING (true);

-- إضافة أعمدة للجداول الموجودة

-- Games (Ludo)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'games' AND column_name = 'game_mode'
  ) THEN
    ALTER TABLE games ADD COLUMN game_mode text DEFAULT 'single' CHECK (game_mode IN ('single', 'doubles'));
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'players' AND column_name = 'team_id'
  ) THEN
    ALTER TABLE players ADD COLUMN team_id text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'players' AND column_name = 'socket_id'
  ) THEN
    ALTER TABLE players ADD COLUMN socket_id text;
  END IF;
END $$;

-- Jakaro
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'jakaro_games' AND column_name = 'game_mode'
  ) THEN
    ALTER TABLE jakaro_games ADD COLUMN game_mode text DEFAULT 'single' CHECK (game_mode IN ('single', 'doubles'));
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'jakaro_players' AND column_name = 'team_id'
  ) THEN
    ALTER TABLE jakaro_players ADD COLUMN team_id text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'jakaro_players' AND column_name = 'socket_id'
  ) THEN
    ALTER TABLE jakaro_players ADD COLUMN socket_id text;
  END IF;
END $$;

-- Domino - فردي فقط
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'domino_games' AND column_name = 'game_mode'
  ) THEN
    ALTER TABLE domino_games ADD COLUMN game_mode text DEFAULT 'single' CHECK (game_mode = 'single');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'domino_players' AND column_name = 'socket_id'
  ) THEN
    ALTER TABLE domino_players ADD COLUMN socket_id text;
  END IF;
END $$;

-- Backgammon - فردي فقط
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'backgammon_games' AND column_name = 'game_mode'
  ) THEN
    ALTER TABLE backgammon_games ADD COLUMN game_mode text DEFAULT 'single' CHECK (game_mode = 'single');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'backgammon_players' AND column_name = 'socket_id'
  ) THEN
    ALTER TABLE backgammon_players ADD COLUMN socket_id text;
  END IF;
END $$;
