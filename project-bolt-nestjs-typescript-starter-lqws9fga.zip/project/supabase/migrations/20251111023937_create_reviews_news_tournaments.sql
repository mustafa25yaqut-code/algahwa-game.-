/*
  # أنظمة التقييمات والأخبار والبطولات

  1. جداول جديدة
    - `user_reviews` - تقييمات اللاعبين
    - `news_articles` - الأخبار
    - `tournaments` - البطولات
    - `tournament_participants` - المشاركون في البطولات
    - `tournament_matches` - مباريات البطولات

  2. الأمان
    - RLS على جميع الجداول
*/

CREATE TABLE IF NOT EXISTS user_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reviewer_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  reviewed_user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  rating integer CHECK (rating >= 1 AND rating <= 5),
  comment text,
  match_id uuid REFERENCES match_history(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(reviewer_id, reviewed_user_id, match_id)
);

CREATE INDEX IF NOT EXISTS idx_reviews_reviewed_user ON user_reviews(reviewed_user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON user_reviews(rating);

ALTER TABLE user_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all reviews" ON user_reviews
  FOR SELECT
  USING (true);

CREATE POLICY "Users can create reviews" ON user_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reviewer_id);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_profiles' AND column_name = 'average_rating'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN average_rating numeric(3,2) DEFAULT 0;
    ALTER TABLE user_profiles ADD COLUMN total_reviews integer DEFAULT 0;
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  summary text,
  image_url text,
  category text CHECK (category IN ('update', 'event', 'announcement', 'maintenance', 'tips')),
  author_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  published boolean DEFAULT false,
  published_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_news_published ON news_articles(published, published_at DESC);
CREATE INDEX IF NOT EXISTS idx_news_category ON news_articles(category);

ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published news" ON news_articles
  FOR SELECT
  USING (published = true);

CREATE TABLE IF NOT EXISTS tournaments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  game_type text NOT NULL CHECK (game_type IN ('ludo', 'domino', 'jakaro', 'backgammon')),
  entry_fee numeric DEFAULT 0,
  prize_pool numeric NOT NULL,
  max_participants integer NOT NULL,
  current_participants integer DEFAULT 0,
  tournament_type text CHECK (tournament_type IN ('single_elimination', 'double_elimination', 'round_robin')),
  status text DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'registration', 'in_progress', 'completed', 'cancelled')),
  start_time timestamptz NOT NULL,
  end_time timestamptz,
  winner_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  rules jsonb DEFAULT '{}'::jsonb,
  prizes jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tournaments_status ON tournaments(status);
CREATE INDEX IF NOT EXISTS idx_tournaments_game_type ON tournaments(game_type);
CREATE INDEX IF NOT EXISTS idx_tournaments_start_time ON tournaments(start_time);

ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view tournaments" ON tournaments
  FOR SELECT
  USING (true);

CREATE TABLE IF NOT EXISTS tournament_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  profile_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  seed_number integer,
  current_round integer DEFAULT 1,
  eliminated boolean DEFAULT false,
  final_position integer,
  prize_won numeric DEFAULT 0,
  registered_at timestamptz DEFAULT now(),
  UNIQUE(tournament_id, profile_id)
);

CREATE INDEX IF NOT EXISTS idx_tournament_participants_tournament ON tournament_participants(tournament_id);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_profile ON tournament_participants(profile_id);
CREATE INDEX IF NOT EXISTS idx_tournament_participants_eliminated ON tournament_participants(eliminated);

ALTER TABLE tournament_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view participants" ON tournament_participants
  FOR SELECT
  USING (true);

CREATE POLICY "Users can register" ON tournament_participants
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = profile_id);

CREATE TABLE IF NOT EXISTS tournament_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  round_number integer NOT NULL,
  match_number integer NOT NULL,
  player1_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  player2_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  winner_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  match_history_id uuid REFERENCES match_history(id) ON DELETE SET NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'bye')),
  scheduled_time timestamptz,
  completed_at timestamptz,
  UNIQUE(tournament_id, round_number, match_number)
);

CREATE INDEX IF NOT EXISTS idx_tournament_matches_tournament ON tournament_matches(tournament_id);
CREATE INDEX IF NOT EXISTS idx_tournament_matches_round ON tournament_matches(round_number);
CREATE INDEX IF NOT EXISTS idx_tournament_matches_status ON tournament_matches(status);

ALTER TABLE tournament_matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view matches" ON tournament_matches
  FOR SELECT
  USING (true);

CREATE OR REPLACE FUNCTION submit_review(
  p_reviewer_id uuid,
  p_reviewed_user_id uuid,
  p_rating integer,
  p_comment text,
  p_match_id uuid DEFAULT NULL
)
RETURNS uuid AS $$
DECLARE
  v_review_id uuid;
  v_avg_rating numeric;
  v_total_reviews integer;
BEGIN
  IF p_reviewer_id = p_reviewed_user_id THEN
    RAISE EXCEPTION 'Cannot review yourself';
  END IF;
  
  INSERT INTO user_reviews (reviewer_id, reviewed_user_id, rating, comment, match_id)
  VALUES (p_reviewer_id, p_reviewed_user_id, p_rating, p_comment, p_match_id)
  ON CONFLICT (reviewer_id, reviewed_user_id, match_id) 
  DO UPDATE SET rating = p_rating, comment = p_comment
  RETURNING id INTO v_review_id;
  
  SELECT AVG(rating), COUNT(*) 
  INTO v_avg_rating, v_total_reviews
  FROM user_reviews
  WHERE reviewed_user_id = p_reviewed_user_id;
  
  UPDATE user_profiles
  SET 
    average_rating = v_avg_rating,
    total_reviews = v_total_reviews
  WHERE id = p_reviewed_user_id;
  
  RETURN v_review_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION register_for_tournament(
  p_profile_id uuid,
  p_tournament_id uuid
)
RETURNS boolean AS $$
DECLARE
  v_tournament record;
  v_user_coins numeric;
BEGIN
  SELECT * INTO v_tournament
  FROM tournaments
  WHERE id = p_tournament_id;
  
  IF v_tournament.status NOT IN ('upcoming', 'registration') THEN
    RAISE EXCEPTION 'Tournament is not open for registration';
  END IF;
  
  IF v_tournament.current_participants >= v_tournament.max_participants THEN
    RAISE EXCEPTION 'Tournament is full';
  END IF;
  
  SELECT coins INTO v_user_coins
  FROM user_profiles
  WHERE id = p_profile_id;
  
  IF v_user_coins < v_tournament.entry_fee THEN
    RAISE EXCEPTION 'Insufficient coins';
  END IF;
  
  UPDATE user_profiles
  SET coins = coins - v_tournament.entry_fee
  WHERE id = p_profile_id;
  
  INSERT INTO tournament_participants (tournament_id, profile_id)
  VALUES (p_tournament_id, p_profile_id);
  
  UPDATE tournaments
  SET current_participants = current_participants + 1
  WHERE id = p_tournament_id;
  
  PERFORM create_notification(
    p_profile_id,
    'system',
    'تم التسجيل في البطولة! 🏆',
    'لقد تم تسجيلك بنجاح في البطولة: ' || v_tournament.name,
    jsonb_build_object('tournament_id', p_tournament_id)
  );
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION get_upcoming_tournaments(p_limit integer DEFAULT 10)
RETURNS TABLE (
  tournament_id uuid,
  name text,
  game_type text,
  entry_fee numeric,
  prize_pool numeric,
  current_participants integer,
  max_participants integer,
  start_time timestamptz
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.id,
    t.name,
    t.game_type,
    t.entry_fee,
    t.prize_pool,
    t.current_participants,
    t.max_participants,
    t.start_time
  FROM tournaments t
  WHERE t.status IN ('upcoming', 'registration')
    AND t.start_time > now()
  ORDER BY t.start_time
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

INSERT INTO tournaments (
  name, description, game_type, entry_fee, prize_pool, max_participants, 
  tournament_type, status, start_time
) VALUES
  (
    'بطولة اللودو الكبرى', 
    'تنافس مع أفضل اللاعبين في بطولة اللودو الكبرى',
    'ludo',
    1000,
    50000,
    16,
    'single_elimination',
    'upcoming',
    now() + interval '7 days'
  ),
  (
    'بطولة الدومينو الأسبوعية',
    'بطولة دومينو أسبوعية للجميع',
    'domino',
    500,
    20000,
    32,
    'single_elimination',
    'registration',
    now() + interval '3 days'
  ),
  (
    'تحدي الجاكارو',
    'تحدي الجاكارو للمحترفين',
    'jakaro',
    2000,
    100000,
    16,
    'double_elimination',
    'upcoming',
    now() + interval '10 days'
  )
ON CONFLICT DO NOTHING;

INSERT INTO news_articles (
  title, content, summary, category, published, published_at
) VALUES
  (
    'مرحباً بكم في الگهوة! 🎮',
    'نرحب بكم في تطبيق الگهوة - أفضل تطبيق للعب الألعاب الشعبية مع الأصدقاء. استمتع بلعب اللودو، الدومينو، الجاكارو، وطاولة الزهر مع لاعبين من جميع أنحاء العالم.',
    'مرحباً بكم في الگهوة',
    'announcement',
    true,
    now()
  ),
  (
    'إطلاق نظام البطولات! 🏆',
    'نحن سعداء بالإعلان عن إطلاق نظام البطولات الجديد! الآن يمكنك المشاركة في بطولات منظمة والتنافس على جوائز كبيرة. سجل الآن في البطولة القادمة!',
    'إطلاق نظام البطولات',
    'update',
    true,
    now()
  ),
  (
    'نصائح للفوز في اللودو 🎲',
    'إليك بعض النصائح المهمة للفوز في لعبة اللودو: 1) حاول إخراج جميع القطع بسرعة 2) احمِ قطعك بوضعها معاً 3) استهدف قطع الخصم 4) كن صبوراً في اللحظات الحرجة',
    'نصائح للفوز في اللودو',
    'tips',
    true,
    now() - interval '1 day'
  )
ON CONFLICT DO NOTHING;
