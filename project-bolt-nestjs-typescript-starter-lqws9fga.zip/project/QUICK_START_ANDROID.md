# 🚀 البدء السريع - بناء APK للأندرويد

## ✅ الإعداد مكتمل!

تم تجهيز مشروع Android بالكامل وجاهز للبناء.

---

## 📱 الطريقة السريعة (3 خطوات)

### الخطوة 1: تثبيت المتطلبات

```bash
# حمّل وثبت Android Studio
https://developer.android.com/studio

# بعد التثبيت، افتح Android Studio وثبت:
# - Android SDK
# - Android SDK Platform (API 34 أو أحدث)
# - Android SDK Build-Tools
```

### الخطوة 2: مزامنة المشروع

```bash
# نسخ الملفات إلى Android
npm run android:sync
```

### الخطوة 3: بناء APK

```bash
# افتح Android Studio
npm run android:open

# ثم في Android Studio:
# Build → Build Bundle(s) / APK(s) → Build APK(s)

# ✅ سيتم إنشاء ملف APK في:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 🎯 الأوامر المتاحة

```bash
# مزامنة التغييرات مع Android
npm run android:sync

# فتح Android Studio
npm run android:open

# بناء وتشغيل على جهاز متصل
npm run android:run

# بناء APK موقّع للنشر
npm run android:build

# بناء AAB للنشر على Google Play
npm run android:bundle
```

---

## 📦 ملفات APK الناتجة

### للتطوير (Debug):
```
android/app/build/outputs/apk/debug/app-debug.apk
الحجم: ~10-15 MB
الاستخدام: الاختبار المحلي فقط
```

### للنشر (Release):
```
android/app/build/outputs/apk/release/app-release.apk
الحجم: ~8-10 MB
الاستخدام: النشر للمستخدمين

android/app/build/outputs/bundle/release/app-release.aab
الحجم: ~7-9 MB
الاستخدام: النشر على Google Play (موصى به)
```

---

## 🔧 حل المشاكل السريع

### المشكلة: Android Studio لا يفتح المشروع
```bash
# تأكد من تثبيت JDK 17
java -version

# إذا لم يكن مثبتاً:
# Windows: حمّل من https://adoptium.net/
# macOS: brew install openjdk@17
# Linux: sudo apt install openjdk-17-jdk
```

### المشكلة: Gradle build failed
```bash
# نظف المشروع وأعد البناء
cd android
./gradlew clean
npx cap sync
```

### المشكلة: APK كبير جداً
```bash
# استخدم AAB بدلاً من APK (أصغر 20-30%)
npm run android:bundle
```

---

## 📲 تثبيت APK على الهاتف

### الطريقة 1: USB
```bash
# وصّل الهاتف بالكمبيوتر
# فعّل "تصحيح USB" في خيارات المطور
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### الطريقة 2: مباشرة
```bash
# انسخ ملف APK إلى الهاتف
# افتح الملف على الهاتف وثبّته
# (قد تحتاج للسماح بتثبيت من مصادر غير معروفة)
```

---

## 🏪 النشر على Google Play

### 1. أنشئ حساب مطور ($25 لمرة واحدة)
```
https://play.google.com/console/signup
```

### 2. ابنِ AAB موقّع
```bash
# أولاً: أنشئ مفتاح توقيع (مرة واحدة)
keytool -genkey -v -keystore algahwa-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias algahwa

# ثانياً: ابنِ AAB
npm run android:bundle
```

### 3. ارفع على Google Play
```
1. اذهب إلى Google Play Console
2. أنشئ تطبيق جديد
3. املأ المعلومات المطلوبة
4. ارفع ملف AAB
5. انتظر المراجعة (2-7 أيام)
```

---

## 📋 قائمة التحقق قبل النشر

```
✅ اختبار على أجهزة حقيقية
✅ التأكد من جميع الميزات تعمل
✅ إضافة لقطات شاشة جيدة
✅ كتابة وصف جذاب
✅ تحديد الفئة العمرية
✅ إضافة سياسة الخصوصية
✅ اختبار داخلي مع 20 مستخدم على الأقل
✅ مراجعة جميع الصلاحيات المطلوبة
```

---

## 🎨 تخصيص التطبيق

### تغيير الأيقونة:
```bash
# استبدل الملفات في:
android/app/src/main/res/mipmap-*/ic_launcher.png
```

### تغيير اسم التطبيق:
```xml
<!-- في android/app/src/main/res/values/strings.xml -->
<string name="app_name">اسم جديد</string>
```

### تغيير Package Name:
```
⚠️ لا يُنصح بعد إنشاء المشروع
إذا كان ضرورياً، استخدم Android Studio:
Refactor → Rename Package
```

---

## 📊 معلومات المشروع الحالي

```
اسم التطبيق: الگهوة
Package: com.algahwa.game
الإصدار: 1.0.0 (versionCode: 1)
الحد الأدنى لـ Android: API 22 (Android 5.1)
الإصدار المستهدف: API 34 (Android 14)

الميزات المضمنة:
✅ Push Notifications
✅ Haptic Feedback
✅ Share functionality
✅ Status Bar control
✅ Splash Screen
✅ RTL Support (دعم العربية)
```

---

## 🔗 روابط مهمة

- [دليل كامل](BUILD_ANDROID_APK.md) - دليل مفصل خطوة بخطوة
- [Capacitor Docs](https://capacitorjs.com/docs/android) - التوثيق الرسمي
- [Google Play Console](https://play.google.com/console) - لوحة النشر
- [Android Developer Guide](https://developer.android.com) - دليل المطورين

---

## 💡 نصائح

1. **استخدم AAB بدلاً من APK** للنشر على Google Play (حجم أصغر)
2. **اختبر على أجهزة حقيقية** متنوعة قبل النشر
3. **راقب Crash Reports** في Google Play Console
4. **حدّث بانتظام** لإصلاح الأخطاء وإضافة ميزات
5. **اقرأ تعليقات المستخدمين** وحسّن التطبيق بناءً عليها

---

## ✨ مستعد للبدء؟

```bash
# ابدأ الآن:
npm run android:sync
npm run android:open

# في Android Studio:
# Build → Build APK
```

**🎮 حظاً موفقاً! 🚀**
