#!/bin/bash
# سكريبت لبناء APK باستخدام Docker (بدون Android Studio)

echo "🐳 بناء APK باستخدام Docker..."
echo "================================"
echo ""

# التحقق من وجود Docker
if ! command -v docker &> /dev/null; then
    echo "❌ خطأ: Docker غير مثبت!"
    echo "📥 ثبّت Docker من: https://www.docker.com/get-started"
    exit 1
fi

echo "✅ Docker متوفر"
echo ""

# بناء Docker image
echo "🔨 بناء Docker image..."
docker build -f Dockerfile.android -t algahwa-android-builder .

if [ $? -ne 0 ]; then
    echo "❌ فشل بناء Docker image"
    exit 1
fi

echo ""
echo "✅ تم بناء Docker image بنجاح"
echo ""

# تشغيل البناء
echo "🚀 بدء بناء APK..."
docker run --rm \
    -v "$(pwd)/android/app/build:/app/android/app/build" \
    algahwa-android-builder

if [ $? -ne 0 ]; then
    echo "❌ فشل بناء APK"
    exit 1
fi

echo ""
echo "================================"
echo "✅ تم بناء APK بنجاح!"
echo ""
echo "📍 موقع APK:"
echo "   android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "📱 لتثبيته على هاتفك:"
echo "   adb install android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "🎉 تهانينا!"
