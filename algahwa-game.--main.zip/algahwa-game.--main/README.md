git init
git add .
git commit -m "AlGahwa Game"
git remote add origin https://github.com/اسمك/algahwa-game.git
git push -u origin main

